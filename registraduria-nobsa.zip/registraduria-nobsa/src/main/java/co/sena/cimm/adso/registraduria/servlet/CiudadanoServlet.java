package co.sena.cimm.adso.registraduria.servlet;

import co.sena.cimm.adso.registraduria.dao.CiudadanoDAO;
import co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl;
import co.sena.cimm.adso.registraduria.model.Ciudadano;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

@WebServlet("/ciudadanos")
public class CiudadanoServlet extends HttpServlet {
    
    private final CiudadanoDAO dao = new CiudadanoDAOImpl();
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        String action = req.getParameter("action");
        
        try {
            // ELIMINAR CIUDADANO - CON VALIDACIÓN
            if ("eliminar".equals(action)) {
                String idParam = req.getParameter("id");
                if (idParam != null && !idParam.isEmpty()) {
                    int id = Integer.parseInt(idParam);
                    
                    // Verificar si tiene documentos asociados
                    if (dao.tieneDocs(id)) {
                        req.getSession().setAttribute("error", 
                            "No se puede eliminar: El ciudadano tiene documentos expedidos asociados.");
                    } else {
                        boolean eliminado = dao.eliminar(id);
                        if (eliminado) {
                            req.getSession().setAttribute("success", "Ciudadano eliminado correctamente.");
                        } else {
                            req.getSession().setAttribute("error", "Error al eliminar el ciudadano.");
                        }
                    }
                }
                resp.sendRedirect(req.getContextPath() + "/ciudadanos");
                return;
            }
            
            // EDITAR - Mostrar formulario
            if ("editar".equals(action)) {
                String idParam = req.getParameter("id");
                if (idParam != null && !idParam.isEmpty()) {
                    int id = Integer.parseInt(idParam);
                    Ciudadano c = dao.buscarPorId(id);
                    req.setAttribute("ciudadano", c);
                }
                req.getRequestDispatcher("/WEB-INF/vistas/ciudadanos/formCiudadano.jsp")
                    .forward(req, resp);
                return;
            }
            
            // NUEVO - Mostrar formulario vacío
            if ("nuevo".equals(action)) {
                req.getRequestDispatcher("/WEB-INF/vistas/ciudadanos/formCiudadano.jsp")
                    .forward(req, resp);
                return;
            }
            
            // LISTAR (por defecto)
            List<Ciudadano> lista = dao.listarTodos();
            req.setAttribute("ciudadanos", lista);
            req.getRequestDispatcher("/WEB-INF/vistas/ciudadanos/listaCiudadanos.jsp")
                .forward(req, resp);
                
        } catch (Exception e) {
            throw new ServletException("Error en CiudadanoServlet", e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        
        try {
            Ciudadano c = new Ciudadano();
            
            String idParam = req.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                c.setId(Integer.parseInt(idParam));
            }
            
            c.setNumeroDocumento(req.getParameter("numeroDocumento"));
            c.setNombres(req.getParameter("nombres"));
            c.setApellidos(req.getParameter("apellidos"));
            c.setFechaNacimiento(Date.valueOf(req.getParameter("fechaNacimiento")));
            c.setVeredaBarrio(req.getParameter("veredaBarrio"));
            c.setTelefono(req.getParameter("telefono"));
            c.setCorreo(req.getParameter("correo"));
            
            String idMesaParam = req.getParameter("idMesa");
            if (idMesaParam != null && !idMesaParam.isEmpty()) {
                c.setIdMesa(Integer.parseInt(idMesaParam));
            }
            
            boolean success;
            if (c.getId() == 0) {
                success = dao.insertar(c);
            } else {
                success = dao.actualizar(c);
            }
            
            if (success) {
                req.getSession().setAttribute("success", 
                    c.getId() == 0 ? "Ciudadano registrado correctamente." : "Ciudadano actualizado correctamente.");
            } else {
                req.getSession().setAttribute("error", "Error al guardar el ciudadano.");
            }
            
            resp.sendRedirect(req.getContextPath() + "/ciudadanos");
            
        } catch (Exception e) {
            throw new ServletException("Error guardando ciudadano", e);
        }
    }
}