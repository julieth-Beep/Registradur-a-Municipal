package co.sena.cimm.adso.registraduria.servlet;

import co.sena.cimm.adso.registraduria.dao.UsuarioDAO;
import co.sena.cimm.adso.registraduria.dao.UsuarioDAOImpl;
import co.sena.cimm.adso.registraduria.dao.CiudadanoDAO;
import co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl;
import co.sena.cimm.adso.registraduria.model.Usuario;
import co.sena.cimm.adso.registraduria.model.Ciudadano;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/votante/*")
public class VotanteServlet extends HttpServlet {
    
    private UsuarioDAO usuarioDAO;
    private CiudadanoDAO ciudadanoDAO;
    
    @Override
    public void init() {
        usuarioDAO = new UsuarioDAOImpl();
        ciudadanoDAO = new CiudadanoDAOImpl();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("usuario") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }
        
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        String path = req.getPathInfo();
        
        try {
            // PERFIL - Ver información
            if ("/perfil".equals(path)) {
                Ciudadano ciudadano = ciudadanoDAO.buscarPorDocumento(usuario.getDocumento());
                req.setAttribute("ciudadano", ciudadano);
                req.getRequestDispatcher("/WEB-INF/vistas/votante/perfil.jsp").forward(req, resp);
                return;
            }
            
            // EDITAR PERFIL - Formulario
            if ("/editar-perfil".equals(path)) {
                req.getRequestDispatcher("/WEB-INF/vistas/votante/editar-perfil.jsp").forward(req, resp);
                return;
            }
            
            // MIS DOCUMENTOS
            if ("/documentos".equals(path)) {
                req.getRequestDispatcher("/WEB-INF/vistas/votante/documentos.jsp").forward(req, resp);
                return;
            }
            
            // Por defecto, redirigir al perfil
            resp.sendRedirect(req.getContextPath() + "/votante/perfil");
            
        } catch (Exception e) {
            throw new ServletException("Error en VotanteServlet", e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        
        String path = req.getPathInfo();
        
        try {
            // EDITAR PERFIL - Guardar cambios
            if ("/editar-perfil".equals(path)) {
                String username = req.getParameter("username");
                String password = req.getParameter("password");
                String confirmPassword = req.getParameter("confirmPassword");
                
                // Validar username único
                Usuario existente = usuarioDAO.buscarPorUsername(username);
                if (existente != null && existente.getId() != usuario.getId()) {
                    req.getSession().setAttribute("error", "El nombre de usuario ya está en uso.");
                    resp.sendRedirect(req.getContextPath() + "/votante/editar-perfil");
                    return;
                }
                
                // Validar contraseñas
                if (password != null && !password.isEmpty()) {
                    if (!password.equals(confirmPassword)) {
                        req.getSession().setAttribute("error", "Las contraseñas no coinciden.");
                        resp.sendRedirect(req.getContextPath() + "/votante/editar-perfil");
                        return;
                    }
                    usuario.setContraseña(password);
                }
                
                usuario.setUsername(username);
                
                boolean actualizado = usuarioDAO.actualizar(usuario);
                
                if (actualizado) {
                    session.setAttribute("usuario", usuario);
                    req.getSession().setAttribute("success", "Perfil actualizado correctamente.");
                    resp.sendRedirect(req.getContextPath() + "/votante/perfil");
                } else {
                    req.getSession().setAttribute("error", "Error al actualizar el perfil.");
                    resp.sendRedirect(req.getContextPath() + "/votante/editar-perfil");
                }
                return;
            }
            
            resp.sendRedirect(req.getContextPath() + "/votante/perfil");
            
        } catch (Exception e) {
            req.getSession().setAttribute("error", "Error: " + e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/votante/perfil");
        }
    }
}