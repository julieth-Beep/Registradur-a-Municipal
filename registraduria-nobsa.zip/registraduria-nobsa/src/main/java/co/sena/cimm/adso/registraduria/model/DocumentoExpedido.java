package co.sena.cimm.adso.registraduria.model;

import java.util.Date;

public class DocumentoExpedido {

    private int id;
    private int idCiudadano;
    private String tipoDocumento;
    private String numeroSerie;
    private Date fechaExpedicion;
    private Date fechaVencimiento;
    private String estado;
    private String observaciones;
    private String imagenDocumento;

    // Campos para JOIN con ciudadano
    private String nombresCiudadano;
    private String apellidosCiudadano;
    private String numeroDocumento;

    public DocumentoExpedido() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdCiudadano() {
        return idCiudadano;
    }

    public void setIdCiudadano(int idCiudadano) {
        this.idCiudadano = idCiudadano;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public void setNumeroSerie(String numeroSerie) {
        this.numeroSerie = numeroSerie;
    }

    public Date getFechaExpedicion() {
        return fechaExpedicion;
    }

    public void setFechaExpedicion(Date fechaExpedicion) {
        this.fechaExpedicion = fechaExpedicion;
    }

    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(Date fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getImagenDocumento() {
        return imagenDocumento;
    }

    public void setImagenDocumento(String imagenDocumento) {
        this.imagenDocumento = imagenDocumento;
    }

    public String getNombresCiudadano() {
        return nombresCiudadano;
    }

    public void setNombresCiudadano(String nombresCiudadano) {
        this.nombresCiudadano = nombresCiudadano;
    }

    public String getApellidosCiudadano() {
        return apellidosCiudadano;
    }

    public void setApellidosCiudadano(String apellidosCiudadano) {
        this.apellidosCiudadano = apellidosCiudadano;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getNombreCompletoCiudadano() {
        return (nombresCiudadano != null ? nombresCiudadano : "")
                + " " + (apellidosCiudadano != null ? apellidosCiudadano : "");
    }
}
