package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.config.ConexionDB;
import co.sena.cimm.adso.registraduria.model.Ciudadano;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CiudadanoDAOImpl implements CiudadanoDAO {
    
    @Override
    public List<Ciudadano> listarTodos() throws Exception {
        List<Ciudadano> lista = new ArrayList<>();
        String sql = "SELECT c.*, m.numero_mesa, z.nombre_zona, z.puesto_votacion, " +
                    "z.direccion, cd.nombre as ciudad_nombre, cd.departamento " +
                    "FROM ciudadanos c " +
                    "LEFT JOIN mesas_votacion m ON c.id_mesa = m.id " +
                    "LEFT JOIN zonas_votacion z ON m.id_zona = z.id " +
                    "LEFT JOIN ciudades cd ON z.id_ciudad = cd.id " +
                    "ORDER BY c.id DESC";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                lista.add(mapearCiudadano(rs));
            }
        }
        return lista;
    }
    
    @Override
    public Ciudadano buscarPorId(int id) throws Exception {
        String sql = "SELECT c.*, m.numero_mesa, z.nombre_zona, z.puesto_votacion, " +
                    "z.direccion, cd.nombre as ciudad_nombre, cd.departamento " +
                    "FROM ciudadanos c " +
                    "LEFT JOIN mesas_votacion m ON c.id_mesa = m.id " +
                    "LEFT JOIN zonas_votacion z ON m.id_zona = z.id " +
                    "LEFT JOIN ciudades cd ON z.id_ciudad = cd.id " +
                    "WHERE c.id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearCiudadano(rs);
                }
            }
        }
        return null;
    }
    
    @Override
    public Ciudadano buscarPorDocumento(String documento) throws Exception {
        String sql = "SELECT c.*, m.numero_mesa, z.nombre_zona, z.puesto_votacion, " +
                    "z.direccion, cd.nombre as ciudad_nombre, cd.departamento " +
                    "FROM ciudadanos c " +
                    "LEFT JOIN mesas_votacion m ON c.id_mesa = m.id " +
                    "LEFT JOIN zonas_votacion z ON m.id_zona = z.id " +
                    "LEFT JOIN ciudades cd ON z.id_ciudad = cd.id " +
                    "WHERE c.numero_documento = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, documento);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearCiudadano(rs);
                }
            }
        }
        return null;
    }
    
    @Override
    public Ciudadano buscarConZonaYMesa(String documento) throws Exception {
        return buscarPorDocumento(documento);
    }
    
    @Override
    public boolean insertar(Ciudadano ciudadano) throws Exception {
        String sql = "INSERT INTO ciudadanos (numero_documento, nombres, apellidos, " +
                    "fecha_nacimiento, vereda_barrio, telefono, correo, id_mesa) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, ciudadano.getNumeroDocumento());
            stmt.setString(2, ciudadano.getNombres());
            stmt.setString(3, ciudadano.getApellidos());
            stmt.setDate(4, new java.sql.Date(ciudadano.getFechaNacimiento().getTime()));
            stmt.setString(5, ciudadano.getVeredaBarrio());
            stmt.setString(6, ciudadano.getTelefono());
            stmt.setString(7, ciudadano.getCorreo());
            
            if (ciudadano.getIdMesa() != null && ciudadano.getIdMesa() > 0) {
                stmt.setInt(8, ciudadano.getIdMesa());
            } else {
                stmt.setNull(8, java.sql.Types.INTEGER);
            }
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    @Override
    public boolean actualizar(Ciudadano ciudadano) throws Exception {
        String sql = "UPDATE ciudadanos SET nombres = ?, apellidos = ?, " +
                    "fecha_nacimiento = ?, vereda_barrio = ?, telefono = ?, " +
                    "correo = ?, id_mesa = ? WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, ciudadano.getNombres());
            stmt.setString(2, ciudadano.getApellidos());
            stmt.setDate(3, new java.sql.Date(ciudadano.getFechaNacimiento().getTime()));
            stmt.setString(4, ciudadano.getVeredaBarrio());
            stmt.setString(5, ciudadano.getTelefono());
            stmt.setString(6, ciudadano.getCorreo());
            
            if (ciudadano.getIdMesa() != null && ciudadano.getIdMesa() > 0) {
                stmt.setInt(7, ciudadano.getIdMesa());
            } else {
                stmt.setNull(7, java.sql.Types.INTEGER);
            }
            
            stmt.setInt(8, ciudadano.getId());
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    @Override
    public boolean eliminar(int id) throws Exception {
        String sql = "DELETE FROM ciudadanos WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }
    
    @Override
    public boolean tieneDocs(int idCiudadano) throws Exception {
        String sql = "SELECT COUNT(*) FROM documentos_expedidos WHERE id_ciudadano = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idCiudadano);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }
    
    @Override
    public int contarTotal() throws Exception {
        String sql = "SELECT COUNT(*) FROM ciudadanos";
        
        try (Connection conn = ConexionDB.getConexion();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }
    
    @Override
    public List<Ciudadano> buscarPorNombre(String nombre) throws Exception {
        List<Ciudadano> lista = new ArrayList<>();
        String sql = "SELECT c.*, m.numero_mesa, z.nombre_zona " +
                    "FROM ciudadanos c " +
                    "LEFT JOIN mesas_votacion m ON c.id_mesa = m.id " +
                    "LEFT JOIN zonas_votacion z ON m.id_zona = z.id " +
                    "WHERE c.nombres LIKE ? OR c.apellidos LIKE ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            String pattern = "%" + nombre + "%";
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearCiudadano(rs));
                }
            }
        }
        return lista;
    }
    
    private Ciudadano mapearCiudadano(ResultSet rs) throws SQLException {
        Ciudadano c = new Ciudadano();
        c.setId(rs.getInt("id"));
        c.setNumeroDocumento(rs.getString("numero_documento"));
        c.setNombres(rs.getString("nombres"));
        c.setApellidos(rs.getString("apellidos"));
        c.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
        c.setVeredaBarrio(rs.getString("vereda_barrio"));
        c.setTelefono(rs.getString("telefono"));
        c.setCorreo(rs.getString("correo"));
        c.setFechaRegistro(rs.getTimestamp("fecha_registro"));
        
        int idMesa = rs.getInt("id_mesa");
        if (!rs.wasNull()) {
            c.setIdMesa(idMesa);
        }
        
        try {
            c.setNumeroMesa(rs.getInt("numero_mesa"));
            c.setNombreZona(rs.getString("nombre_zona"));
            c.setPuestoVotacion(rs.getString("puesto_votacion"));
            c.setDireccionZona(rs.getString("direccion"));
            c.setNombreCiudad(rs.getString("ciudad_nombre"));
            c.setDepartamento(rs.getString("departamento"));
        } catch (SQLException e) {
            // Columnas no disponibles
        }
        
        return c;
    }
}