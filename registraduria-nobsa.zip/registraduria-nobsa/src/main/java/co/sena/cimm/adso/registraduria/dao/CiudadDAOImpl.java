package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.config.ConexionDB;
import co.sena.cimm.adso.registraduria.model.Ciudad;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CiudadDAOImpl implements CiudadDAO {
    
    @Override
    public List<Ciudad> listarTodos() throws Exception {
        List<Ciudad> lista = new ArrayList<>();
        String sql = "SELECT * FROM ciudades ORDER BY nombre";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                lista.add(mapearCiudad(rs));
            }
        }
        return lista;
    }
    
    @Override
    public Ciudad buscarPorId(int id) throws Exception {
        String sql = "SELECT * FROM ciudades WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearCiudad(rs);
                }
            }
        }
        return null;
    }
    
    @Override
    public Ciudad buscarPorCodigoDane(String codigoDane) throws Exception {
        String sql = "SELECT * FROM ciudades WHERE codigo_dane = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, codigoDane);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearCiudad(rs);
                }
            }
        }
        return null;
    }
    
    @Override
    public boolean insertar(Ciudad ciudad) throws Exception {
        String sql = "INSERT INTO ciudades (nombre, departamento, codigo_dane) VALUES (?, ?, ?)";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, ciudad.getNombre());
            stmt.setString(2, ciudad.getDepartamento());
            stmt.setString(3, ciudad.getCodigoDane());
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    @Override
    public boolean actualizar(Ciudad ciudad) throws Exception {
        String sql = "UPDATE ciudades SET nombre = ?, departamento = ?, codigo_dane = ? WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, ciudad.getNombre());
            stmt.setString(2, ciudad.getDepartamento());
            stmt.setString(3, ciudad.getCodigoDane());
            stmt.setInt(4, ciudad.getId());
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    @Override
    public boolean eliminar(int id) throws Exception {
        String sql = "DELETE FROM ciudades WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }
    
    private Ciudad mapearCiudad(ResultSet rs) throws SQLException {
        Ciudad c = new Ciudad();
        c.setId(rs.getInt("id"));
        c.setNombre(rs.getString("nombre"));
        c.setDepartamento(rs.getString("departamento"));
        c.setCodigoDane(rs.getString("codigo_dane"));
        return c;
    }
}