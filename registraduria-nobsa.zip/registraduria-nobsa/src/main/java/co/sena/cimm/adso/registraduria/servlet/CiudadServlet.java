package co.sena.cimm.adso.registraduria.servlet;

import co.sena.cimm.adso.registraduria.dao.CiudadDAO;
import co.sena.cimm.adso.registraduria.dao.CiudadDAOImpl;
import co.sena.cimm.adso.registraduria.model.Ciudad;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@WebServlet("/admin/ciudades")
public class CiudadServlet extends HttpServlet {
    
    private CiudadDAO ciudadDAO;
    
    @Override
    public void init() {
        ciudadDAO = new CiudadDAOImpl();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        String action = req.getParameter("action");
        
        try {
            if ("eliminar".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                ciudadDAO.eliminar(id);
                resp.sendRedirect(req.getContextPath() + "/admin/ciudades?success=eliminado");
                
            } else if ("nuevo".equals(action)) {
                req.getRequestDispatcher("/WEB-INF/vistas/admin/formCiudad.jsp")
                    .forward(req, resp);
                
            } else if ("editar".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                Ciudad ciudad = ciudadDAO.buscarPorId(id);
                req.setAttribute("ciudad", ciudad);
                req.getRequestDispatcher("/WEB-INF/vistas/admin/formCiudad.jsp")
                    .forward(req, resp);
                
            } else {
                // Listar todas las ciudades y calcular estadísticas
                List<Ciudad> ciudades = ciudadDAO.listarTodos();
                
                // Calcular estadísticas (compatible Java 7 / Tomcat 7)
                int totalCiudades = ciudades != null ? ciudades.size() : 0;
                
                Set<String> departamentosSet = new HashSet<String>();
                int conCodigoDane = 0;
                
                if (ciudades != null) {
                    for (Ciudad c : ciudades) {
                        if (c.getDepartamento() != null && !c.getDepartamento().isEmpty()) {
                            departamentosSet.add(c.getDepartamento());
                        }
                        if (c.getCodigoDane() != null && !c.getCodigoDane().isEmpty()) {
                            conCodigoDane++;
                        }
                    }
                }
                
                int totalDepartamentos = departamentosSet.size();
                
                // Pasar atributos a la vista
                req.setAttribute("ciudades", ciudades);
                req.setAttribute("totalCiudades", totalCiudades);
                req.setAttribute("totalDepartamentos", totalDepartamentos);
                req.setAttribute("conCodigoDane", conCodigoDane);
                
                req.getRequestDispatcher("/WEB-INF/vistas/admin/listaCiudades.jsp")
                    .forward(req, resp);
            }
        } catch (Exception e) {
            System.err.println("❌ ERROR en CiudadServlet GET: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("Error en CiudadServlet", e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        
        try {
            Ciudad ciudad = new Ciudad();
            
            String idParam = req.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                ciudad.setId(Integer.parseInt(idParam));
            }
            
            ciudad.setNombre(req.getParameter("nombre"));
            ciudad.setDepartamento(req.getParameter("departamento"));
            ciudad.setCodigoDane(req.getParameter("codigoDane"));
            
            if (ciudad.getId() == 0) {
                ciudadDAO.insertar(ciudad);
                resp.sendRedirect(req.getContextPath() + "/admin/ciudades?success=creado");
            } else {
                ciudadDAO.actualizar(ciudad);
                resp.sendRedirect(req.getContextPath() + "/admin/ciudades?success=actualizado");
            }
            
        } catch (Exception e) {
            System.err.println("❌ ERROR guardando ciudad: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("Error guardando ciudad", e);
        }
    }
}