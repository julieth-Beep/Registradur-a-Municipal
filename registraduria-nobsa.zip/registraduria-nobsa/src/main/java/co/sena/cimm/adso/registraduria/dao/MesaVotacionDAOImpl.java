package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.config.ConexionDB;
import co.sena.cimm.adso.registraduria.model.MesaVotacion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MesaVotacionDAOImpl implements MesaVotacionDAO {
    
    @Override
    public List<MesaVotacion> listarTodos() throws Exception {
        List<MesaVotacion> lista = new ArrayList<>();
        String sql = "SELECT m.*, z.nombre_zona, c.nombre as ciudad_nombre " +
                    "FROM mesas_votacion m " +
                    "INNER JOIN zonas_votacion z ON m.id_zona = z.id " +
                    "INNER JOIN ciudades c ON z.id_ciudad = c.id " +
                    "ORDER BY m.numero_mesa";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                lista.add(mapearMesa(rs));
            }
        }
        return lista;
    }
    
    @Override
    public List<MesaVotacion> listarPorZona(int idZona) throws Exception {
        List<MesaVotacion> lista = new ArrayList<>();
        String sql = "SELECT m.*, z.nombre_zona, c.nombre as ciudad_nombre " +
                    "FROM mesas_votacion m " +
                    "INNER JOIN zonas_votacion z ON m.id_zona = z.id " +
                    "INNER JOIN ciudades c ON z.id_ciudad = c.id " +
                    "WHERE m.id_zona = ? " +
                    "ORDER BY m.numero_mesa";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idZona);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearMesa(rs));
                }
            }
        }
        return lista;
    }
    
    @Override
    public MesaVotacion buscarPorId(int id) throws Exception {
        String sql = "SELECT m.*, z.nombre_zona, c.nombre as ciudad_nombre " +
                    "FROM mesas_votacion m " +
                    "INNER JOIN zonas_votacion z ON m.id_zona = z.id " +
                    "INNER JOIN ciudades c ON z.id_ciudad = c.id " +
                    "WHERE m.id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearMesa(rs);
                }
            }
        }
        return null;
    }
    
    @Override
    public boolean insertar(MesaVotacion mesa) throws Exception {
        String sql = "INSERT INTO mesas_votacion (id_zona, numero_mesa, capacidad) VALUES (?, ?, ?)";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, mesa.getIdZona());
            stmt.setInt(2, mesa.getNumeroMesa());
            stmt.setInt(3, mesa.getCapacidad() != null ? mesa.getCapacidad() : 200);
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    @Override
    public boolean actualizar(MesaVotacion mesa) throws Exception {
        String sql = "UPDATE mesas_votacion SET id_zona = ?, numero_mesa = ?, capacidad = ? WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, mesa.getIdZona());
            stmt.setInt(2, mesa.getNumeroMesa());
            stmt.setInt(3, mesa.getCapacidad() != null ? mesa.getCapacidad() : 200);
            stmt.setInt(4, mesa.getId());
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    @Override
    public boolean eliminar(int id) throws Exception {
        String sql = "DELETE FROM mesas_votacion WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }
    
    private MesaVotacion mapearMesa(ResultSet rs) throws SQLException {
        MesaVotacion m = new MesaVotacion();
        m.setId(rs.getInt("id"));
        m.setIdZona(rs.getInt("id_zona"));
        m.setNumeroMesa(rs.getInt("numero_mesa"));
        m.setCapacidad(rs.getInt("capacidad"));
        m.setNombreZona(rs.getString("nombre_zona"));
        m.setNombreCiudad(rs.getString("ciudad_nombre"));
        return m;
    }
}