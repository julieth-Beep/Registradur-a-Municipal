package co.sena.cimm.adso.registraduria.servlet;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import co.sena.cimm.adso.registraduria.dao.UsuarioDAO;
import co.sena.cimm.adso.registraduria.dao.UsuarioDAOImpl;
import co.sena.cimm.adso.registraduria.model.Usuario;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private UsuarioDAO usuarioDAO;
    private static final int MAX_LOGIN_ATTEMPTS = 5;
    private static final int SESSION_TIMEOUT = 30 * 60; // 30 minutos en segundos

    @Override
    public void init() {
        usuarioDAO = new UsuarioDAOImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);

        // Si ya hay una sesión activa, redirigir según el rol
        if (session != null && session.getAttribute("usuario") != null) {
            Usuario usuario = (Usuario) session.getAttribute("usuario");
            redirectByRole(req, resp, usuario);
            return;
        }

        // Verificar si hay mensaje de logout
        String logout = req.getParameter("logout");
        if (logout != null) {
            req.setAttribute("success", "Has cerrado sesión exitosamente.");
        }

        // Verificar si hay mensaje de sesión expirada
        String expired = req.getParameter("expired");
        if (expired != null) {
            req.setAttribute("error", "Tu sesión ha expirado. Por favor, inicia sesión nuevamente.");
        }

        // Verificar si hay una URL de redirección guardada (para mostrar mensaje)
        HttpSession sessionForRedirect = req.getSession();
        String redirectURL = (String) sessionForRedirect.getAttribute("redirectAfterLogin");
        if (redirectURL != null) {
            req.setAttribute("info", "Debes iniciar sesión para acceder a: " + redirectURL);
        }

        // Mostrar la página de login
        req.getRequestDispatcher("/WEB-INF/vistas/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String rememberMe = req.getParameter("remember");

        // Validar campos requeridos
        if (username == null || username.trim().isEmpty() ||
                password == null || password.trim().isEmpty()) {

            req.setAttribute("error", "Usuario y contraseña son requeridos");
            req.getRequestDispatcher("/WEB-INF/vistas/login.jsp").forward(req, resp);
            return;
        }

        username = username.trim();
        password = password.trim();

        // Verificar intentos de login (protección contra fuerza bruta)
        HttpSession session = req.getSession();
        Integer loginAttempts = (Integer) session.getAttribute("loginAttempts");

        if (loginAttempts != null && loginAttempts >= MAX_LOGIN_ATTEMPTS) {
            req.setAttribute("error",
                    "Demasiados intentos fallidos. Por favor, espera 15 minutos o contacta al administrador.");
            req.getRequestDispatcher("/WEB-INF/vistas/login.jsp").forward(req, resp);
            return;
        }

        // Intentar autenticar
        Usuario usuario = usuarioDAO.login(username, password);

        if (usuario != null) {
            // Verificar si el usuario está activo
            if (!usuario.isActivo()) {
                req.setAttribute("error",
                        "Tu cuenta está inactiva. Contacta al administrador del sistema.");
                req.getRequestDispatcher("/WEB-INF/vistas/login.jsp").forward(req, resp);
                return;
            }

            // Login exitoso - Limpiar intentos fallidos
            session.removeAttribute("loginAttempts");

            // Crear nueva sesión (invalidar la anterior por seguridad)
            // Guardar URL de redirección ANTES de invalidar la sesión
            String savedRedirectURL = (String) session.getAttribute("redirectAfterLogin");

            session.invalidate();
            session = req.getSession(true);
            session.setAttribute("usuario", usuario);
            // Guardar rol explícitamente para que el chatbot lo lea de forma fiable
            session.setAttribute("rol", usuario.isAdmin() ? "ADMIN" : "VOTANTE");
            // Restaurar la URL guardada antes del invalidate
            if (savedRedirectURL != null) {
                session.setAttribute("redirectAfterLogin", savedRedirectURL);
            }

            // Configurar timeout de sesión
            session.setMaxInactiveInterval(SESSION_TIMEOUT);

            // Si marcó "Recordarme", extender el tiempo de sesión
            if ("on".equals(rememberMe) || "true".equals(rememberMe)) {
                session.setMaxInactiveInterval(7 * 24 * 60 * 60); // 7 días
            }

            // Registrar fecha y hora de login
            LocalDateTime now = LocalDateTime.now();
            String loginTime = now.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
            session.setAttribute("loginTime", loginTime);
            session.setAttribute("sessionId", session.getId());

            // Registrar IP del cliente (para auditoría)
            String clientIP = getClientIP(req);
            session.setAttribute("clientIP", clientIP);

            // Actualizar último acceso en base de datos
            try {
                usuarioDAO.actualizarUltimoAcceso(usuario.getId());
            } catch (Exception e) {
                System.err.println("Error actualizando último acceso: " + e.getMessage());
            }

            // Limpiar la URL guardada y redirigir
            session.removeAttribute("redirectAfterLogin");

            // Si hay URL guardada y no es la página de login/logout, redirigir allí
            if (savedRedirectURL != null && !savedRedirectURL.isEmpty() &&
                    !savedRedirectURL.contains("/login") && !savedRedirectURL.contains("/logout")) {
                resp.sendRedirect(savedRedirectURL);
            } else {
                // Redirección por defecto según el rol
                redirectByRole(req, resp, usuario);
            }

        } else {
            // Login fallido - Incrementar contador de intentos
            loginAttempts = (loginAttempts == null) ? 1 : loginAttempts + 1;
            session.setAttribute("loginAttempts", loginAttempts);

            int remainingAttempts = MAX_LOGIN_ATTEMPTS - loginAttempts;

            if (remainingAttempts <= 0) {
                req.setAttribute("error",
                        "Has excedido el número máximo de intentos. Tu cuenta ha sido bloqueada temporalmente.");
            } else {
                req.setAttribute("error",
                        "Usuario o contraseña incorrectos. Te quedan " + remainingAttempts + " intento(s).");
            }

            // Mantener el username para no tener que volver a escribirlo
            req.setAttribute("lastUsername", username);

            req.getRequestDispatcher("/WEB-INF/vistas/login.jsp").forward(req, resp);
        }
    }

    /**
     * Redirige al usuario según su rol
     */
    private void redirectByRole(HttpServletRequest req, HttpServletResponse resp, Usuario usuario)
            throws IOException {

        String contextPath = req.getContextPath();

        if (usuario.isAdmin()) {
            resp.sendRedirect(contextPath + "/dashboard");
        } else if (usuario.isVotante()) {
            resp.sendRedirect(contextPath + "/dashboard");
        } else {
            resp.sendRedirect(contextPath + "/");
        }
    }

    /**
     * Obtiene la IP real del cliente (considerando proxies)
     */
    private String getClientIP(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");

        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }

        // Si hay múltiples IPs (cadena separada por comas), tomar la primera
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }

        return ip;
    }
}