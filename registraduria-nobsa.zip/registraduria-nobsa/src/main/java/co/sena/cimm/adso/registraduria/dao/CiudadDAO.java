package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.model.Ciudad;
import java.util.List;

public interface CiudadDAO {
    List<Ciudad> listarTodos() throws Exception;
    Ciudad buscarPorId(int id) throws Exception;
    Ciudad buscarPorCodigoDane(String codigoDane) throws Exception;
    boolean insertar(Ciudad ciudad) throws Exception;
    boolean actualizar(Ciudad ciudad) throws Exception;
    boolean eliminar(int id) throws Exception;
}