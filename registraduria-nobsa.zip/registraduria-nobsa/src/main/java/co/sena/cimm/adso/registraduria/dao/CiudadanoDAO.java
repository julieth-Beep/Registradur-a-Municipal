package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.model.Ciudadano;
import java.util.List;

public interface CiudadanoDAO {
    List<Ciudadano> listarTodos() throws Exception;
    Ciudadano buscarPorId(int id) throws Exception;
    Ciudadano buscarPorDocumento(String documento) throws Exception;
    Ciudadano buscarConZonaYMesa(String documento) throws Exception;
    boolean insertar(Ciudadano ciudadano) throws Exception;
    boolean actualizar(Ciudadano ciudadano) throws Exception;
    boolean eliminar(int id) throws Exception;
    boolean tieneDocs(int idCiudadano) throws Exception;
    int contarTotal() throws Exception;
    List<Ciudadano> buscarPorNombre(String nombre) throws Exception;
}