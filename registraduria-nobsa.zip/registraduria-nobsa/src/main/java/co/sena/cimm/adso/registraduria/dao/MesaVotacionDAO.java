package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.model.MesaVotacion;
import java.util.List;

public interface MesaVotacionDAO {
    List<MesaVotacion> listarTodos() throws Exception;
    List<MesaVotacion> listarPorZona(int idZona) throws Exception;
    MesaVotacion buscarPorId(int id) throws Exception;
    boolean insertar(MesaVotacion mesa) throws Exception;
    boolean actualizar(MesaVotacion mesa) throws Exception;
    boolean eliminar(int id) throws Exception;
}