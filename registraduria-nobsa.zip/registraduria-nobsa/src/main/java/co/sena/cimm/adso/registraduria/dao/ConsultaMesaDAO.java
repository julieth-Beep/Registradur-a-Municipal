package co.sena.cimm.adso.registraduria.dao;

import java.util.List;
import java.util.Map;

public interface ConsultaMesaDAO {
    
    Map<String, Object> buscarMesaPorDocumento(String numeroDocumento) throws Exception;
    
    List<Map<String, Object>> listarMesasPorZona(int idZona) throws Exception;
    
    List<Map<String, Object>> listarZonasPorCiudad(int idCiudad) throws Exception;
    
    List<Map<String, Object>> listarTodasCiudades() throws Exception;
}