package co.sena.cimm.adso.registraduria.servlet;

import co.sena.cimm.adso.registraduria.dao.MesaVotacionDAO;
import co.sena.cimm.adso.registraduria.dao.MesaVotacionDAOImpl;
import co.sena.cimm.adso.registraduria.dao.ZonaVotacionDAO;
import co.sena.cimm.adso.registraduria.dao.ZonaVotacionDAOImpl;
import co.sena.cimm.adso.registraduria.model.MesaVotacion;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/mesas")
public class MesaServlet extends HttpServlet {
    
    private MesaVotacionDAO mesaDAO;
    private ZonaVotacionDAO zonaDAO;
    
    @Override
    public void init() {
        mesaDAO = new MesaVotacionDAOImpl();
        zonaDAO = new ZonaVotacionDAOImpl();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        String action = req.getParameter("action");
        
        // ELIMINAR MESA
        if ("eliminar".equals(action)) {
            String idParam = req.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                int id = Integer.parseInt(idParam);
                
                try {
                    mesaDAO.eliminar(id);
                    req.getSession().setAttribute("success", "Mesa eliminada correctamente.");
                } catch (Exception e) {
                    // Si hay error, es porque tiene ciudadanos asignados
                    req.getSession().setAttribute("error", 
                        "No se puede eliminar: La mesa tiene ciudadanos asignados.");
                }
            }
            resp.sendRedirect(req.getContextPath() + "/admin/mesas");
            return;
        }
        
        // NUEVO
        if ("nuevo".equals(action)) {
            try {
                req.setAttribute("zonas", zonaDAO.listarTodos());
            } catch (Exception e) {
                e.printStackTrace();
            }
            req.getRequestDispatcher("/WEB-INF/vistas/admin/formMesa.jsp").forward(req, resp);
            return;
        }
        
        // EDITAR
        if ("editar".equals(action)) {
            String idParam = req.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                int id = Integer.parseInt(idParam);
                try {
                    MesaVotacion mesa = mesaDAO.buscarPorId(id);
                    req.setAttribute("mesa", mesa);
                    req.setAttribute("zonas", zonaDAO.listarTodos());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            req.getRequestDispatcher("/WEB-INF/vistas/admin/formMesa.jsp").forward(req, resp);
            return;
        }
        
        // LISTAR
        try {
            List<MesaVotacion> mesas = mesaDAO.listarTodos();
            req.setAttribute("mesas", mesas);
        } catch (Exception e) {
            e.printStackTrace();
        }
        req.getRequestDispatcher("/WEB-INF/vistas/admin/listaMesas.jsp").forward(req, resp);
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        
        try {
            MesaVotacion mesa = new MesaVotacion();
            
            String idParam = req.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                mesa.setId(Integer.parseInt(idParam));
            }
            
            mesa.setIdZona(Integer.parseInt(req.getParameter("idZona")));
            mesa.setNumeroMesa(Integer.parseInt(req.getParameter("numeroMesa")));
            
            String capacidadParam = req.getParameter("capacidad");
            if (capacidadParam != null && !capacidadParam.isEmpty()) {
                mesa.setCapacidad(Integer.parseInt(capacidadParam));
            }
            
            if (mesa.getId() == 0) {
                mesaDAO.insertar(mesa);
                req.getSession().setAttribute("success", "Mesa creada correctamente.");
            } else {
                mesaDAO.actualizar(mesa);
                req.getSession().setAttribute("success", "Mesa actualizada correctamente.");
            }
            
        } catch (Exception e) {
            req.getSession().setAttribute("error", "Error al guardar la mesa.");
            e.printStackTrace();
        }
        
        resp.sendRedirect(req.getContextPath() + "/admin/mesas");
    }
}