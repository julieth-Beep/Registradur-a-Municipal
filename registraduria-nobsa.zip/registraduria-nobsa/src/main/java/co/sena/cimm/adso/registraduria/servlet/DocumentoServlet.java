package co.sena.cimm.adso.registraduria.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import co.sena.cimm.adso.registraduria.dao.CiudadanoDAO;
import co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl;
import co.sena.cimm.adso.registraduria.dao.DocumentoDAO;
import co.sena.cimm.adso.registraduria.dao.DocumentoDAOImpl;
import co.sena.cimm.adso.registraduria.model.Ciudadano;
import co.sena.cimm.adso.registraduria.model.DocumentoExpedido;

@WebServlet("/documentos")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,
    maxFileSize = 5 * 1024 * 1024,
    maxRequestSize = 10 * 1024 * 1024
)
public class DocumentoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    
    private final DocumentoDAO dao = new DocumentoDAOImpl();
    private final CiudadanoDAO ciudadanoDAO = new CiudadanoDAOImpl();
    
    private static final Set<String> ALLOWED_EXTENSIONS = new HashSet<>(Arrays.asList(
        ".jpg", ".jpeg", ".png", ".gif", ".webp", ".pdf"
    ));
    
    private static final Set<String> ALLOWED_MIME_TYPES = new HashSet<>(Arrays.asList(
        "image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp", "application/pdf"
    ));

    private String getUploadDir() {
        String uploadPath = getServletContext().getRealPath("") + 
                           File.separator + "uploads" + File.separator + "documentos";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }
        return uploadPath;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        try {
            if ("editar".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                DocumentoExpedido d = dao.buscarPorId(id);
                req.setAttribute("documento", d);
                if (d != null) {
                    List<DocumentoExpedido> historial = dao.listarPorCiudadano(d.getIdCiudadano());
                    req.setAttribute("historial", historial);
                    Ciudadano ciudadano = ciudadanoDAO.buscarPorId(d.getIdCiudadano());
                    req.setAttribute("ciudadanoCargado", ciudadano);
                }
                req.getRequestDispatcher("/WEB-INF/vistas/documentos/formDocumento.jsp").forward(req, resp);

            } else if ("nuevo".equals(action)) {
                String numDoc = req.getParameter("numeroCiudadano");
                if (numDoc != null && !numDoc.trim().isEmpty()) {
                    Ciudadano c = ciudadanoDAO.buscarPorDocumento(numDoc.trim());
                    if (c != null) {
                        req.setAttribute("ciudadanoCargado", c);
                        List<DocumentoExpedido> historial = dao.listarPorCiudadano(c.getId());
                        req.setAttribute("historial", historial);
                    } else {
                        req.setAttribute("errorBusqueda", "No se encontro ciudadano: " + numDoc);
                    }
                }
                req.getRequestDispatcher("/WEB-INF/vistas/documentos/formDocumento.jsp").forward(req, resp);

            } else if ("buscarCiudadano".equals(action)) {
                resp.setContentType("application/json;charset=UTF-8");
                String numDoc = req.getParameter("numero");
                if (numDoc == null || numDoc.trim().isEmpty()) {
                    resp.getWriter().write("{\"error\":\"Ingrese un numero de documento\"}");
                    return;
                }
                Ciudadano c = ciudadanoDAO.buscarPorDocumento(numDoc.trim());
                if (c == null) {
                    resp.getWriter().write("{\"error\":\"Ciudadano no encontrado\"}");
                    return;
                }
                List<DocumentoExpedido> historial = dao.listarPorCiudadano(c.getId());
                StringBuilder json = new StringBuilder("{");
                json.append("\"id\":").append(c.getId()).append(",");
                json.append("\"nombres\":\"").append(esc(c.getNombres())).append("\",");
                json.append("\"apellidos\":\"").append(esc(c.getApellidos())).append("\",");
                json.append("\"numeroDocumento\":\"").append(esc(c.getNumeroDocumento())).append("\",");
                json.append("\"veredaBarrio\":\"").append(esc(c.getVeredaBarrio())).append("\",");
                json.append("\"historial\":[");
                boolean first = true;
                for (DocumentoExpedido d : historial) {
                    if (!first) json.append(",");
                    first = false;
                    json.append("{");
                    json.append("\"tipo\":\"").append(esc(d.getTipoDocumento())).append("\",");
                    json.append("\"serie\":\"").append(esc(d.getNumeroSerie())).append("\",");
                    json.append("\"expedicion\":\"").append(d.getFechaExpedicion()).append("\",");
                    json.append("\"vencimiento\":\"")
                            .append(d.getFechaVencimiento() != null ? d.getFechaVencimiento() : "").append("\",");
                    json.append("\"estado\":\"").append(esc(d.getEstado())).append("\"");
                    json.append("}");
                }
                json.append("]}");
                resp.getWriter().write(json.toString());

            } else if ("validarSerie".equals(action)) {
                resp.setContentType("application/json;charset=UTF-8");
                String numero = req.getParameter("numero");
                String excluirIdParam = req.getParameter("excluirId");
                int excluirId = 0;
                
                if (excluirIdParam != null && !excluirIdParam.isEmpty()) {
                    try {
                        excluirId = Integer.parseInt(excluirIdParam);
                    } catch (NumberFormatException e) {
                        excluirId = 0;
                    }
                }
                
                if (numero == null || numero.trim().isEmpty()) {
                    resp.getWriter().write("{\"existe\":false}");
                    return;
                }
                
                boolean existe = dao.existeNumeroSerie(numero.trim(), excluirId);
                resp.getWriter().write("{\"existe\":" + existe + "}");

            } else if ("eliminar".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                dao.eliminar(id);
                resp.sendRedirect(req.getContextPath() + "/documentos");

            } else if ("cambiarEstado".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                String estado = req.getParameter("estado");
                dao.cambiarEstado(id, estado);
                resp.sendRedirect(req.getContextPath() + "/documentos");

            } else if ("detalleCiudadano".equals(action)) {
                resp.setContentType("application/json;charset=UTF-8");
                int id = Integer.parseInt(req.getParameter("id"));
                Ciudadano c = ciudadanoDAO.buscarPorId(id);
                if (c == null) {
                    resp.getWriter().write("{\"error\":\"Ciudadano no encontrado\"}");
                    return;
                }
                List<DocumentoExpedido> docs = dao.listarPorCiudadano(id);

                StringBuilder json = new StringBuilder("{");
                json.append("\"id\":").append(c.getId()).append(",");
                json.append("\"nombres\":\"").append(esc(c.getNombres())).append("\",");
                json.append("\"apellidos\":\"").append(esc(c.getApellidos())).append("\",");
                json.append("\"numeroDocumento\":\"").append(esc(c.getNumeroDocumento())).append("\",");
                json.append("\"fechaNacimiento\":\"").append(c.getFechaNacimiento()).append("\",");
                json.append("\"veredaBarrio\":\"").append(esc(c.getVeredaBarrio())).append("\",");
                json.append("\"telefono\":\"").append(esc(c.getTelefono())).append("\",");
                json.append("\"correo\":\"").append(esc(c.getCorreo())).append("\",");
                
                // ══════════════════════════════════════════════════════════════
                // DOCUMENTOS CON IMAGEN/ARCHIVO
                // ══════════════════════════════════════════════════════════════
                json.append("\"documentos\":[");
                boolean first = true;
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                for (DocumentoExpedido d : docs) {
                    if (!first) json.append(",");
                    first = false;
                    json.append("{");
                    json.append("\"id\":").append(d.getId()).append(",");
                    json.append("\"tipo\":\"").append(esc(d.getTipoDocumento())).append("\",");
                    json.append("\"serie\":\"").append(esc(d.getNumeroSerie())).append("\",");
                    json.append("\"expedicion\":\"")
                            .append(d.getFechaExpedicion() != null ? sdf.format(d.getFechaExpedicion()) : "")
                            .append("\",");
                    json.append("\"vencimiento\":\"")
                            .append(d.getFechaVencimiento() != null ? sdf.format(d.getFechaVencimiento()) : "")
                            .append("\",");
                    json.append("\"estado\":\"").append(esc(d.getEstado())).append("\",");
                    
                    // Ruta de la imagen/archivo
                    String imagenDoc = d.getImagenDocumento() != null ? d.getImagenDocumento() : "";
                    json.append("\"imagen\":\"").append(esc(imagenDoc)).append("\",");
                    
                    // URL completa para acceso directo
                    if (!imagenDoc.isEmpty()) {
                        String imgUrl = req.getContextPath() + "/uploads/documentos/" + imagenDoc;
                        json.append("\"imagenUrl\":\"").append(esc(imgUrl)).append("\",");
                        // Determinar tipo de archivo
                        String ext = imagenDoc.substring(imagenDoc.lastIndexOf('.')).toLowerCase();
                        json.append("\"tipoArchivo\":\"").append(ext.equals(".pdf") ? "pdf" : "image").append("\"");
                    } else {
                        json.append("\"imagenUrl\":\"\",");
                        json.append("\"tipoArchivo\":\"\"");
                    }
                    json.append("}");
                }
                json.append("]}");
                resp.getWriter().write(json.toString());
                
            } else {
                List<DocumentoExpedido> lista = dao.listarTodos();
                List<DocumentoExpedido> recientes = dao.listarRecientes(6);
                Map<String, Integer> porTipo = dao.contarPorTipo();
                req.setAttribute("documentos", lista);
                req.setAttribute("recientes", recientes);
                req.setAttribute("porTipo", porTipo);
                req.getRequestDispatcher("/WEB-INF/vistas/documentos/listaDocumentos.jsp").forward(req, resp);
            }

        } catch (NumberFormatException e) {
            req.setAttribute("error", "ID de documento inválido");
            req.getRequestDispatcher("/WEB-INF/vistas/documentos/listaDocumentos.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Error en el servidor: " + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/vistas/documentos/listaDocumentos.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        try {
            DocumentoExpedido d = new DocumentoExpedido();

            String idParam = req.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                d.setId(Integer.parseInt(idParam));
            }

            String idCiudadanoParam = req.getParameter("idCiudadano");
            if (idCiudadanoParam == null || idCiudadanoParam.isEmpty() || "0".equals(idCiudadanoParam)) {
                req.setAttribute("error", "Debe seleccionar un ciudadano válido");
                req.getRequestDispatcher("/WEB-INF/vistas/documentos/formDocumento.jsp").forward(req, resp);
                return;
            }
            d.setIdCiudadano(Integer.parseInt(idCiudadanoParam));
            
            d.setTipoDocumento(req.getParameter("tipoDocumento"));
            
            String numeroSerie = req.getParameter("numeroSerie");
            if (numeroSerie == null || numeroSerie.trim().isEmpty()) {
                req.setAttribute("error", "El número de serie es obligatorio");
                mantenerDatosFormulario(req, d);
                req.getRequestDispatcher("/WEB-INF/vistas/documentos/formDocumento.jsp").forward(req, resp);
                return;
            }
            numeroSerie = numeroSerie.trim();
            d.setNumeroSerie(numeroSerie);
            
            boolean serieExiste = dao.existeNumeroSerie(numeroSerie, d.getId());
            if (serieExiste) {
                req.setAttribute("error", "El número de serie '" + numeroSerie + "' ya está registrado en el sistema");
                mantenerDatosFormulario(req, d);
                req.getRequestDispatcher("/WEB-INF/vistas/documentos/formDocumento.jsp").forward(req, resp);
                return;
            }
            
            d.setFechaExpedicion(Date.valueOf(req.getParameter("fechaExpedicion")));

            String fv = req.getParameter("fechaVencimiento");
            if (fv != null && !fv.isEmpty()) {
                d.setFechaVencimiento(Date.valueOf(fv));
            }

            d.setEstado(req.getParameter("estado"));
            d.setObservaciones(req.getParameter("observaciones"));

            Part imagenPart = null;
            try {
                imagenPart = req.getPart("imagenDocumento");
            } catch (IllegalStateException e) {
                System.err.println("Error al obtener part: " + e.getMessage());
            }
            
            if (imagenPart != null && imagenPart.getSize() > 0) {
                String contentType = imagenPart.getContentType();
                if (contentType != null && !ALLOWED_MIME_TYPES.contains(contentType.toLowerCase())) {
                    req.setAttribute("error", "Tipo de archivo no permitido: " + contentType);
                    mantenerDatosFormulario(req, d);
                    req.getRequestDispatcher("/WEB-INF/vistas/documentos/formDocumento.jsp").forward(req, resp);
                    return;
                }
                
                String nombreArchivo = guardarImagen(imagenPart, d.getIdCiudadano());
                if (nombreArchivo != null) {
                    d.setImagenDocumento(nombreArchivo);
                } else {
                    req.setAttribute("error", "Error al guardar el archivo. Intente de nuevo.");
                    mantenerDatosFormulario(req, d);
                    req.getRequestDispatcher("/WEB-INF/vistas/documentos/formDocumento.jsp").forward(req, resp);
                    return;
                }
            } else if (d.getId() > 0) {
                DocumentoExpedido anterior = dao.buscarPorId(d.getId());
                if (anterior != null && anterior.getImagenDocumento() != null) {
                    d.setImagenDocumento(anterior.getImagenDocumento());
                }
            }

            if (d.getId() == 0) {
                List<DocumentoExpedido> anteriores = dao.listarPorCiudadano(d.getIdCiudadano());
                for (DocumentoExpedido ant : anteriores) {
                    if (ant.getTipoDocumento().equals(d.getTipoDocumento())
                            && "vigente".equals(ant.getEstado())) {
                        dao.cambiarEstado(ant.getId(), "reemplazado");
                    }
                }
                dao.insertar(d);
            } else {
                dao.actualizar(d);
            }

            resp.sendRedirect(req.getContextPath() + "/documentos?success=" + 
                (d.getId() == 0 ? "creado" : "actualizado"));

        } catch (IllegalArgumentException e) {
            req.setAttribute("error", "Datos inválidos: " + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/vistas/documentos/formDocumento.jsp").forward(req, resp);
        } catch (org.postgresql.util.PSQLException e) {
            if (e.getMessage().contains("llave duplicada") || e.getMessage().contains("duplicate key")) {
                req.setAttribute("error", "El número de serie ya existe en el sistema. Por favor use uno diferente.");
            } else {
                e.printStackTrace();
                req.setAttribute("error", "Error de base de datos: " + e.getMessage());
            }
            req.getRequestDispatcher("/WEB-INF/vistas/documentos/formDocumento.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Error guardando documento: " + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/vistas/documentos/formDocumento.jsp").forward(req, resp);
        }
    }

    private void mantenerDatosFormulario(HttpServletRequest req, DocumentoExpedido d) {
        req.setAttribute("documento", d);
        if (d.getIdCiudadano() > 0) {
            try {
                Ciudadano c = ciudadanoDAO.buscarPorId(d.getIdCiudadano());
                req.setAttribute("ciudadanoCargado", c);
                List<DocumentoExpedido> historial = dao.listarPorCiudadano(d.getIdCiudadano());
                req.setAttribute("historial", historial);
            } catch (Exception e) {
                System.err.println("Error cargando datos del ciudadano: " + e.getMessage());
            }
        }
    }

    private String guardarImagen(Part part, int idCiudadano) throws IOException {
        String uploadDir = getUploadDir();
        File dir = new File(uploadDir);
        if (!dir.exists() && !dir.mkdirs()) {
            System.err.println("No se pudo crear directorio: " + uploadDir);
            return null;
        }
        if (!dir.canWrite()) {
            System.err.println("Directorio no escribible: " + uploadDir);
            return null;
        }

        String nombreOriginal = getFileName(part);
        String extension = "";
        
        if (nombreOriginal != null && !nombreOriginal.isEmpty()) {
            int punto = nombreOriginal.lastIndexOf('.');
            if (punto >= 0 && punto < nombreOriginal.length() - 1) {
                extension = nombreOriginal.substring(punto).toLowerCase();
            }
        }
        
        if (extension.isEmpty() || !ALLOWED_EXTENSIONS.contains(extension)) {
            String contentType = part.getContentType();
            if (contentType != null) {
                if (contentType.contains("jpeg") || contentType.contains("jpg")) {
                    extension = ".jpg";
                } else if (contentType.contains("png")) {
                    extension = ".png";
                } else if (contentType.contains("gif")) {
                    extension = ".gif";
                } else if (contentType.contains("webp")) {
                    extension = ".webp";
                } else if (contentType.contains("pdf")) {
                    extension = ".pdf";
                } else {
                    extension = ".jpg";
                }
            } else {
                extension = ".jpg";
            }
        }

        String nombreArchivo = "doc_" + idCiudadano + "_" + 
                               System.currentTimeMillis() + "_" + 
                               UUID.randomUUID().toString().substring(0, 6) + 
                               extension;
        
        String rutaCompleta = uploadDir + File.separator + nombreArchivo;

        try (InputStream input = part.getInputStream();
             FileOutputStream output = new FileOutputStream(rutaCompleta)) {
            
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
            output.flush();
            
        } catch (IOException e) {
            System.err.println("Error guardando archivo: " + e.getMessage());
            File archivoParcial = new File(rutaCompleta);
            if (archivoParcial.exists()) {
                archivoParcial.delete();
            }
            return null;
        }
        
        File archivoGuardado = new File(rutaCompleta);
        if (!archivoGuardado.exists() || archivoGuardado.length() == 0) {
            System.err.println("Archivo no se guardó correctamente: " + rutaCompleta);
            return null;
        }
        
        return nombreArchivo;
    }

    private String getFileName(Part part) {
        if (part == null) return null;
        
        String contentDisposition = part.getHeader("content-disposition");
        if (contentDisposition == null || contentDisposition.isEmpty()) {
            return null;
        }

        for (String token : contentDisposition.split(";")) {
            token = token.trim();
            if (token.toLowerCase().startsWith("filename")) {
                int eqIndex = token.indexOf('=');
                if (eqIndex == -1) continue;
                
                String filename = token.substring(eqIndex + 1).trim();
                
                if (filename.startsWith("\"") && filename.endsWith("\"") && filename.length() > 1) {
                    filename = filename.substring(1, filename.length() - 1);
                }
                
                filename = filename.replaceAll("[^a-zA-Z0-9._\\-]", "_");
                
                return filename.isEmpty() ? null : filename;
            }
        }
        return null;
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "")
                .replace("\n", "")
                .replace("\t", "");
    }
}