package co.sena.cimm.adso.registraduria.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import co.sena.cimm.adso.registraduria.dao.CiudadanoDAO;
import co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl;
import co.sena.cimm.adso.registraduria.model.Ciudadano;

@WebServlet("/consulta-mesa")
public class ConsultaMesaServlet extends HttpServlet {

    private CiudadanoDAO ciudadanoDAO;

    private static final String SECRET_KEY = "6LdK8cAsAAAAAOuiYcQDscwsaIuQvwL9bW8jCCnZ";
    private static final String RECAPTCHA_VERIFY_URL = "https://www.google.com/recaptcha/api/siteverify";

    @Override
    public void init() {
        ciudadanoDAO = new CiudadanoDAOImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String documento = req.getParameter("documento");
        String recaptchaToken = req.getParameter("g-recaptcha-response");

        if (documento != null && !documento.trim().isEmpty()) {

            // Validar reCAPTCHA primero
            if (recaptchaToken == null || recaptchaToken.isEmpty()) {
                req.setAttribute("error", "Por favor completa la verificación reCAPTCHA.");
                req.setAttribute("busquedaRealizada", true);
                req.getRequestDispatcher("/WEB-INF/vistas/consulta/consultaMesa.jsp").forward(req, resp);
                return;
            }

            if (!verificarRecaptcha(recaptchaToken)) {
                req.setAttribute("error", "Verificación reCAPTCHA fallida. Por favor inténtalo de nuevo.");
                req.setAttribute("busquedaRealizada", true);
                req.getRequestDispatcher("/WEB-INF/vistas/consulta/consultaMesa.jsp").forward(req, resp);
                return;
            }

            // reCAPTCHA OK → proceder con la consulta
            try {
                Ciudadano ciudadano = ciudadanoDAO.buscarConZonaYMesa(documento.trim());

                if (ciudadano != null) {
                    if (ciudadano.getIdMesa() != null && ciudadano.getIdMesa() > 0) {
                        req.setAttribute("resultado", ciudadano);
                        req.setAttribute("tieneMesa", true);
                    } else {
                        req.setAttribute("ciudadano", ciudadano);
                        req.setAttribute("tieneMesa", false);
                        req.setAttribute("mensaje",
                            "Este ciudadano no está inscrito en ninguna mesa de votación.");
                    }
                } else {
                    req.setAttribute("error",
                        "No se encontró un ciudadano con el documento: " + documento);
                }
            } catch (Exception e) {
                e.printStackTrace();
                req.setAttribute("error", "Error en la consulta: " + e.getMessage());
            }
        }

        req.setAttribute("busquedaRealizada", documento != null && !documento.trim().isEmpty());
        req.getRequestDispatcher("/WEB-INF/vistas/consulta/consultaMesa.jsp").forward(req, resp);
    }

    /**
     * Verifica el token reCAPTCHA contra la API de Google.
     */
    private boolean verificarRecaptcha(String token) {
        try {
            URL url = new URL(RECAPTCHA_VERIFY_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            String params = "secret=" + SECRET_KEY + "&response=" + token;
            try (OutputStream os = conn.getOutputStream()) {
                os.write(params.getBytes(StandardCharsets.UTF_8));
            }

            StringBuilder response = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    response.append(line);
                }
            }

            JSONObject json = new JSONObject(response.toString());
            return json.getBoolean("success");

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}