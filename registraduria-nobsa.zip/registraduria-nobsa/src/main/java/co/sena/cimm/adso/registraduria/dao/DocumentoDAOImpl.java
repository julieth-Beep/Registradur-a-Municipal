package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.config.ConexionDB;
import co.sena.cimm.adso.registraduria.model.DocumentoExpedido;
import java.sql.*;
import java.util.*;

public class DocumentoDAOImpl implements DocumentoDAO {

    // ══════════════════════════════════════════════════════════════
    // LISTAR TODOS
    // ══════════════════════════════════════════════════════════════
    @Override
    public List<DocumentoExpedido> listarTodos() throws Exception {
        List<DocumentoExpedido> lista = new ArrayList<>();
        String sql = "SELECT d.*, c.nombres, c.apellidos, c.numero_documento " +
                "FROM documentos_expedidos d " +
                "INNER JOIN ciudadanos c ON d.id_ciudadano = c.id " +
                "ORDER BY d.fecha_expedicion DESC";
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {
            while (rs.next())
                lista.add(mapear(rs));
        }
        return lista;
    }

    // ══════════════════════════════════════════════════════════════
    // LISTAR POR CIUDADANO — historial completo ordenado por fecha
    // ══════════════════════════════════════════════════════════════
    @Override
    public List<DocumentoExpedido> listarPorCiudadano(int idCiudadano) throws Exception {
        List<DocumentoExpedido> lista = new ArrayList<>();
        String sql = "SELECT d.*, c.nombres, c.apellidos, c.numero_documento " +
                "FROM documentos_expedidos d " +
                "INNER JOIN ciudadanos c ON d.id_ciudadano = c.id " +
                "WHERE d.id_ciudadano = ? " +
                "ORDER BY d.fecha_expedicion ASC";
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCiudadano);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next())
                    lista.add(mapear(rs));
            }
        }
        return lista;
    }

    // ══════════════════════════════════════════════════════════════
    // LISTAR RECIENTES — para el panel de actividad
    // ══════════════════════════════════════════════════════════════
    @Override
    public List<DocumentoExpedido> listarRecientes(int limite) throws Exception {
        List<DocumentoExpedido> lista = new ArrayList<>();
        String sql = "SELECT d.*, c.nombres, c.apellidos, c.numero_documento " +
                "FROM documentos_expedidos d " +
                "INNER JOIN ciudadanos c ON d.id_ciudadano = c.id " +
                "ORDER BY d.id DESC LIMIT ?";
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, limite);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next())
                    lista.add(mapear(rs));
            }
        }
        return lista;
    }

    // ══════════════════════════════════════════════════════════════
    // BUSCAR POR ID
    // ══════════════════════════════════════════════════════════════
    @Override
    public DocumentoExpedido buscarPorId(int id) throws Exception {
        String sql = "SELECT d.*, c.nombres, c.apellidos, c.numero_documento " +
                "FROM documentos_expedidos d " +
                "INNER JOIN ciudadanos c ON d.id_ciudadano = c.id " +
                "WHERE d.id = ?";
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next())
                    return mapear(rs);
            }
        }
        return null;
    }

    // ══════════════════════════════════════════════════════════════
    // BUSCAR POR NUMERO SERIE
    // ══════════════════════════════════════════════════════════════
    @Override
    public DocumentoExpedido buscarPorNumeroSerie(String numeroSerie) throws Exception {
        String sql = "SELECT d.*, c.nombres, c.apellidos, c.numero_documento " +
                "FROM documentos_expedidos d " +
                "INNER JOIN ciudadanos c ON d.id_ciudadano = c.id " +
                "WHERE d.numero_serie = ?";
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, numeroSerie);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next())
                    return mapear(rs);
            }
        }
        return null;
    }

    // ══════════════════════════════════════════════════════════════
    // BUSCAR POR NÚMERO DE DOCUMENTO DEL CIUDADANO
    // Devuelve todos los documentos que tiene ese ciudadano
    // ══════════════════════════════════════════════════════════════
    @Override
    public List<DocumentoExpedido> buscarPorNumeroCiudadano(String numeroCiudadano) throws Exception {
        List<DocumentoExpedido> lista = new ArrayList<>();
        String sql = "SELECT d.*, c.nombres, c.apellidos, c.numero_documento " +
                "FROM documentos_expedidos d " +
                "INNER JOIN ciudadanos c ON d.id_ciudadano = c.id " +
                "WHERE c.numero_documento = ? " +
                "ORDER BY d.fecha_expedicion ASC";
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, numeroCiudadano);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next())
                    lista.add(mapear(rs));
            }
        }
        return lista;
    }

    // ══════════════════════════════════════════════════════════════
    // VALIDAR EXISTENCIA DE NÚMERO DE SERIE (NUEVO MÉTODO)
    // ══════════════════════════════════════════════════════════════
    @Override
    public boolean existeNumeroSerie(String numeroSerie, int excluirId) throws Exception {
        boolean existe = false;
        String sql = "SELECT COUNT(*) FROM documentos_expedidos WHERE numero_serie = ?";
        
        if (excluirId > 0) {
            sql += " AND id != ?";
        }
        
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, numeroSerie);
            
            if (excluirId > 0) {
                stmt.setInt(2, excluirId);
            }
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    existe = rs.getInt(1) > 0;
                }
            }
        }
        return existe;
    }

    // ══════════════════════════════════════════════════════════════
    // INSERTAR — incluye imagen_documento
    // ══════════════════════════════════════════════════════════════
    @Override
    public boolean insertar(DocumentoExpedido documento) throws Exception {
        String sql = "INSERT INTO documentos_expedidos " +
                "(id_ciudadano, tipo_documento, numero_serie, fecha_expedicion, " +
                "fecha_vencimiento, estado, observaciones, imagen_documento) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, documento.getIdCiudadano());
            stmt.setString(2, documento.getTipoDocumento());
            stmt.setString(3, documento.getNumeroSerie());
            stmt.setDate(4, new java.sql.Date(documento.getFechaExpedicion().getTime()));
            if (documento.getFechaVencimiento() != null)
                stmt.setDate(5, new java.sql.Date(documento.getFechaVencimiento().getTime()));
            else
                stmt.setNull(5, Types.DATE);
            stmt.setString(6, documento.getEstado() != null ? documento.getEstado() : "vigente");
            stmt.setString(7, documento.getObservaciones());
            stmt.setString(8, documento.getImagenDocumento());
            return stmt.executeUpdate() > 0;
        }
    }

    // ══════════════════════════════════════════════════════════════
    // ACTUALIZAR — incluye imagen_documento
    // ══════════════════════════════════════════════════════════════
    @Override
    public boolean actualizar(DocumentoExpedido documento) throws Exception {
        String sql = "UPDATE documentos_expedidos SET tipo_documento=?, numero_serie=?, " +
                "fecha_expedicion=?, fecha_vencimiento=?, estado=?, observaciones=?, imagen_documento=? " +
                "WHERE id=?";
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, documento.getTipoDocumento());
            stmt.setString(2, documento.getNumeroSerie());
            stmt.setDate(3, new java.sql.Date(documento.getFechaExpedicion().getTime()));
            if (documento.getFechaVencimiento() != null)
                stmt.setDate(4, new java.sql.Date(documento.getFechaVencimiento().getTime()));
            else
                stmt.setNull(4, Types.DATE);
            stmt.setString(5, documento.getEstado());
            stmt.setString(6, documento.getObservaciones());
            stmt.setString(7, documento.getImagenDocumento());
            stmt.setInt(8, documento.getId());
            return stmt.executeUpdate() > 0;
        }
    }

    // ══════════════════════════════════════════════════════════════
    // ELIMINAR
    // ══════════════════════════════════════════════════════════════
    @Override
    public boolean eliminar(int id) throws Exception {
        String sql = "DELETE FROM documentos_expedidos WHERE id=?";
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    // ══════════════════════════════════════════════════════════════
    // CAMBIAR ESTADO
    // ══════════════════════════════════════════════════════════════
    @Override
    public boolean cambiarEstado(int id, String estado) throws Exception {
        String sql = "UPDATE documentos_expedidos SET estado=? WHERE id=?";
        try (Connection conn = ConexionDB.getConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, estado);
            stmt.setInt(2, id);
            return stmt.executeUpdate() > 0;
        }
    }

    // ══════════════════════════════════════════════════════════════
    // CONTAR TOTAL
    // ══════════════════════════════════════════════════════════════
    @Override
    public int contarTotal() throws Exception {
        String sql = "SELECT COUNT(*) FROM documentos_expedidos";
        try (Connection conn = ConexionDB.getConexion();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next())
                return rs.getInt(1);
        }
        return 0;
    }

    // ══════════════════════════════════════════════════════════════
    // CONTAR POR TIPO — para las cards del listado
    // ══════════════════════════════════════════════════════════════
    @Override
    public Map<String, Integer> contarPorTipo() throws Exception {
        Map<String, Integer> mapa = new LinkedHashMap<String, Integer>();

        // Inicializar todos los tipos con 0
        mapa.put("Cedula de Ciudadania", 0);
        mapa.put("Tarjeta de Identidad", 0);
        mapa.put("Registro Civil de Nacimiento", 0);
        mapa.put("Cedula de Extranjeria", 0);

        String sql = "SELECT tipo_documento, COUNT(*) as total FROM documentos_expedidos GROUP BY tipo_documento";

        try (Connection conn = ConexionDB.getConexion();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String tipo = rs.getString("tipo_documento");
                int total = rs.getInt("total");

                // Normalizar nombres
                if (tipo != null) {
                    if (tipo.contains("Cedula") && tipo.contains("Ciudadania")) {
                        mapa.put("Cedula de Ciudadania", total);
                    } else if (tipo.contains("Tarjeta")) {
                        mapa.put("Tarjeta de Identidad", total);
                    } else if (tipo.contains("Registro")) {
                        mapa.put("Registro Civil de Nacimiento", total);
                    } else if (tipo.contains("Extranjeria")) {
                        mapa.put("Cedula de Extranjeria", total);
                    }
                }
            }
        }
        return mapa;
    }

    // ══════════════════════════════════════════════════════════════
    // MAPEO INTERNO
    // ══════════════════════════════════════════════════════════════
    private DocumentoExpedido mapear(ResultSet rs) throws SQLException {
        DocumentoExpedido d = new DocumentoExpedido();
        d.setId(rs.getInt("id"));
        d.setIdCiudadano(rs.getInt("id_ciudadano"));
        d.setTipoDocumento(rs.getString("tipo_documento"));
        d.setNumeroSerie(rs.getString("numero_serie"));
        d.setFechaExpedicion(rs.getDate("fecha_expedicion"));
        d.setFechaVencimiento(rs.getDate("fecha_vencimiento"));
        d.setEstado(rs.getString("estado"));
        d.setObservaciones(rs.getString("observaciones"));
        // imagen_documento puede no existir en BD antigua — manejar gracefully
        try {
            d.setImagenDocumento(rs.getString("imagen_documento"));
        } catch (SQLException e) {
            d.setImagenDocumento(null);
        }
        d.setNombresCiudadano(rs.getString("nombres"));
        d.setApellidosCiudadano(rs.getString("apellidos"));
        d.setNumeroDocumento(rs.getString("numero_documento"));
        return d;
    }
}