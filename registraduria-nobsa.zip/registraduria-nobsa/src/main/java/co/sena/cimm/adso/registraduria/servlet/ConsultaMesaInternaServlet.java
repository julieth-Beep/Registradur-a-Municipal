package co.sena.cimm.adso.registraduria.servlet;

import co.sena.cimm.adso.registraduria.dao.CiudadanoDAO;
import co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl;
import co.sena.cimm.adso.registraduria.model.Ciudadano;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/consulta-mesa-interna")
public class ConsultaMesaInternaServlet extends HttpServlet {
    
    private final CiudadanoDAO ciudadanoDAO = new CiudadanoDAOImpl();
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        String documento = req.getParameter("documento");
        
        // Solo procesar búsqueda si viene el parámetro (para admin)
        if (documento != null && !documento.trim().isEmpty()) {
            try {
                Ciudadano ciudadano = ciudadanoDAO.buscarConZonaYMesa(documento.trim());
                
                if (ciudadano != null) {
                    req.setAttribute("resultado", ciudadano);
                    req.setAttribute("tieneMesa", ciudadano.getIdMesa() != null && ciudadano.getIdMesa() > 0);
                    if (ciudadano.getIdMesa() == null || ciudadano.getIdMesa() == 0) {
                        req.setAttribute("mensaje", "Este ciudadano no está inscrito en ninguna mesa de votación.");
                    }
                } else {
                    req.setAttribute("error", "No se encontró un ciudadano con el documento: " + documento);
                }
            } catch (Exception e) {
                req.setAttribute("error", "Error en la consulta: " + e.getMessage());
            }
        }
        
        req.getRequestDispatcher("/WEB-INF/vistas/consultaMesaInterna.jsp").forward(req, resp);
    }
}