package co.sena.cimm.adso.registraduria.filter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import co.sena.cimm.adso.registraduria.model.Usuario;

@WebFilter("/*")  // Intercepta TODAS las peticiones
public class AuthFilter implements Filter {
    
    // Rutas públicas que NO requieren autenticación
    private static final List<String> PUBLIC_PATHS = Arrays.asList(
        "/",
        "/index.jsp",
        "/login",
        "/logout",
        "/registro-votante",
        "/consulta-mesa",
        "/chatbot",
        "/js/",
        "/error",
        "/css/",
        "/fonts/",
        "/images/",
        "/favicon.ico"
    );
    
    // Rutas que requieren autenticación (cualquier usuario logueado)
    private static final List<String> PROTECTED_PATHS = Arrays.asList(
        "/ciudadanos",
        "/documentos",
        "/perfil"
    );
    
    // Rutas que requieren rol de ADMINISTRADOR
    private static final List<String> ADMIN_PATHS = Arrays.asList(
        "/admin/",
        "/admin/dashboard",
        "/admin/ciudades",
        "/admin/zonas",
        "/admin/mesas",
        "/admin/usuarios"
    );
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        String path = httpRequest.getRequestURI().substring(httpRequest.getContextPath().length());
        String method = httpRequest.getMethod();
        
        if ("OPTIONS".equalsIgnoreCase(method)) {
            chain.doFilter(request, response);
            return;
        }
        
        if (isPublicPath(path)) {
            chain.doFilter(request, response);
            return;
        }
        
        HttpSession session = httpRequest.getSession(false);
        Usuario usuario = (session != null) ? (Usuario) session.getAttribute("usuario") : null;
        
        if (usuario == null) {
            String originalURL = httpRequest.getRequestURI();
            String queryString = httpRequest.getQueryString();
            if (queryString != null) {
                originalURL += "?" + queryString;
            }
            httpRequest.getSession().setAttribute("redirectAfterLogin", originalURL);
            
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
            return;
        }
        
        if (!usuario.isActivo()) {
            session.invalidate();
            httpRequest.setAttribute("error", "Su cuenta ha sido desactivada. Contacte al administrador.");
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
            return;
        }
        
        if (isAdminPath(path) && !usuario.isAdmin()) {
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN, 
                "Acceso denegado. Se requieren permisos de administrador.");
            return;
        }
        
        if (isProtectedPath(path)) {
            chain.doFilter(request, response);
            return;
        }
        
        chain.doFilter(request, response);
    }
    
    private boolean isPublicPath(String path) {
        if (path == null || path.isEmpty() || "/".equals(path)) {
            return true;
        }
        
        for (String publicPath : PUBLIC_PATHS) {
            if (path.startsWith(publicPath)) {
                return true;
            }
        }
        
        if (path.endsWith(".css") || path.endsWith(".js") || 
            path.endsWith(".jpg") || path.endsWith(".png") || 
            path.endsWith(".gif") || path.endsWith(".svg") ||
            path.endsWith(".ico") || path.endsWith(".woff") ||
            path.endsWith(".woff2") || path.endsWith(".ttf")) {
            return true;
        }
        
        return false;
    }
    
    private boolean isProtectedPath(String path) {
        for (String protectedPath : PROTECTED_PATHS) {
            if (path.startsWith(protectedPath)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isAdminPath(String path) {
        for (String adminPath : ADMIN_PATHS) {
            if (path.startsWith(adminPath)) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public void destroy() {
        // Limpieza si es necesaria
    }
}