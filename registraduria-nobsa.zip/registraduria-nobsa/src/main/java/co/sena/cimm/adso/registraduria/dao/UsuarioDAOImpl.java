package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.config.ConexionDB;
import co.sena.cimm.adso.registraduria.model.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAOImpl implements UsuarioDAO {
    
    @Override
    public Usuario login(String username, String password) {
        String sql = "SELECT u.*, c.nombres, c.apellidos FROM usuarios u " +
                    "INNER JOIN ciudadanos c ON u.documento = c.numero_documento " +
                    "WHERE u.username = ? AND u.contraseña = ? AND u.estado = 'activo'";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            stmt.setString(2, password);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setId(rs.getInt("id"));
                    usuario.setUsername(rs.getString("username"));
                    usuario.setDocumento(rs.getString("documento"));
                    usuario.setTipoUsuario(rs.getString("tipo_usuario"));
                    usuario.setEstado(rs.getString("estado"));
                    usuario.setFechaRegistro(rs.getTimestamp("fecha_registro"));
                    usuario.setNombres(rs.getString("nombres"));
                    usuario.setApellidos(rs.getString("apellidos"));
                    
                    actualizarUltimoAcceso(usuario.getId());
                    return usuario;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public boolean registrar(Usuario usuario) {
        String sql = "INSERT INTO usuarios (username, documento, contraseña, tipo_usuario) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, usuario.getUsername());
            stmt.setString(2, usuario.getDocumento());
            stmt.setString(3, usuario.getContraseña());
            stmt.setString(4, usuario.getTipoUsuario());
            
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public Usuario buscarPorUsername(String username) {
        String sql = "SELECT u.*, c.nombres, c.apellidos FROM usuarios u " +
                    "INNER JOIN ciudadanos c ON u.documento = c.numero_documento " +
                    "WHERE u.username = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setId(rs.getInt("id"));
                    usuario.setUsername(rs.getString("username"));
                    usuario.setDocumento(rs.getString("documento"));
                    usuario.setTipoUsuario(rs.getString("tipo_usuario"));
                    usuario.setEstado(rs.getString("estado"));
                    usuario.setNombres(rs.getString("nombres"));
                    usuario.setApellidos(rs.getString("apellidos"));
                    return usuario;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public Usuario buscarPorDocumento(String documento) {
        String sql = "SELECT u.*, c.nombres, c.apellidos FROM usuarios u " +
                    "INNER JOIN ciudadanos c ON u.documento = c.numero_documento " +
                    "WHERE u.documento = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, documento);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setId(rs.getInt("id"));
                    usuario.setUsername(rs.getString("username"));
                    usuario.setDocumento(rs.getString("documento"));
                    usuario.setTipoUsuario(rs.getString("tipo_usuario"));
                    usuario.setEstado(rs.getString("estado"));
                    usuario.setNombres(rs.getString("nombres"));
                    usuario.setApellidos(rs.getString("apellidos"));
                    return usuario;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public Usuario buscarPorId(int id) {
        String sql = "SELECT u.*, c.nombres, c.apellidos FROM usuarios u " +
                    "INNER JOIN ciudadanos c ON u.documento = c.numero_documento " +
                    "WHERE u.id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setId(rs.getInt("id"));
                    usuario.setUsername(rs.getString("username"));
                    usuario.setDocumento(rs.getString("documento"));
                    usuario.setTipoUsuario(rs.getString("tipo_usuario"));
                    usuario.setEstado(rs.getString("estado"));
                    usuario.setNombres(rs.getString("nombres"));
                    usuario.setApellidos(rs.getString("apellidos"));
                    return usuario;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public boolean ciudadanoExiste(String documento) {
        String sql = "SELECT COUNT(*) FROM ciudadanos WHERE numero_documento = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, documento);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    @Override
    public List<Usuario> listarTodos() {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT u.*, c.nombres, c.apellidos FROM usuarios u " +
                    "INNER JOIN ciudadanos c ON u.documento = c.numero_documento " +
                    "ORDER BY u.fecha_registro DESC";
        
        try (Connection conn = ConexionDB.getConexion();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("id"));
                usuario.setUsername(rs.getString("username"));
                usuario.setDocumento(rs.getString("documento"));
                usuario.setTipoUsuario(rs.getString("tipo_usuario"));
                usuario.setEstado(rs.getString("estado"));
                usuario.setFechaRegistro(rs.getTimestamp("fecha_registro"));
                usuario.setUltimoAcceso(rs.getTimestamp("ultimo_acceso"));
                usuario.setNombres(rs.getString("nombres"));
                usuario.setApellidos(rs.getString("apellidos"));
                usuarios.add(usuario);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return usuarios;
    }
    
    @Override
    public boolean actualizarEstado(int id, String estado) {
        String sql = "UPDATE usuarios SET estado = ? WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, estado);
            stmt.setInt(2, id);
            
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean actualizarUltimoAcceso(int id) {
        String sql = "UPDATE usuarios SET ultimo_acceso = CURRENT_TIMESTAMP WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean eliminar(int id) {
        String sql = "DELETE FROM usuarios WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean actualizar(Usuario usuario) {
        String sql = "UPDATE usuarios SET username = ?, tipo_usuario = ?, estado = ? WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, usuario.getUsername());
            stmt.setString(2, usuario.getTipoUsuario());
            stmt.setString(3, usuario.getEstado());
            stmt.setInt(4, usuario.getId());
            
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}