package co.sena.cimm.adso.registraduria.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import co.sena.cimm.adso.registraduria.config.ConexionDB;
import co.sena.cimm.adso.registraduria.model.Usuario;

@WebServlet("/chatbot")
public class ChatbotServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json;charset=UTF-8");
        response.setHeader("Cache-Control", "no-cache");
        response.setHeader("Access-Control-Allow-Origin", "*");

        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession(false);
        Usuario usuario = (session != null) ? (Usuario) session.getAttribute("usuario") : null;

        // Respaldo: si por alguna razón el objeto Usuario no está pero sí el rol string
        String rolSesion = (session != null) ? (String) session.getAttribute("rol") : null;

        String accion = request.getParameter("accion");
        if (accion == null) accion = "";

        try {
            switch (accion) {
                case "obtener_rol":
                    out.print(getRolUsuario(usuario, rolSesion));
                    break;
                case "stats_generales":
                    out.print(getStatsGenerales(usuario));
                    break;
                case "ciudadanos_sin_mesa":
                    out.print(getCiudadanosSinMesa(usuario));
                    break;
                case "resumen_mesas":
                    out.print(getResumenMesas(usuario));
                    break;
                default:
                    out.print("{\"success\":false,\"error\":\"Accion no reconocida\"}");
            }
        } catch (Exception e) {
            response.setStatus(500);
            out.print("{\"success\":false,\"error\":\"" + escJson(e.getMessage()) + "\"}");
        }
    }

    // ── ROL DEL USUARIO ──────────────────────────────────────────
    private String getRolUsuario(Usuario usuario, String rolSesion) {
        // Si no hay objeto usuario, intentar usar el atributo "rol" de sesión como respaldo
        if (usuario == null) {
            if ("ADMIN".equalsIgnoreCase(rolSesion)) {
                return "{\"rol\":\"admin\",\"nombre\":\"\"}";
            } else if ("VOTANTE".equalsIgnoreCase(rolSesion)) {
                return "{\"rol\":\"votante\",\"nombre\":\"\"}";
            }
            return "{\"rol\":\"invitado\",\"nombre\":\"\"}";
        }

        // Determinar rol a partir del método isAdmin()
        String rol;
        String nombre = "";
        
        if (usuario.isAdmin()) {
            rol = "admin";
        } else if (usuario.isVotante()) {
            rol = "votante";
        } else {
            rol = "invitado";
        }

        nombre = usuario.getNombres() != null && !usuario.getNombres().isEmpty()
                ? usuario.getNombres()
                : usuario.getUsername();
        
        return "{\"rol\":\"" + rol + "\",\"nombre\":\"" + escJson(nombre) + "\"}";
    }

    // ── ESTADÍSTICAS GENERALES (solo admin) ──────────────────────
    private String getStatsGenerales(Usuario usuario) {
        if (usuario == null || !usuario.isAdmin()) {
            return "{\"success\":false,\"error\":\"Acceso denegado\"}";
        }
        try (Connection cn = ConexionDB.getConexion()) {

            // Total ciudadanos
            long totalCiudadanos = 0;
            try (PreparedStatement ps = cn.prepareStatement("SELECT COUNT(*) FROM ciudadanos");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) totalCiudadanos = rs.getLong(1);
            }

            // Ciudadanos con mesa asignada
            long conMesa = 0;
            try (PreparedStatement ps = cn.prepareStatement("SELECT COUNT(*) FROM ciudadanos WHERE id_mesa IS NOT NULL");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) conMesa = rs.getLong(1);
            }

            // Total mesas
            long totalMesas = 0;
            try (PreparedStatement ps = cn.prepareStatement("SELECT COUNT(*) FROM mesas_votacion");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) totalMesas = rs.getLong(1);
            }

            // Total zonas
            long totalZonas = 0;
            try (PreparedStatement ps = cn.prepareStatement("SELECT COUNT(*) FROM zonas_votacion");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) totalZonas = rs.getLong(1);
            }

            // Total usuarios del sistema
            long totalUsuarios = 0;
            try (PreparedStatement ps = cn.prepareStatement("SELECT COUNT(*) FROM usuarios");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) totalUsuarios = rs.getLong(1);
            }

            long sinMesa = totalCiudadanos - conMesa;

            return "{\"success\":true"
                    + ",\"totalCiudadanos\":" + totalCiudadanos
                    + ",\"conMesa\":" + conMesa
                    + ",\"sinMesa\":" + sinMesa
                    + ",\"totalMesas\":" + totalMesas
                    + ",\"totalZonas\":" + totalZonas
                    + ",\"totalUsuarios\":" + totalUsuarios
                    + "}";

        } catch (Exception e) {
            return "{\"success\":false,\"error\":\"" + escJson(e.getMessage()) + "\"}";
        }
    }

    // ── CIUDADANOS SIN MESA ASIGNADA (admin) ─────────────────────
    private String getCiudadanosSinMesa(Usuario usuario) {
        if (usuario == null || !usuario.isAdmin()) {
            return "{\"success\":false,\"error\":\"Acceso denegado\"}";
        }
        try (Connection cn = ConexionDB.getConexion()) {

            long sinMesa = 0;
            try (PreparedStatement ps = cn.prepareStatement(
                    "SELECT COUNT(*) FROM ciudadanos WHERE id_mesa IS NULL");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) sinMesa = rs.getLong(1);
            }

            // Últimos 3 sin mesa
            StringBuilder detalle = new StringBuilder("[");
            String sqlDetalle = "SELECT nombres, apellidos, numero_documento FROM ciudadanos WHERE id_mesa IS NULL ORDER BY id DESC LIMIT 3";
            int cnt = 0;
            try (PreparedStatement ps = cn.prepareStatement(sqlDetalle);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    if (cnt > 0) detalle.append(",");
                    detalle.append("{\"nombre\":\"")
                           .append(escJson(rs.getString("nombres") + " " + rs.getString("apellidos")))
                           .append("\",\"documento\":\"")
                           .append(escJson(rs.getString("numero_documento")))
                           .append("\"}");
                    cnt++;
                }
            }
            detalle.append("]");

            return "{\"success\":true,\"sinMesa\":" + sinMesa + ",\"detalle\":" + detalle + "}";

        } catch (Exception e) {
            return "{\"success\":false,\"error\":\"" + escJson(e.getMessage()) + "\"}";
        }
    }

    // ── RESUMEN DE MESAS Y CAPACIDAD (admin) ─────────────────────
    private String getResumenMesas(Usuario usuario) {
        if (usuario == null || !usuario.isAdmin()) {
            return "{\"success\":false,\"error\":\"Acceso denegado\"}";
        }
        try (Connection cn = ConexionDB.getConexion()) {

            String sql = "SELECT z.nombre_zona, z.puesto_votacion, "
                    + "COUNT(m.id) AS mesas, SUM(m.capacidad) AS capacidad_total "
                    + "FROM zonas_votacion z "
                    + "LEFT JOIN mesas_votacion m ON m.id_zona = z.id "
                    + "GROUP BY z.id ORDER BY z.nombre_zona LIMIT 5";

            StringBuilder zonas = new StringBuilder("[");
            int cnt = 0;
            try (PreparedStatement ps = cn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    if (cnt > 0) zonas.append(",");
                    zonas.append("{\"zona\":\"").append(escJson(rs.getString("nombre_zona"))).append("\"")
                         .append(",\"puesto\":\"").append(escJson(rs.getString("puesto_votacion"))).append("\"")
                         .append(",\"mesas\":").append(rs.getInt("mesas"))
                         .append(",\"capacidad\":").append(rs.getInt("capacidad_total"))
                         .append("}");
                    cnt++;
                }
            }
            zonas.append("]");

            return "{\"success\":true,\"zonas\":" + zonas + "}";

        } catch (Exception e) {
            return "{\"success\":false,\"error\":\"" + escJson(e.getMessage()) + "\"}";
        }
    }

    // ── UTILIDAD ──────────────────────────────────────────────────
    private String escJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}