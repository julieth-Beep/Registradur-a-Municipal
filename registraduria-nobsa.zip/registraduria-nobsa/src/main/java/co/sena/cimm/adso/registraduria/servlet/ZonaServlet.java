package co.sena.cimm.adso.registraduria.servlet;

import co.sena.cimm.adso.registraduria.dao.CiudadDAO;
import co.sena.cimm.adso.registraduria.dao.CiudadDAOImpl;
import co.sena.cimm.adso.registraduria.dao.ZonaVotacionDAO;
import co.sena.cimm.adso.registraduria.dao.ZonaVotacionDAOImpl;
import co.sena.cimm.adso.registraduria.dao.MesaVotacionDAO;
import co.sena.cimm.adso.registraduria.dao.MesaVotacionDAOImpl;
import co.sena.cimm.adso.registraduria.model.ZonaVotacion;
import co.sena.cimm.adso.registraduria.model.MesaVotacion;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/zonas")
public class ZonaServlet extends HttpServlet {
    
    private ZonaVotacionDAO zonaDAO;
    private CiudadDAO ciudadDAO;
    private MesaVotacionDAO mesaDAO;
    
    @Override
    public void init() {
        zonaDAO = new ZonaVotacionDAOImpl();
        ciudadDAO = new CiudadDAOImpl();
        mesaDAO = new MesaVotacionDAOImpl();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        String action = req.getParameter("action");
        
        try {
            // ELIMINAR ZONA - CON VALIDACIÓN
            if ("eliminar".equals(action)) {
                String idParam = req.getParameter("id");
                if (idParam != null && !idParam.isEmpty()) {
                    int id = Integer.parseInt(idParam);
                    
                    // VERIFICAR si la zona tiene mesas asociadas
                    if (tieneMesasAsociadas(id)) {
                        req.getSession().setAttribute("error", 
                            "No se puede eliminar: La zona tiene mesas de votación asociadas.");
                    } else {
                        boolean eliminado = zonaDAO.eliminar(id);
                        if (eliminado) {
                            req.getSession().setAttribute("success", "Zona eliminada correctamente.");
                        } else {
                            req.getSession().setAttribute("error", "Error al eliminar la zona.");
                        }
                    }
                }
                resp.sendRedirect(req.getContextPath() + "/admin/zonas");
                return;
            }
            
            // NUEVO - Mostrar formulario
            if ("nuevo".equals(action)) {
                req.setAttribute("ciudades", ciudadDAO.listarTodos());
                req.getRequestDispatcher("/WEB-INF/vistas/admin/formZona.jsp")
                    .forward(req, resp);
                return;
            }
            
            // EDITAR - Mostrar formulario con datos
            if ("editar".equals(action)) {
                String idParam = req.getParameter("id");
                if (idParam != null && !idParam.isEmpty()) {
                    int id = Integer.parseInt(idParam);
                    ZonaVotacion zona = zonaDAO.buscarPorId(id);
                    req.setAttribute("zona", zona);
                    req.setAttribute("ciudades", ciudadDAO.listarTodos());
                }
                req.getRequestDispatcher("/WEB-INF/vistas/admin/formZona.jsp")
                    .forward(req, resp);
                return;
            }
            
            // LISTAR (por defecto)
            List<ZonaVotacion> zonas = zonaDAO.listarTodos();
            req.setAttribute("zonas", zonas);
            req.getRequestDispatcher("/WEB-INF/vistas/admin/listaZonas.jsp")
                .forward(req, resp);
                
        } catch (Exception e) {
            throw new ServletException("Error en ZonaServlet", e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        
        try {
            ZonaVotacion zona = new ZonaVotacion();
            
            String idParam = req.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                zona.setId(Integer.parseInt(idParam));
            }
            
            zona.setIdCiudad(Integer.parseInt(req.getParameter("idCiudad")));
            zona.setNombreZona(req.getParameter("nombreZona"));
            zona.setPuestoVotacion(req.getParameter("puestoVotacion"));
            zona.setDireccion(req.getParameter("direccion"));
            
            boolean success;
            if (zona.getId() == 0) {
                success = zonaDAO.insertar(zona);
            } else {
                success = zonaDAO.actualizar(zona);
            }
            
            if (success) {
                req.getSession().setAttribute("success", 
                    zona.getId() == 0 ? "Zona creada correctamente." : "Zona actualizada correctamente.");
            } else {
                req.getSession().setAttribute("error", "Error al guardar la zona.");
            }
            
            resp.sendRedirect(req.getContextPath() + "/admin/zonas");
            
        } catch (Exception e) {
            throw new ServletException("Error guardando zona", e);
        }
    }
    
    /**
     * Verifica si una zona tiene mesas asociadas
     */
    private boolean tieneMesasAsociadas(int idZona) {
        try {
            List<MesaVotacion> mesas = mesaDAO.listarPorZona(idZona);
            return !mesas.isEmpty();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}