package co.sena.cimm.adso.registraduria.dao;

import java.util.List;
import java.util.Map;

import co.sena.cimm.adso.registraduria.model.DocumentoExpedido;

public interface DocumentoDAO {
    
    List<DocumentoExpedido> listarTodos() throws Exception;
    
    List<DocumentoExpedido> listarPorCiudadano(int idCiudadano) throws Exception;
    
    List<DocumentoExpedido> listarRecientes(int limite) throws Exception;
    
    DocumentoExpedido buscarPorId(int id) throws Exception;
    
    DocumentoExpedido buscarPorNumeroSerie(String numeroSerie) throws Exception;
    
    List<DocumentoExpedido> buscarPorNumeroCiudadano(String numeroCiudadano) throws Exception;
    
    // ══════════════════════════════════════════════════════════════
    // NUEVO MÉTODO - Agregar esta línea en la interfaz
    // ══════════════════════════════════════════════════════════════
    boolean existeNumeroSerie(String numeroSerie, int excluirId) throws Exception;
    
    boolean insertar(DocumentoExpedido documento) throws Exception;
    
    boolean actualizar(DocumentoExpedido documento) throws Exception;
    
    boolean eliminar(int id) throws Exception;
    
    boolean cambiarEstado(int id, String estado) throws Exception;
    
    int contarTotal() throws Exception;
    
    Map<String, Integer> contarPorTipo() throws Exception;
}