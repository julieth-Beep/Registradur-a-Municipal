package co.sena.cimm.adso.registraduria.model;

import java.util.Date;

public class Usuario {

    private int id;
    private String username;
    private String documento;
    private String contraseña;
    private String tipoUsuario;
    private String estado;
    private Date fechaRegistro;
    private Date ultimoAcceso;
    private String nombres;
    private String apellidos;

    public Usuario() {
    }

    public Usuario(String username, String documento, String contraseña, String tipoUsuario) {
        this.username = username;
        this.documento = documento;
        this.contraseña = contraseña;
        this.tipoUsuario = tipoUsuario;
        this.estado = "activo";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Date getUltimoAcceso() {
        return ultimoAcceso;
    }

    public void setUltimoAcceso(Date ultimoAcceso) {
        this.ultimoAcceso = ultimoAcceso;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public boolean isAdmin() {
        return "ADMIN".equalsIgnoreCase(tipoUsuario);
    }

    public boolean isVotante() {
        return "VOTANTE".equalsIgnoreCase(tipoUsuario);
    }

    public boolean isActivo() {
        return "activo".equalsIgnoreCase(estado);
    }

    public String getNombreCompleto() {
        return nombres + " " + apellidos;
    }
}
