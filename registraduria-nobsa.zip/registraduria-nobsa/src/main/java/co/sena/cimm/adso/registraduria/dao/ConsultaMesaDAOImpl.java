package co.sena.cimm.adso.registraduria.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import co.sena.cimm.adso.registraduria.config.ConexionDB;

public class ConsultaMesaDAOImpl implements ConsultaMesaDAO {

    @Override
    public Map<String, Object> buscarMesaPorDocumento(String numeroDocumento) throws Exception {
        String sql = "SELECT "
                + "    c.nombres, "
                + "    c.apellidos, "
                + "    c.numero_documento, "
                + "    ciu.nombre AS ciudad, "
                + "    ciu.codigo_dane, "
                + "    z.nombre_zona, "
                + "    z.puesto_votacion, "
                + "    z.direccion, "
                + "    m.numero_mesa, "
                + "    m.capacidad, "
                + "    c.id_mesa "
                + "FROM ciudadanos c "
                + "LEFT JOIN mesas_votacion m ON c.id_mesa = m.id "
                + "LEFT JOIN zonas_votacion z ON m.id_zona = z.id "
                + "LEFT JOIN ciudades ciu ON z.id_ciudad = ciu.id "
                + "WHERE c.numero_documento = ?";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, numeroDocumento);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Map<String, Object> resultado = new HashMap<>();
                    resultado.put("nombres", rs.getString("nombres"));
                    resultado.put("apellidos", rs.getString("apellidos"));
                    resultado.put("numeroDocumento", rs.getString("numero_documento"));
                    resultado.put("ciudad", rs.getString("ciudad"));
                    resultado.put("codigoDane", rs.getString("codigo_dane"));
                    resultado.put("nombreZona", rs.getString("nombre_zona"));
                    resultado.put("puestoVotacion", rs.getString("puesto_votacion"));
                    resultado.put("direccion", rs.getString("direccion"));
                    resultado.put("numeroMesa", rs.getInt("numero_mesa"));
                    resultado.put("capacidad", rs.getInt("capacidad"));
                    resultado.put("tieneMesa", rs.getObject("id_mesa") != null);
                    return resultado;
                }
                return null;
            }
        }
    }

    @Override
    public List<Map<String, Object>> listarMesasPorZona(int idZona) throws Exception {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = "SELECT id, numero_mesa, capacidad FROM mesas_votacion "
                + "WHERE id_zona = ? ORDER BY numero_mesa";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idZona);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> mesa = new HashMap<>();
                    mesa.put("id", rs.getInt("id"));
                    mesa.put("numeroMesa", rs.getInt("numero_mesa"));
                    mesa.put("capacidad", rs.getInt("capacidad"));
                    lista.add(mesa);
                }
            }
        }
        return lista;
    }

    @Override
    public List<Map<String, Object>> listarZonasPorCiudad(int idCiudad) throws Exception {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = "SELECT id, nombre_zona, puesto_votacion, direccion "
                + "FROM zonas_votacion WHERE id_ciudad = ? ORDER BY nombre_zona";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCiudad);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> zona = new HashMap<>();
                    zona.put("id", rs.getInt("id"));
                    zona.put("nombreZona", rs.getString("nombre_zona"));
                    zona.put("puestoVotacion", rs.getString("puesto_votacion"));
                    zona.put("direccion", rs.getString("direccion"));
                    lista.add(zona);
                }
            }
        }
        return lista;
    }

    @Override
    public List<Map<String, Object>> listarTodasCiudades() throws Exception {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = "SELECT id, nombre, departamento, codigo_dane "
                + "FROM ciudades ORDER BY nombre";

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> ciudad = new HashMap<>();
                ciudad.put("id", rs.getInt("id"));
                ciudad.put("nombre", rs.getString("nombre"));
                ciudad.put("departamento", rs.getString("departamento"));
                ciudad.put("codigoDane", rs.getString("codigo_dane"));
                lista.add(ciudad);
            }
        }
        return lista;
    }
}