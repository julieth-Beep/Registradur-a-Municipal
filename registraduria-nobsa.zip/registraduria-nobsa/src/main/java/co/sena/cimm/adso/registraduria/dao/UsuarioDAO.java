package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.model.Usuario;
import java.util.List;

public interface UsuarioDAO {
    Usuario login(String username, String password);
    boolean registrar(Usuario usuario);
    Usuario buscarPorUsername(String username);
    Usuario buscarPorDocumento(String documento);
    Usuario buscarPorId(int id);
    boolean ciudadanoExiste(String documento);
    List<Usuario> listarTodos();
    boolean actualizarEstado(int id, String estado);
    boolean actualizarUltimoAcceso(int id);
    boolean eliminar(int id);
    boolean actualizar(Usuario usuario);
}