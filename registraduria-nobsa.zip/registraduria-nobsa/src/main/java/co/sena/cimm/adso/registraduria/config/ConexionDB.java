package co.sena.cimm.adso.registraduria.config;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConexionDB {

    // Carga el archivo db.properties una sola vez al arrancar la app
    private static final Properties props = new Properties();

    static {
        try (InputStream in = ConexionDB.class.getClassLoader()
                .getResourceAsStream("db.properties")) {
            if (in == null) {
                throw new RuntimeException("No se encontró db.properties en el classpath");
            }
            props.load(in);
        } catch (Exception e) {
            throw new RuntimeException("No se pudo cargar db.properties", e);
        }
    }

    /**
     * Si el valor del .properties es ${NOMBRE_VARIABLE},
     * busca esa variable en el sistema operativo (variables de entorno de Render).
     * Si no la encuentra, devuelve el valor tal cual (sirve para pruebas locales).
     */
    private static String resolve(String value) {
        if (value == null) return null;

        // Detecta si el valor tiene formato ${ALGO}
        if (value.startsWith("${") && value.endsWith("}")) {
            // Extrae el nombre de la variable, ej: DB_URL
            String varName = value.substring(2, value.length() - 1);

            // Busca primero en variables de entorno del sistema (las que pones en Render)
            String envVal = System.getenv(varName);
            if (envVal != null && !envVal.isBlank()) {
                return envVal;
            }

            // Si no encuentra en entorno, busca en propiedades del sistema (-D al arrancar)
            String sysVal = System.getProperty(varName);
            if (sysVal != null && !sysVal.isBlank()) {
                return sysVal;
            }

            // Si no encontró nada, devuelve el ${VAR} literal
            // (la conexión fallará, pero al menos sabrás qué variable falta)
            return value;
        }

        // Si el valor NO tiene formato ${}, lo devuelve tal cual (texto literal)
        return value;
    }

    /**
     * Devuelve una conexión activa a la base de datos
     * según el motor configurado en db.properties
     */
    public static Connection getConexion() throws Exception {
        String engine = resolve(props.getProperty("db.engine")).trim();

        return switch (engine) {

            case "postgresql" -> {
                String url  = resolve(props.getProperty("postgresql.url"));
                String user = resolve(props.getProperty("postgresql.user"));
                String pass = resolve(props.getProperty("postgresql.password"));
                yield DriverManager.getConnection(url, user, pass);
            }

            case "sqlserver" -> {
                String url  = resolve(props.getProperty("sqlserver.url"));
                String user = resolve(props.getProperty("sqlserver.user"));
                String pass = resolve(props.getProperty("sqlserver.password"));
                if (user == null || user.trim().isEmpty()) {
                    yield DriverManager.getConnection(url);
                } else {
                    yield DriverManager.getConnection(url, user, pass);
                }
            }

            default -> throw new IllegalArgumentException("Motor no reconocido: " + engine);
        };
    }
}