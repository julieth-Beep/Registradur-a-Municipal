package co.sena.cimm.adso.registraduria.config;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConexionDB {
    
    private static final Properties props = new Properties();
    
    static {
        try (InputStream in = ConexionDB.class.getClassLoader()
                .getResourceAsStream("db.properties")) {
            props.load(in);
        } catch (Exception e) {
            throw new RuntimeException("No se pudo cargar db.properties", e);
        }
    }
    
    public static Connection getConexion() throws Exception {
        String engine = props.getProperty("db.engine").trim();
        
        return switch (engine) {
            case "sqlserver" -> {
                String url = props.getProperty("sqlserver.url");
                String user = props.getProperty("sqlserver.user");
                String pass = props.getProperty("sqlserver.password");
                
                if (user == null || user.trim().isEmpty()) {
                    yield DriverManager.getConnection(url);
                } else {
                    yield DriverManager.getConnection(url, user, pass);
                }
            }
            case "postgresql" -> {
                String url = props.getProperty("postgresql.url");
                String user = props.getProperty("postgresql.user");
                String pass = props.getProperty("postgresql.password");
                yield DriverManager.getConnection(url, user, pass);
            }
            default -> throw new IllegalArgumentException("Motor no reconocido: " + engine);
        };
    }
}