package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.config.ConexionDB;
import co.sena.cimm.adso.registraduria.model.ZonaVotacion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ZonaVotacionDAOImpl implements ZonaVotacionDAO {
    
    @Override
    public List<ZonaVotacion> listarTodos() throws Exception {
        List<ZonaVotacion> lista = new ArrayList<>();
        String sql = "SELECT z.*, c.nombre as ciudad_nombre, c.departamento " +
                    "FROM zonas_votacion z " +
                    "INNER JOIN ciudades c ON z.id_ciudad = c.id " +
                    "ORDER BY z.nombre_zona";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                lista.add(mapearZona(rs));
            }
        }
        return lista;
    }
    
    @Override
    public List<ZonaVotacion> listarPorCiudad(int idCiudad) throws Exception {
        List<ZonaVotacion> lista = new ArrayList<>();
        String sql = "SELECT z.*, c.nombre as ciudad_nombre, c.departamento " +
                    "FROM zonas_votacion z " +
                    "INNER JOIN ciudades c ON z.id_ciudad = c.id " +
                    "WHERE z.id_ciudad = ? " +
                    "ORDER BY z.nombre_zona";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idCiudad);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearZona(rs));
                }
            }
        }
        return lista;
    }
    
    @Override
    public ZonaVotacion buscarPorId(int id) throws Exception {
        String sql = "SELECT z.*, c.nombre as ciudad_nombre, c.departamento " +
                    "FROM zonas_votacion z " +
                    "INNER JOIN ciudades c ON z.id_ciudad = c.id " +
                    "WHERE z.id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearZona(rs);
                }
            }
        }
        return null;
    }
    
    @Override
    public boolean insertar(ZonaVotacion zona) throws Exception {
        String sql = "INSERT INTO zonas_votacion (id_ciudad, nombre_zona, puesto_votacion, direccion) " +
                    "VALUES (?, ?, ?, ?)";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, zona.getIdCiudad());
            stmt.setString(2, zona.getNombreZona());
            stmt.setString(3, zona.getPuestoVotacion());
            stmt.setString(4, zona.getDireccion());
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    @Override
    public boolean actualizar(ZonaVotacion zona) throws Exception {
        String sql = "UPDATE zonas_votacion SET id_ciudad = ?, nombre_zona = ?, " +
                    "puesto_votacion = ?, direccion = ? WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, zona.getIdCiudad());
            stmt.setString(2, zona.getNombreZona());
            stmt.setString(3, zona.getPuestoVotacion());
            stmt.setString(4, zona.getDireccion());
            stmt.setInt(5, zona.getId());
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    @Override
    public boolean eliminar(int id) throws Exception {
        String sql = "DELETE FROM zonas_votacion WHERE id = ?";
        
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }
    
    private ZonaVotacion mapearZona(ResultSet rs) throws SQLException {
        ZonaVotacion z = new ZonaVotacion();
        z.setId(rs.getInt("id"));
        z.setIdCiudad(rs.getInt("id_ciudad"));
        z.setNombreZona(rs.getString("nombre_zona"));
        z.setPuestoVotacion(rs.getString("puesto_votacion"));
        z.setDireccion(rs.getString("direccion"));
        z.setNombreCiudad(rs.getString("ciudad_nombre"));
        z.setDepartamento(rs.getString("departamento"));
        return z;
    }
}