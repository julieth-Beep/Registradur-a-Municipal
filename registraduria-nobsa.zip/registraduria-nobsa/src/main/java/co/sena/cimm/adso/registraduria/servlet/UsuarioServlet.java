package co.sena.cimm.adso.registraduria.servlet;

import co.sena.cimm.adso.registraduria.dao.UsuarioDAO;
import co.sena.cimm.adso.registraduria.dao.UsuarioDAOImpl;
import co.sena.cimm.adso.registraduria.dao.CiudadanoDAO;
import co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl;
import co.sena.cimm.adso.registraduria.model.Usuario;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/usuarios")
public class UsuarioServlet extends HttpServlet {
    
    private UsuarioDAO usuarioDAO;
    private CiudadanoDAO ciudadanoDAO;
    
    @Override
    public void init() {
        usuarioDAO = new UsuarioDAOImpl();
        ciudadanoDAO = new CiudadanoDAOImpl();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        String action = req.getParameter("action");
        
        try {
            // ELIMINAR USUARIO
            if ("eliminar".equals(action)) {
                String idParam = req.getParameter("id");
                if (idParam != null && !idParam.isEmpty()) {
                    int id = Integer.parseInt(idParam);
                    
                    try {
                        boolean eliminado = usuarioDAO.eliminar(id);
                        if (eliminado) {
                            req.getSession().setAttribute("success", "Usuario eliminado correctamente.");
                        } else {
                            req.getSession().setAttribute("error", "Error al eliminar el usuario.");
                        }
                    } catch (Exception e) {
                        req.getSession().setAttribute("error", "Error al eliminar: " + e.getMessage());
                    }
                }
                resp.sendRedirect(req.getContextPath() + "/admin/usuarios");
                return;
            }
            
            // CAMBIAR ESTADO
            if ("cambiarEstado".equals(action)) {
                String idParam = req.getParameter("id");
                String estado = req.getParameter("estado");
                if (idParam != null && !idParam.isEmpty() && estado != null) {
                    int id = Integer.parseInt(idParam);
                    
                    try {
                        boolean actualizado = usuarioDAO.actualizarEstado(id, estado);
                        if (actualizado) {
                            req.getSession().setAttribute("success", "Estado actualizado correctamente.");
                        } else {
                            req.getSession().setAttribute("error", "Error al cambiar el estado.");
                        }
                    } catch (Exception e) {
                        req.getSession().setAttribute("error", "Error: " + e.getMessage());
                    }
                }
                resp.sendRedirect(req.getContextPath() + "/admin/usuarios");
                return;
            }
            
            // NUEVO - Mostrar formulario vacío
            if ("nuevo".equals(action)) {
                req.getRequestDispatcher("/WEB-INF/vistas/admin/formUsuario.jsp")
                    .forward(req, resp);
                return;
            }
            
            // EDITAR - Mostrar formulario con datos
            if ("editar".equals(action)) {
                String idParam = req.getParameter("id");
                if (idParam != null && !idParam.isEmpty()) {
                    int id = Integer.parseInt(idParam);
                    Usuario usuario = usuarioDAO.buscarPorId(id);
                    req.setAttribute("usuario", usuario);
                }
                req.getRequestDispatcher("/WEB-INF/vistas/admin/formUsuario.jsp")
                    .forward(req, resp);
                return;
            }
            
            // LISTAR (por defecto)
            List<Usuario> usuarios = usuarioDAO.listarTodos();
            req.setAttribute("usuarios", usuarios);
            req.getRequestDispatcher("/WEB-INF/vistas/admin/listaUsuarios.jsp")
                .forward(req, resp);
                
        } catch (Exception e) {
            throw new ServletException("Error en UsuarioServlet", e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        
        try {
            Usuario usuario = new Usuario();
            
            String idParam = req.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                usuario.setId(Integer.parseInt(idParam));
            }
            
            usuario.setUsername(req.getParameter("username"));
            usuario.setDocumento(req.getParameter("documento"));
            usuario.setTipoUsuario(req.getParameter("tipoUsuario"));
            
            // Estado solo en edición
            String estado = req.getParameter("estado");
            if (estado != null && !estado.isEmpty()) {
                usuario.setEstado(estado);
            }
            
            String password = req.getParameter("password");
            
            boolean success = false;
            
            if (usuario.getId() == 0) {
                // NUEVO USUARIO
                if (password != null && !password.trim().isEmpty()) {
                    // Verificar que el ciudadano existe
                    if (!usuarioDAO.ciudadanoExiste(usuario.getDocumento())) {
                        req.getSession().setAttribute("error", 
                            "El documento no está registrado en el sistema de ciudadanos.");
                        resp.sendRedirect(req.getContextPath() + "/admin/usuarios?action=nuevo");
                        return;
                    }
                    
                    // Verificar que no exista otro usuario con el mismo documento
                    if (usuarioDAO.buscarPorDocumento(usuario.getDocumento()) != null) {
                        req.getSession().setAttribute("error", 
                            "Ya existe un usuario con este documento.");
                        resp.sendRedirect(req.getContextPath() + "/admin/usuarios?action=nuevo");
                        return;
                    }
                    
                    // Verificar que el username no exista
                    if (usuarioDAO.buscarPorUsername(usuario.getUsername()) != null) {
                        req.getSession().setAttribute("error", 
                            "El nombre de usuario ya está en uso.");
                        resp.sendRedirect(req.getContextPath() + "/admin/usuarios?action=nuevo");
                        return;
                    }
                    
                    usuario.setContraseña(password);
                    success = usuarioDAO.registrar(usuario);
                    
                    if (success) {
                        req.getSession().setAttribute("success", "Usuario creado correctamente.");
                    } else {
                        req.getSession().setAttribute("error", "Error al crear el usuario.");
                    }
                } else {
                    req.getSession().setAttribute("error", "La contraseña es obligatoria.");
                    resp.sendRedirect(req.getContextPath() + "/admin/usuarios?action=nuevo");
                    return;
                }
            } else {
                // EDITAR USUARIO
                // Verificar que el username no exista (excepto el actual)
                Usuario existente = usuarioDAO.buscarPorUsername(usuario.getUsername());
                if (existente != null && existente.getId() != usuario.getId()) {
                    req.getSession().setAttribute("error", 
                        "El nombre de usuario ya está en uso.");
                    resp.sendRedirect(req.getContextPath() + "/admin/usuarios?action=editar&id=" + usuario.getId());
                    return;
                }
                
                // Si se proporcionó nueva contraseña, actualizarla
                if (password != null && !password.trim().isEmpty()) {
                    usuario.setContraseña(password);
                }
                
                success = usuarioDAO.actualizar(usuario);
                
                if (success) {
                    req.getSession().setAttribute("success", "Usuario actualizado correctamente.");
                } else {
                    req.getSession().setAttribute("error", "Error al actualizar el usuario.");
                }
            }
            
            resp.sendRedirect(req.getContextPath() + "/admin/usuarios");
            
        } catch (Exception e) {
            req.getSession().setAttribute("error", "Error: " + e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/admin/usuarios");
        }
    }
}