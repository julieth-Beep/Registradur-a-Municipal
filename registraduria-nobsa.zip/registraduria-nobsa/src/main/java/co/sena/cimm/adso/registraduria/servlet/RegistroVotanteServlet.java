package co.sena.cimm.adso.registraduria.servlet;

import co.sena.cimm.adso.registraduria.dao.UsuarioDAO;
import co.sena.cimm.adso.registraduria.dao.UsuarioDAOImpl;
import co.sena.cimm.adso.registraduria.model.Usuario;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/registro-votante")
public class RegistroVotanteServlet extends HttpServlet {
    
    private UsuarioDAO usuarioDAO;
    
    @Override
    public void init() {
        usuarioDAO = new UsuarioDAOImpl();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/vistas/registro-votante.jsp").forward(req, resp);
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        
        String documento = req.getParameter("documento");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        
        // Verificar si la cédula existe en ciudadanos
        if (!usuarioDAO.ciudadanoExiste(documento)) {
            req.setAttribute("error", 
                "Su cédula no está registrada en el sistema. Contacte al administrador.");
            req.getRequestDispatcher("/WEB-INF/vistas/registro-votante.jsp").forward(req, resp);
            return;
        }
        
        // Verificar si ya existe un usuario con ese documento
        if (usuarioDAO.buscarPorDocumento(documento) != null) {
            req.setAttribute("error", "Ya existe una cuenta con este documento.");
            req.getRequestDispatcher("/WEB-INF/vistas/registro-votante.jsp").forward(req, resp);
            return;
        }
        
        // Verificar si el username ya existe
        if (usuarioDAO.buscarPorUsername(username) != null) {
            req.setAttribute("error", "El nombre de usuario ya está en uso.");
            req.getRequestDispatcher("/WEB-INF/vistas/registro-votante.jsp").forward(req, resp);
            return;
        }
        
        // Crear usuario con rol VOTANTE
        Usuario nuevoUsuario = new Usuario(username, documento, password, "VOTANTE");
        
        if (usuarioDAO.registrar(nuevoUsuario)) {
            req.setAttribute("success", 
                "Cuenta creada exitosamente. Ahora puede iniciar sesión.");
        } else {
            req.setAttribute("error", "Error al crear la cuenta. Intente nuevamente.");
        }
        
        req.getRequestDispatcher("/WEB-INF/vistas/registro-votante.jsp").forward(req, resp);
    }
}