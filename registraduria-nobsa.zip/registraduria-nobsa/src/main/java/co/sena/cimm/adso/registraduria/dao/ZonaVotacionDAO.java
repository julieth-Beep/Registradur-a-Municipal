package co.sena.cimm.adso.registraduria.dao;

import co.sena.cimm.adso.registraduria.model.ZonaVotacion;
import java.util.List;

public interface ZonaVotacionDAO {
    List<ZonaVotacion> listarTodos() throws Exception;
    List<ZonaVotacion> listarPorCiudad(int idCiudad) throws Exception;
    ZonaVotacion buscarPorId(int id) throws Exception;
    boolean insertar(ZonaVotacion zona) throws Exception;
    boolean actualizar(ZonaVotacion zona) throws Exception;
    boolean eliminar(int id) throws Exception;
}