package co.sena.cimm.adso.registraduria.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/uploads/documentos/*")
public class FileServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private static final int BUFFER_SIZE = 4096;
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Obtener nombre del archivo desde la URL
        String requestPath = req.getRequestURI();
        String contextPath = req.getContextPath();
        String filePath = requestPath.substring(contextPath.length() + "/uploads/documentos/".length());
        
        // Sanitizar nombre de archivo - solo caracteres seguros
        filePath = filePath.replaceAll("[^a-zA-Z0-9._\\-]", "_");
        
        if (filePath.isEmpty()) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Ruta completa del archivo
        String uploadDir = getServletContext().getRealPath("") + 
                          File.separator + "uploads" + File.separator + "documentos";
        File archivo = new File(uploadDir, filePath);
        
        // Verificar que el archivo existe y está dentro del directorio permitido (previene path traversal)
        try {
            if (!archivo.exists() || !archivo.getCanonicalPath().startsWith(new File(uploadDir).getCanonicalPath())) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }
        } catch (IOException e) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        
        // Determinar Content-Type según extensión
        String contentType = getServletContext().getMimeType(archivo.getAbsolutePath());
        if (contentType == null) {
            if (filePath.toLowerCase().endsWith(".pdf")) {
                contentType = "application/pdf";
            } else if (filePath.toLowerCase().endsWith(".jpg") || filePath.toLowerCase().endsWith(".jpeg")) {
                contentType = "image/jpeg";
            } else if (filePath.toLowerCase().endsWith(".png")) {
                contentType = "image/png";
            } else if (filePath.toLowerCase().endsWith(".gif")) {
                contentType = "image/gif";
            } else if (filePath.toLowerCase().endsWith(".webp")) {
                contentType = "image/webp";
            } else {
                contentType = "application/octet-stream";
            }
        }
        
        // Configurar respuesta
        resp.setContentType(contentType);
        resp.setContentLength((int) archivo.length());
        
        // Content-Disposition: inline para visualizar en navegador, attachment para descargar
        String download = req.getParameter("download");
        if ("true".equals(download)) {
            resp.setHeader("Content-Disposition", "attachment; filename=\"" + archivo.getName() + "\"");
        } else {
            resp.setHeader("Content-Disposition", "inline; filename=\"" + archivo.getName() + "\"");
        }
        
        // Headers de cache para imágenes
        if (contentType.startsWith("image/")) {
            resp.setHeader("Cache-Control", "public, max-age=31536000");
        }
        
        // Stream del archivo al cliente
        try (FileInputStream input = new FileInputStream(archivo);
             OutputStream output = resp.getOutputStream()) {
            
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
            output.flush();
        }
    }
}