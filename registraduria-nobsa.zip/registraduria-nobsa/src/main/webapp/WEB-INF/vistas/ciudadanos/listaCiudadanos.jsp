<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudadano" %>
<%@ page import="java.util.*" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    // Cargar ciudadanos
    CiudadanoDAO ciudadanoDAO = new CiudadanoDAOImpl();
    List<Ciudadano> todosCiudadanos = new ArrayList<Ciudadano>();
    
    try {
        todosCiudadanos = ciudadanoDAO.listarTodos();
    } catch (Exception e) {
        out.println("<!-- ERROR: " + e.getMessage() + " -->");
    }
    
    // Contar estadísticas
    int totalCiudadanos = todosCiudadanos.size();
    int conMesa = 0, sinMesa = 0, conTelefono = 0;
    
    for (Ciudadano c : todosCiudadanos) {
        if (c.getIdMesa() != null && c.getIdMesa() > 0) conMesa++;
        else sinMesa++;
        if (c.getTelefono() != null && !c.getTelefono().isEmpty()) conTelefono++;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Ciudadanos | Registraduría Municipal de Nobsa</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ═══════════════════════════════════════════════════════════ */
        /* DESIGN TOKENS - Registraduría Premium */
        /* ═══════════════════════════════════════════════════════════ */
        :root {
            --primary-900: #001a3a;
            --primary-800: #003366;
            --primary-700: #004080;
            --primary-600: #0055A4;
            --primary-500: #1a6bc4;
            --primary-100: #dbeafe;
            --primary-50: #eff6ff;
            
            --accent-red: #CE1126;
            --accent-yellow: #FCD116;
            --accent-yellow-light: #FFE066;
            
            --bg: #f8fafc;
            --surface: rgba(255, 255, 255, 0.85);
            --surface-2: rgba(248, 250, 252, 0.85);
            --border: rgba(0, 51, 102, 0.12);
            --txt: #0f172a;
            --txt-muted: #64748b;
            --txt-light: #94a3b8;
            
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            --info: #0ea5e9;
            
            --glass-bg: rgba(255, 255, 255, 0.75);
            --glass-border: rgba(255, 255, 255, 0.25);
            --glass-shadow: 0 8px 32px rgba(0, 51, 102, 0.08);
            --glass-blur: blur(16px);
            
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.04);
            --shadow-md: 0 4px 12px rgba(0, 51, 102, 0.08);
            --shadow-lg: 0 12px 32px rgba(0, 51, 102, 0.12);
            --shadow-glow: 0 0 40px rgba(0, 85, 164, 0.15);
            
            --radius-sm: 12px;
            --radius-md: 16px;
            --radius-lg: 20px;
            --radius-xl: 24px;
            --radius-2xl: 32px;
            
            --font-sans: 'Plus Jakarta Sans', sans-serif;
            --font-display: 'Space Grotesk', sans-serif;
            
            --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
            --duration-fast: 200ms;
            --duration-normal: 350ms;
        }

        [data-theme="dark"] {
            --bg: #0f172a;
            --surface: rgba(30, 41, 59, 0.85);
            --surface-2: rgba(23, 33, 54, 0.85);
            --border: rgba(255, 255, 255, 0.12);
            --txt: #f1f5f9;
            --txt-muted: #94a3b8;
            --txt-light: #64748b;
            --glass-bg: rgba(30, 41, 59, 0.75);
            --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        
        body {
            font-family: var(--font-sans);
            background: var(--bg);
            color: var(--txt);
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        /* Ambient Background */
        .ambient-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }
        .ambient-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.08;
            animation: float 20s ease-in-out infinite;
        }
        .ambient-blob-1 {
            width: 600px; height: 600px;
            background: var(--primary-600);
            top: -100px; right: -100px;
        }
        .ambient-blob-2 {
            width: 400px; height: 400px;
            background: var(--accent-yellow);
            bottom: -50px; left: -50px;
            animation-delay: -10s;
        }
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(20px, -20px) scale(1.05); }
        }

        .grid-pattern {
            position: fixed;
            inset: 0;
            background-image: 
                linear-gradient(rgba(0, 51, 102, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 51, 102, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: 0;
            pointer-events: none;
        }

        /* Layout */
        .main-content {
            margin-left: 280px;
            padding: 40px 32px 48px;
            min-height: 100vh;
            position: relative;
            z-index: 10;
        }
        @media (max-width: 1024px) {
            .main-content { margin-left: 0; padding: 24px 20px 40px; }
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            gap: 16px;
            flex-wrap: wrap;
            animation: fadeInDown 0.6s var(--ease-out) both;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-title {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 700;
            color: var(--txt);
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0;
        }
        .page-title i { color: var(--primary-600); font-size: 24px; }

        .page-subtitle {
            font-size: 14px;
            color: var(--txt-muted);
            margin-top: 4px;
            font-weight: 500;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary-600), var(--primary-800));
            border: none;
            padding: 12px 24px;
            border-radius: var(--radius-md);
            color: white;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all var(--duration-normal) var(--ease-out);
            box-shadow: var(--shadow-md), var(--shadow-glow);
        }
        .btn-primary-custom:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg), var(--shadow-glow);
            color: white;
        }

        /* Stats Cards */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }
        @media (max-width: 1200px) { .stats-row { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 768px) { .stats-row { grid-template-columns: 1fr; } }

        .stat-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-xl);
            padding: 24px;
            text-align: center;
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
            animation: fadeInUp 0.5s var(--ease-out) both;
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-600), var(--accent-yellow));
            transform: scaleX(0);
            transform-origin: left;
            transition: transform var(--duration-normal) var(--ease-out);
        }
        .stat-card:hover::before { transform: scaleX(1); }
        .stat-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg), var(--glass-shadow); }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .stat-icon {
            width: 56px;
            height: 56px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin: 0 auto 16px;
        }
        .stat-icon.primary { background: rgba(0, 85, 164, 0.12); color: var(--primary-600); }
        .stat-icon.success { background: rgba(16, 185, 129, 0.12); color: var(--success); }
        .stat-icon.warning { background: rgba(245, 158, 11, 0.12); color: var(--warning); }
        .stat-icon.info { background: rgba(14, 165, 233, 0.12); color: var(--info); }

        .stat-value {
            font-family: var(--font-display);
            font-size: 32px;
            font-weight: 800;
            color: var(--txt);
            line-height: 1;
            margin-bottom: 4px;
        }
        .stat-label {
            font-size: 13px;
            color: var(--txt-muted);
            font-weight: 500;
        }

        /* Section Title */
        .section-title {
            font-family: var(--font-display);
            font-size: 20px;
            font-weight: 700;
            color: var(--txt);
            margin: 32px 0 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .section-title i { color: var(--primary-600); }

        /* Toolbar */
        .toolbar {
            display: flex;
            gap: 16px;
            margin-bottom: 20px;
            padding: 16px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--glass-shadow);
            flex-wrap: wrap;
        }

        .search-box {
            flex: 1;
            min-width: 250px;
            display: flex;
            align-items: center;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 8px 16px;
        }
        .search-box input {
            border: none;
            padding: 10px;
            width: 100%;
            background: transparent;
            color: var(--txt);
            font-size: 14px;
        }
        .search-box input:focus { outline: none; }
        .search-box i { color: var(--txt-muted); }

        .filter-select {
            padding: 10px 20px;
            border-radius: var(--radius-md);
            background: var(--surface-2);
            border: 1px solid var(--border);
            color: var(--txt);
            font-size: 14px;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .filter-select:focus {
            outline: none;
            border-color: var(--primary-600);
            box-shadow: 0 0 0 3px rgba(0, 85, 164, 0.1);
        }

        .export-btn {
            padding: 10px 20px;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--txt);
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .export-btn:hover {
            background: var(--primary-600);
            color: white;
            border-color: var(--primary-600);
        }

        /* Table Container */
        .table-container {
            background: var(--glass-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-2xl);
            box-shadow: var(--glass-shadow);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: var(--surface-2);
            padding: 16px 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--txt-muted);
            text-align: left;
            border-bottom: 2px solid var(--border);
        }

        td {
            padding: 14px 20px;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
            color: var(--txt);
            font-size: 14px;
        }

        tr { transition: all var(--duration-fast) var(--ease-out); }
        tr:hover {
            background: rgba(0, 85, 164, 0.05);
            transform: translateX(4px);
        }
        tr:last-child td { border-bottom: none; }

        .btn-action {
            padding: 6px 12px;
            border-radius: var(--radius-sm);
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all var(--duration-fast) var(--ease-out);
            margin-right: 4px;
            border: none;
            cursor: pointer;
        }
        .btn-edit { background: rgba(245, 158, 11, 0.12); color: var(--warning); }
        .btn-edit:hover { background: var(--warning); color: white; }
        .btn-delete { background: rgba(239, 68, 68, 0.12); color: var(--error); }
        .btn-delete:hover { background: var(--error); color: white; }

        /* Badges */
        .badge {
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .badge-success { background: rgba(16, 185, 129, 0.12); color: var(--success); }
        .badge-warning { background: rgba(245, 158, 11, 0.12); color: var(--warning); }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--txt-muted);
        }
        .empty-state i {
            font-size: 48px;
            opacity: 0.3;
            margin-bottom: 16px;
            display: block;
        }

        /* Toast Notifications */
        .toast-container {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .toast {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 16px 20px;
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 320px;
            animation: slideInRight 0.3s var(--ease-out) both;
        }
        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(100px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .toast.success { border-left: 4px solid var(--success); }
        .toast.error { border-left: 4px solid var(--error); }
        .toast.warning { border-left: 4px solid var(--warning); }
        .toast i { font-size: 18px; }
        .toast.success i { color: var(--success); }
        .toast.error i { color: var(--error); }
        .toast.warning i { color: var(--warning); }

        /* Responsive */
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: 1fr; }
            .toolbar { flex-direction: column; }
            .search-box { min-width: 100%; }
        }
    </style>
</head>
<body>

    <!-- Ambient Background -->
    <div class="ambient-bg">
        <div class="ambient-blob ambient-blob-1"></div>
        <div class="ambient-blob ambient-blob-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>

    <%@ include file="/includes/navbar.jsp" %>

    <main class="main-content">
        
        <!-- Page Header -->
        <div class="page-header">
            <div>
                <h1 class="page-title">
                    <i class="fas fa-users"></i> 
                    Gestión de Ciudadanos
                </h1>
                <p class="page-subtitle"><%= totalCiudadanos %> ciudadanos registrados en el sistema</p>
            </div>
            <a href="<%= request.getContextPath() %>/ciudadanos?action=nuevo" class="btn-primary-custom">
                <i class="fas fa-plus"></i> Nuevo Ciudadano
            </a>
        </div>

        <!-- Stats Cards -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-icon primary"><i class="fas fa-users"></i></div>
                <div class="stat-value"><%= totalCiudadanos %></div>
                <div class="stat-label">Total Ciudadanos</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon success"><i class="fas fa-check-circle"></i></div>
                <div class="stat-value"><%= conMesa %></div>
                <div class="stat-label">Con Mesa Asignada</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon warning"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-value"><%= sinMesa %></div>
                <div class="stat-label">Sin Mesa Asignada</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon info"><i class="fas fa-phone"></i></div>
                <div class="stat-value"><%= conTelefono %></div>
                <div class="stat-label">Con Teléfono</div>
            </div>
        </div>

        <!-- All Citizens Section -->
        <div class="section-title">
            <i class="fas fa-list"></i> Todos los Ciudadanos
            <span style="font-size: 14px; color: var(--txt-muted); margin-left: 10px; font-weight: 400;">
                (<%= totalCiudadanos %> registros)
            </span>
        </div>

        <!-- Toolbar -->
        <div class="toolbar">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="searchInput" placeholder="Buscar por nombre, apellido o documento..." autocomplete="off">
            </div>
            <select id="filterMesa" class="filter-select">
                <option value="todos">Todos</option>
                <option value="conMesa">Con mesa asignada</option>
                <option value="sinMesa">Sin mesa asignada</option>
            </select>
            <button class="export-btn" onclick="exportToCSV()">
                <i class="fas fa-file-csv"></i> Exportar CSV
            </button>
            <button class="export-btn" onclick="imprimirListado()">
                <i class="fas fa-print"></i> Imprimir
            </button>
        </div>

        <!-- Table -->
        <div class="table-container">
            <div class="table-responsive">
                <table id="ciudadanosTable">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Documento</th>
                            <th>Vereda/Barrio</th>
                            <th>Mesa</th>
                            <th style="width: 140px;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% if (!todosCiudadanos.isEmpty()) {
                            for (Ciudadano c : todosCiudadanos) {
                                boolean tieneMesa = (c.getIdMesa() != null && c.getIdMesa() > 0);
                        %>
                        <tr class="ciudadano-row" 
                            data-nombre="<%= c.getNombres() != null ? c.getNombres().toLowerCase() : "" %>"
                            data-apellido="<%= c.getApellidos() != null ? c.getApellidos().toLowerCase() : "" %>"
                            data-documento="<%= c.getNumeroDocumento() != null ? c.getNumeroDocumento() : "" %>"
                            data-mesa="<%= tieneMesa ? "conMesa" : "sinMesa" %>">
                            <td><strong><%= c.getNombres() %></strong></td>
                            <td><%= c.getApellidos() %></td>
                            <td><%= c.getNumeroDocumento() %></td>
                            <td><%= c.getVeredaBarrio() != null ? c.getVeredaBarrio() : "<span style='color:var(--txt-light);'>—</span>" %></td>
                            <td>
                                <% if (tieneMesa) { %>
                                    <span class="badge badge-success">
                                        <i class="fas fa-check-circle"></i> Mesa #<%= c.getNumeroMesa() %>
                                    </span>
                                <% } else { %>
                                    <span class="badge badge-warning">
                                        <i class="fas fa-exclamation-triangle"></i> Sin asignar
                                    </span>
                                <% } %>
                            </td>
                            <td>
                                <a href="<%= request.getContextPath() %>/ciudadanos?action=editar&id=<%= c.getId() %>" class="btn-action btn-edit" title="Editar ciudadano">
                                    <i class="fas fa-edit"></i> Editar
                                </a>
                                <a href="<%= request.getContextPath() %>/ciudadanos?action=eliminar&id=<%= c.getId() %>" 
                                   class="btn-action btn-delete" title="Eliminar ciudadano"
                                   onclick="return confirm('¿Está seguro de eliminar este ciudadano? Esta acción no se puede deshacer.')">
                                    <i class="fas fa-trash"></i> Eliminar
                                </a>
                            </td>
                        </tr>
                        <% }
                        } else { %>
                        <tr>
                            <td colspan="6">
                                <div class="empty-state">
                                    <i class="fas fa-users"></i>
                                    <p><strong>No hay ciudadanos registrados</strong></p>
                                    <p style="margin-top:8px;">Comienza registrando un nuevo ciudadano</p>
                                    <a href="<%= request.getContextPath() %>/ciudadanos?action=nuevo" class="btn-primary-custom" style="margin-top:16px;">
                                        <i class="fas fa-plus"></i> Registrar Ciudadano
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ═══════════════════════════════════════════════════════════
        // SEARCH & FILTER
        // ═══════════════════════════════════════════════════════════
        const searchInput = document.getElementById('searchInput');
        const filterMesa = document.getElementById('filterMesa');
        const rows = document.querySelectorAll('.ciudadano-row');
        
        function filterTable() {
            const searchTerm = searchInput.value.toLowerCase();
            const mesaFilter = filterMesa.value;
            
            rows.forEach(row => {
                const nombre = row.dataset.nombre || '';
                const apellido = row.dataset.apellido || '';
                const documento = row.dataset.documento || '';
                const mesa = row.dataset.mesa || '';
                
                const nombreCompleto = nombre + ' ' + apellido;
                const matchesSearch = nombreCompleto.includes(searchTerm) || documento.includes(searchTerm);
                const matchesMesa = mesaFilter === 'todos' || mesa === mesaFilter;
                
                row.style.display = (matchesSearch && matchesMesa) ? '' : 'none';
            });
        }
        
        searchInput.addEventListener('keyup', filterTable);
        filterMesa.addEventListener('change', filterTable);

        // ═══════════════════════════════════════════════════════════
        // EXPORT TO CSV
        // ═══════════════════════════════════════════════════════════
        function exportToCSV() {
            const visibleRows = Array.from(rows).filter(r => r.style.display !== 'none');
            if (visibleRows.length === 0) {
                showToast('No hay datos para exportar', 'warning');
                return;
            }
            
            let csv = 'Nombre,Apellido,Documento,Vereda/Barrio,Mesa\n';
            visibleRows.forEach(row => {
                const cells = row.querySelectorAll('td');
                if (cells.length >= 5) {
                    const data = [
                        cells[0].textContent.trim(),
                        cells[1].textContent.trim(),
                        cells[2].textContent.trim(),
                        cells[3].textContent.trim(),
                        cells[4].textContent.trim()
                    ];
                    csv += data.map(d => `"${d.replace(/"/g, '""')}"`).join(',') + '\n';
                }
            });
            
            const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'ciudadanos_' + new Date().toISOString().split('T')[0] + '.csv';
            link.click();
            showToast('Exportación completada exitosamente', 'success');
        }

        // ═══════════════════════════════════════════════════════════
        // IMPRESIÓN BONITA - SOLO LISTADO DE CIUDADANOS
        // ═══════════════════════════════════════════════════════════
        function imprimirListado() {
            const visibleRows = Array.from(rows).filter(r => r.style.display !== 'none');
            
            // Obtener datos de las cards
            const totalCiudadanos = '<%= totalCiudadanos %>';
            const conMesa = '<%= conMesa %>';
            const sinMesa = '<%= sinMesa %>';
            
            // Crear ventana de impresión
            const printWindow = window.open('', '_blank', 'width=900,height=600');
            
            printWindow.document.write(`
                <!DOCTYPE html>
                <html lang="es">
                <head>
                    <meta charset="UTF-8">
                    <title>Listado de Ciudadanos - Registraduría Nobsa</title>
                    <style>
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        body {
                            font-family: 'Segoe UI', 'Inter', Arial, sans-serif;
                            background: white;
                            padding: 30px 40px;
                            color: #1e293b;
                        }
                        
                        .print-header {
                            text-align: center;
                            margin-bottom: 30px;
                            padding-bottom: 20px;
                            border-bottom: 3px solid #003366;
                        }
                        
                        .print-header h1 {
                            font-size: 28px;
                            font-weight: 700;
                            color: #003366;
                            margin-bottom: 5px;
                        }
                        
                        .print-header h2 {
                            font-size: 16px;
                            font-weight: 500;
                            color: #64748b;
                            margin-bottom: 10px;
                        }
                        
                        .print-header .date {
                            font-size: 13px;
                            color: #94a3b8;
                        }
                        
                        .stats-mini {
                            display: flex;
                            justify-content: center;
                            gap: 40px;
                            margin-bottom: 25px;
                            padding: 15px;
                            background: #f8fafc;
                            border-radius: 10px;
                        }
                        
                        .stat-item {
                            text-align: center;
                        }
                        
                        .stat-item .stat-num {
                            font-size: 24px;
                            font-weight: 800;
                            color: #003366;
                        }
                        
                        .stat-item .stat-lbl {
                            font-size: 12px;
                            color: #64748b;
                            text-transform: uppercase;
                            letter-spacing: 0.5px;
                        }
                        
                        table {
                            width: 100%;
                            border-collapse: collapse;
                            margin-top: 20px;
                            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
                        }
                        
                        th {
                            background: #003366;
                            color: white;
                            padding: 12px 15px;
                            font-size: 13px;
                            font-weight: 600;
                            text-transform: uppercase;
                            letter-spacing: 0.5px;
                            text-align: left;
                        }
                        
                        td {
                            padding: 10px 15px;
                            border-bottom: 1px solid #e2e8f0;
                            font-size: 13px;
                        }
                        
                        tr:nth-child(even) {
                            background: #f8fafc;
                        }
                        
                        .badge {
                            display: inline-block;
                            padding: 4px 10px;
                            border-radius: 20px;
                            font-size: 11px;
                            font-weight: 600;
                        }
                        
                        .badge-success {
                            background: #d4edda;
                            color: #155724;
                        }
                        
                        .badge-warning {
                            background: #fff3cd;
                            color: #856404;
                        }
                        
                        .print-footer {
                            margin-top: 30px;
                            padding-top: 15px;
                            border-top: 1px solid #e2e8f0;
                            text-align: center;
                            font-size: 11px;
                            color: #94a3b8;
                        }
                        
                        @media print {
                            body { padding: 20px; }
                        }
                    </style>
                </head>
                <body>
                    <div class="print-header">
                        <h1>🇨🇴 Registraduría Municipal de Nobsa</h1>
                        <h2>Listado Oficial de Ciudadanos</h2>
                        <div class="date">Fecha de impresión: ${new Date().toLocaleDateString('es-CO', { 
                            year: 'numeric', month: 'long', day: 'numeric' 
                        })}</div>
                    </div>
                    
                    <div class="stats-mini">
                        <div class="stat-item">
                            <div class="stat-num">${totalCiudadanos}</div>
                            <div class="stat-lbl">Total Ciudadanos</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-num">${conMesa}</div>
                            <div class="stat-lbl">Con Mesa</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-num">${sinMesa}</div>
                            <div class="stat-lbl">Sin Mesa</div>
                        </div>
                    </div>
                    
                    <table>
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Documento</th>
                                <th>Vereda/Barrio</th>
                                <th>Mesa</th>
                            </tr>
                        </thead>
                        <tbody>
            `);
            
            // Agregar filas visibles
            visibleRows.forEach(row => {
                const cells = row.querySelectorAll('td');
                if (cells.length >= 5) {
                    const nombre = cells[0].textContent.trim();
                    const apellido = cells[1].textContent.trim();
                    const documento = cells[2].textContent.trim();
                    const vereda = cells[3].textContent.trim();
                    const mesaHtml = cells[4].innerHTML;
                    
                    const tieneMesa = mesaHtml.includes('badge-success') || mesaHtml.includes('Mesa #');
                    const mesaTexto = tieneMesa 
                        ? `<span class="badge badge-success">${mesaHtml.replace(/<[^>]*>/g, '').trim()}</span>`
                        : `<span class="badge badge-warning">Sin asignar</span>`;
                    
                    printWindow.document.write(`
                        <tr>
                            <td>${nombre}</td>
                            <td>${apellido}</td>
                            <td>${documento}</td>
                            <td>${vereda}</td>
                            <td>${mesaTexto}</td>
                        </tr>
                    `);
                }
            });
            
            printWindow.document.write(`
                        </tbody>
                    </table>
                    
                    <div class="print-footer">
                        <p>© 2026 Registraduría Municipal de Nobsa - Boyacá, Colombia</p>
                        <p>Documento generado electrónicamente - Válido para consulta</p>
                        <p>Total de registros: ${visibleRows.length}</p>
                    </div>
                    
                    <script>
                        window.onload = function() {
                            window.print();
                            setTimeout(function() { window.close(); }, 500);
                        };
                    <\/script>
                </body>
                </html>
            `);
            
            printWindow.document.close();
        }

        // ═══════════════════════════════════════════════════════════
        // TOAST NOTIFICATIONS
        // ═══════════════════════════════════════════════════════════
        function showToast(message, type = 'success') {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            
            const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle' };
            toast.innerHTML = `<i class="fas ${icons[type]}"></i><span>${message}</span>`;
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(100px)';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        // ═══════════════════════════════════════════════════════════
        // KEYBOARD SHORTCUTS
        // ═══════════════════════════════════════════════════════════
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
                e.preventDefault();
                window.location.href = '<%= request.getContextPath() %>/ciudadanos?action=nuevo';
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                searchInput.focus();
            }
        });

        // Theme toggle
        (function() {
            const saved = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', saved);
        })();
    </script>
    <script src="<%= request.getContextPath() %>/js/registraduria.js"></script>
</body>
</html>