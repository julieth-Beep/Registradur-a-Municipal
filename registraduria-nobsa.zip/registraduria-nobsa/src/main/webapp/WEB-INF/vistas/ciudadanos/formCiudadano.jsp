<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.MesaVotacionDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.MesaVotacionDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudadano" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.MesaVotacion" %>
<%@ page import="java.util.*" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    // Verificar si es edición o nuevo
    String idParam = request.getParameter("id");
    Ciudadano ciudadano = null;
    boolean esEdicion = false;
    
    if (idParam != null && !idParam.isEmpty()) {
        try {
            CiudadanoDAO ciudadanoDAO = new CiudadanoDAOImpl();
            ciudadano = ciudadanoDAO.buscarPorId(Integer.parseInt(idParam));
            esEdicion = (ciudadano != null);
        } catch (Exception e) {
            out.println("<!-- ERROR: " + e.getMessage() + " -->");
        }
    }
    
    // Cargar mesas para el select
    List<MesaVotacion> mesas = new ArrayList<MesaVotacion>();
    try {
        MesaVotacionDAO mesaDAO = new MesaVotacionDAOImpl();
        mesas = mesaDAO.listarTodos();
    } catch (Exception e) {
        out.println("<!-- ERROR: " + e.getMessage() + " -->");
    }
    
    // Formatear fecha para el input date
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String fechaNacimientoStr = "";
    if (ciudadano != null && ciudadano.getFechaNacimiento() != null) {
        fechaNacimientoStr = sdf.format(ciudadano.getFechaNacimiento());
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><%= esEdicion ? "Editar" : "Nuevo" %> Ciudadano - Registraduría</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0eef8; font-family: 'Inter', sans-serif; }
        .main-content { margin-left: 260px; padding: 30px; }
        @media (max-width: 992px) { .main-content { margin-left: 0; } }
        .form-card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.04);
            max-width: 800px;
            margin: 0 auto;
        }
        .form-label {
            font-weight: 600;
            color: #18122b;
            margin-bottom: 6px;
        }
        .form-control, .form-select {
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 12px;
            background: white;
        }
        .form-control:focus, .form-select:focus {
            border-color: #003366;
            box-shadow: 0 0 0 3px rgba(0,51,102,0.1);
        }
        .btn-primary {
            background: #003366;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
        }
        .btn-primary:hover {
            background: #1a5276;
        }
        .btn-secondary {
            background: #e2e8f0;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            color: #5a6a7a;
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
        .info-box {
            background: rgba(0,51,102,0.05);
            border-left: 4px solid #003366;
            padding: 16px;
            border-radius: 10px;
            margin-bottom: 24px;
        }
        .documento-bloqueado {
            background: #f7f5fc;
            color: #5a6a7a;
        }
    </style>
</head>
<body>

<%@ include file="/includes/navbar.jsp" %>

<main class="main-content">
    <div style="margin-bottom: 24px;">
        <a href="<%= request.getContextPath() %>/ciudadanos" class="text-decoration-none" style="color: #5a6a7a;">
            <i class="fas fa-arrow-left"></i> Volver a la lista
        </a>
    </div>
    
    <div class="form-card">
        <h3 style="margin-bottom: 24px; font-weight: 700; color: #18122b;">
            <i class="fas fa-<%= esEdicion ? "edit" : "user-plus" %>" style="color: #003366;"></i> 
            <%= esEdicion ? "Editar Ciudadano" : "Registrar Nuevo Ciudadano" %>
        </h3>
        
        <% if (!esEdicion) { %>
        <div class="info-box">
            <i class="fas fa-info-circle"></i>
            <strong>Nota:</strong> La mesa de votación es opcional. Puedes asignarla más tarde.
        </div>
        <% } %>
        
        <form action="<%= request.getContextPath() %>/ciudadanos" method="POST">
            <% if (esEdicion) { %>
                <input type="hidden" name="id" value="<%= ciudadano.getId() %>">
            <% } %>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">
                        <i class="fas fa-id-card"></i> Número de Documento *
                    </label>
                    <input type="text" name="numeroDocumento" class="form-control <%= esEdicion ? "documento-bloqueado" : "" %>" 
                           placeholder="Ej: 1052345678" 
                           value="<%= ciudadano != null ? ciudadano.getNumeroDocumento() : "" %>"
                           required maxlength="20"
                           <%= esEdicion ? "readonly" : "" %>>
                    <% if (esEdicion) { %>
                        <small class="text-muted">El número de documento no se puede modificar</small>
                    <% } %>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">
                        <i class="fas fa-calendar"></i> Fecha de Nacimiento *
                    </label>
                    <input type="date" name="fechaNacimiento" class="form-control" 
                           value="<%= fechaNacimientoStr %>" required>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">
                        <i class="fas fa-user"></i> Nombres *
                    </label>
                    <input type="text" name="nombres" class="form-control" 
                           placeholder="Ej: Carlos Ernesto" 
                           value="<%= ciudadano != null ? ciudadano.getNombres() : "" %>"
                           required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">
                        <i class="fas fa-user"></i> Apellidos *
                    </label>
                    <input type="text" name="apellidos" class="form-control" 
                           placeholder="Ej: Pedraza Rondón" 
                           value="<%= ciudadano != null ? ciudadano.getApellidos() : "" %>"
                           required>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">
                        <i class="fas fa-map-pin"></i> Vereda/Barrio *
                    </label>
                    <input type="text" name="veredaBarrio" class="form-control" 
                           placeholder="Ej: Centro, Heroica, San Martín" 
                           value="<%= ciudadano != null && ciudadano.getVeredaBarrio() != null ? ciudadano.getVeredaBarrio() : "" %>"
                           required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">
                        <i class="fas fa-phone"></i> Teléfono
                    </label>
                    <input type="text" name="telefono" class="form-control" 
                           placeholder="Ej: 3101234567" maxlength="20"
                           value="<%= ciudadano != null && ciudadano.getTelefono() != null ? ciudadano.getTelefono() : "" %>">
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">
                        <i class="fas fa-envelope"></i> Correo Electrónico
                    </label>
                    <input type="email" name="correo" class="form-control" 
                           placeholder="Ej: carlos@email.com"
                           value="<%= ciudadano != null && ciudadano.getCorreo() != null ? ciudadano.getCorreo() : "" %>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">
                        <i class="fas fa-table"></i> Mesa de Votación
                    </label>
                    <select name="idMesa" class="form-select">
                        <option value="">-- Sin asignar mesa --</option>
                        <% for (MesaVotacion m : mesas) { 
                            boolean seleccionada = (ciudadano != null && ciudadano.getIdMesa() != null && 
                                                   ciudadano.getIdMesa().equals(m.getId()));
                        %>
                            <option value="<%= m.getId() %>" <%= seleccionada ? "selected" : "" %>>
                                Mesa #<%= m.getNumeroMesa() %> - <%= m.getNombreZona() %> (<%= m.getNombreCiudad() %>)
                            </option>
                        <% } %>
                    </select>
                    <small class="text-muted">
                        <%= esEdicion ? "Puedes cambiarla o dejarla sin asignar" : "Opcional - Puedes asignarla después" %>
                    </small>
                </div>
            </div>
            
            <hr style="margin: 24px 0;">
            
            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <a href="<%= request.getContextPath() %>/ciudadanos" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <%= esEdicion ? "Actualizar" : "Guardar" %> Ciudadano
                </button>
            </div>
        </form>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>