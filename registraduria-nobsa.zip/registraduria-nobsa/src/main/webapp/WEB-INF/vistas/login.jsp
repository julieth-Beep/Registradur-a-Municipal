<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Registraduría Municipal de Nobsa</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }

        :root {
            --azul:       #003087;
            --azul-med:   #1565C0;
            --rojo:       #B71C1C;
            --oro:        #C8921A;
            --oro-light:  #F5C842;
            --gris-borde: #E4E7ED;
            --texto:      #1A1F36;
            --texto-soft: #6B7590;
            --blanco:     #FFFFFF;
        }

        html, body { 
            height:100%; 
            font-family:'DM Sans',sans-serif; 
            background:#EEF1F7;
            overflow:hidden;
        }

        .wrapper { 
            width:100vw; 
            height:100vh; 
            display:flex; 
            align-items:stretch; 
            justify-content:stretch;
            padding:0;
        }

        .card-outer {
            width:100%; 
            height:100%;
            border-radius:0;
            overflow:hidden; 
            display:flex;
            box-shadow: none;
            animation: none;
        }

        /* ══ PANEL IZQUIERDO - FORMULARIO ══ */
        .panel-left {
            flex:1; 
            background:var(--blanco);
            display:flex; 
            flex-direction:column; 
            justify-content:center;
            padding:60px 80px; 
            position:relative; 
            overflow:hidden;
            order: 1;
        }
        
        .panel-left::before {
            content:''; 
            position:absolute; 
            top:-80px; 
            right:-80px; 
            width:280px; 
            height:280px;
            background:radial-gradient(circle, rgba(0,48,135,0.03) 0%, transparent 70%); 
            pointer-events:none;
        }

        .pr-nav { 
            position:absolute; 
            top:40px; 
            left:50px; 
            right:50px; 
            display:flex; 
            align-items:center; 
            justify-content:space-between; 
            z-index:2; 
        }
        
        .pr-nav-logo { 
            font-size:0.75rem; 
            font-weight:600; 
            color:var(--texto-soft); 
            letter-spacing:0.06em; 
            text-transform:uppercase; 
            display:flex; 
            align-items:center; 
            gap:6px; 
        }
        
        .pr-nav-logo::before { 
            content:''; 
            width:8px; 
            height:8px; 
            border-radius:50%; 
            background:var(--azul); 
        }
        
        .tricolor-mini { 
            display:flex; 
            gap:3px; 
        }
        
        .tricolor-mini span { 
            width:18px; 
            height:4px; 
            border-radius:2px; 
        }
        
        .tc-1{background:var(--azul)} 
        .tc-2{background:var(--rojo)} 
        .tc-3{background:var(--oro-light)}

        /* 🔥 GLASSMORPHISM CARD - EXTREMADAMENTE ANCHA */
        .login-card {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.6);
            border-radius: 28px;
            padding: 55px 100px;
            box-shadow: 
                0 25px 80px rgba(0, 48, 135, 0.12),
                0 0 0 1px rgba(255, 255, 255, 0.4) inset;
            position: relative;
            overflow: hidden;
            z-index: 10;
            max-width: 850px;
            margin: 0 auto;
        }

        .login-card::before {
            content:''; 
            position:absolute; 
            top:-50%; 
            right:-50%; 
            width:200%; 
            height:200%;
            background:radial-gradient(circle, rgba(0,48,135,0.03) 0%, transparent 70%); 
            pointer-events:none;
            animation: shimmer 15s linear infinite;
        }

        @keyframes shimmer {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* 🔥 Botón Volver a Inicio - ABAJO DEL FORMULARIO */
        .btn-volver {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 11px 22px;
            background: rgba(255, 255, 255, 0.95);
            border: 1.5px solid rgba(0, 48, 135, 0.15);
            border-radius: 50px;
            color: var(--azul);
            font-family: 'DM Sans', sans-serif;
            font-size: 0.83rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s cubic-bezier(0.34,1.4,0.64,1);
            box-shadow: 0 3px 12px rgba(0, 48, 135, 0.1);
            margin-top: 20px;
            white-space: nowrap;
        }

        .btn-volver:hover {
            background: rgba(255, 255, 255, 1);
            border-color: var(--azul);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0, 48, 135, 0.2);
        }

        .btn-volver i {
            font-size: 13px;
        }

        /* Header de la card */
        .card-header {
            text-align: center;
            margin-bottom: 35px;
            position: relative;
            z-index: 1;
            padding-top: 10px;
        }

        .card-header h1 {
            font-family: 'Cormorant Garamond', serif;
            font-size: 2.9rem;
            font-weight: 700;
            color: var(--texto);
            line-height: 1.1;
            margin-bottom: 10px;
        }

        .card-header p {
            font-size: 0.95rem;
            color: var(--texto-soft);
            line-height: 1.5;
        }

        .form-area { 
            position:relative; 
            z-index:2; 
            width:100%;
            margin:0 auto; 
        }

        .alert { 
            display:flex; 
            align-items:center; 
            gap:11px; 
            padding:12px 16px; 
            border-radius:12px; 
            font-size:0.88rem; 
            font-weight:500; 
            margin-bottom:20px; 
            border:1.5px solid; 
            animation:fadeIn 0.3s ease; 
        }
        
        @keyframes fadeIn { 
            from{opacity:0;transform:translateY(-6px)} 
            to{opacity:1;transform:translateY(0)} 
        }
        
        .alert-danger { 
            background:#FEF2F2; 
            border-color:#FECACA; 
            color:#DC2626; 
        }
        
        .alert-success { 
            background:#F0FDF4; 
            border-color:#BBF7D0; 
            color:#16A34A; 
        }

        .form-group { 
            margin-bottom:20px; 
        }
        
        .form-label { 
            display:block; 
            font-size:0.83rem; 
            font-weight:600; 
            color:var(--texto); 
            margin-bottom:8px; 
        }
        
        .input-wrap { 
            position:relative; 
        }
        
        .form-control {
            width:100%; 
            padding:14.5px 16px 14.5px 46px;
            background:var(--blanco); 
            border:1.8px solid var(--gris-borde); 
            border-radius:12px;
            font-size:0.93rem; 
            font-family:'DM Sans',sans-serif; 
            color:var(--texto); 
            outline:none; 
            transition:all 0.25s;
        }
        
        .form-control::placeholder { 
            color:#BCC3D0; 
        }
        
        .form-control:focus { 
            border-color:var(--azul); 
            box-shadow:0 0 0 4px rgba(0,48,135,0.08); 
        }
        
        .input-ico { 
            position:absolute; 
            left:16px; 
            top:50%; 
            transform:translateY(-50%); 
            color:#BCC3D0; 
            font-size:14px; 
            pointer-events:none; 
            transition:color 0.25s; 
        }
        
        .form-control:focus ~ .input-ico { 
            color:var(--azul); 
        }

        .options-row {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:26px;
        }

        .remember-me {
            display:flex;
            align-items:center;
            gap:8px;
            font-size:0.85rem;
            color:var(--texto-soft);
            cursor:pointer;
        }

        .remember-me input[type="checkbox"] {
            width:16px;
            height:16px;
            accent-color:var(--azul);
            cursor:pointer;
        }

        .forgot-password {
            font-size:0.85rem;
            color:var(--azul);
            text-decoration:none;
            font-weight:600;
            transition:all 0.3s;
        }

        .forgot-password:hover {
            color:var(--azul-med);
            text-decoration:underline;
        }

        .btn-main {
            width:100%; 
            padding:15.5px; 
            background:var(--azul); 
            border:none; 
            border-radius:12px;
            color:white; 
            font-size:0.96rem; 
            font-weight:700; 
            font-family:'DM Sans',sans-serif; 
            cursor:pointer;
            position:relative; 
            overflow:hidden; 
            transition:all 0.3s;
            box-shadow:0 6px 24px rgba(0,48,135,0.28);
            display:flex; 
            align-items:center; 
            justify-content:center; 
            gap:10px; 
            margin-top:8px;
        }
        
        .btn-main::after { 
            content:''; 
            position:absolute; 
            top:0; 
            left:-100%; 
            width:100%; 
            height:100%; 
            background:linear-gradient(90deg,transparent,rgba(255,255,255,0.14),transparent); 
            transition:left 0.5s; 
        }
        
        .btn-main:hover::after { 
            left:100%; 
        }
        
        .btn-main:hover { 
            background:#00267a; 
            box-shadow:0 10px 32px rgba(0,48,135,0.38); 
            transform:translateY(-2px); 
        }
        
        .btn-main:active { 
            transform:translateY(0); 
        }

        .sep { 
            display:flex; 
            align-items:center; 
            gap:16px; 
            margin:22px 0 18px; 
        }
        
        .sep-line { 
            flex:1; 
            height:1.5px; 
            background:var(--gris-borde); 
        }
        
        .sep-text { 
            font-size:0.8rem; 
            color:#BCC3D0; 
            white-space:nowrap; 
        }

        .liquid-row { 
            display:flex; 
            gap:12px; 
        }
        
        .liq-btn {
            flex:1; 
            display:inline-flex; 
            align-items:center; 
            justify-content:center; 
            gap:8px; 
            padding:12.5px 14px;
            text-decoration:none; 
            font-family:'DM Sans',sans-serif; 
            font-size:0.86rem; 
            font-weight:600; 
            color:var(--texto-soft);
            border-radius:50px; 
            position:relative; 
            overflow:hidden;
            transition:all 0.35s cubic-bezier(0.34,1.4,0.64,1); 
            cursor:pointer; 
            border:none;
            background:linear-gradient(145deg, rgba(255,255,255,0.95) 0%, rgba(240,244,252,0.9) 100%);
            box-shadow: 0 3px 12px rgba(0,30,80,0.09), 0 1px 4px rgba(0,30,80,0.06), inset 0 1px 0 rgba(255,255,255,1), inset 0 -1px 0 rgba(0,30,80,0.05), inset 1px 0 0 rgba(255,255,255,0.9), inset -1px 0 0 rgba(0,30,80,0.03);
            border:1px solid rgba(0,30,80,0.1);
        }
        
        .liq-btn::before { 
            content:''; 
            position:absolute; 
            top:0; 
            left:0; 
            right:0; 
            height:48%; 
            background:linear-gradient(180deg,rgba(255,255,255,0.8) 0%,rgba(255,255,255,0.1) 100%); 
            border-radius:50px 50px 0 0; 
            pointer-events:none; 
        }
        
        .liq-btn:hover { 
            color:var(--azul); 
            transform:translateY(-3px) scale(1.02); 
            box-shadow:0 8px 24px rgba(0,30,80,0.14), 0 3px 10px rgba(0,30,80,0.08), inset 0 1px 0 rgba(255,255,255,1), inset 0 -1px 0 rgba(0,30,80,0.06), inset 1px 0 0 rgba(255,255,255,0.95), inset -1px 0 0 rgba(0,30,80,0.04); 
            border-color:rgba(0,48,135,0.18); 
        }
        
        .liq-btn:active { 
            transform:translateY(0) scale(0.99); 
        }
        
        .liq-btn i { 
            font-size:13px; 
        }

        .form-foot { 
            font-size:0.88rem; 
            color:var(--texto-soft); 
            text-align:center; 
            margin-top:20px; 
        }
        
        .form-foot a { 
            color:var(--azul); 
            font-weight:600; 
            text-decoration:none; 
        }
        
        .form-foot a:hover { 
            text-decoration:underline; 
        }

        .pr-footer { 
            position:absolute; 
            bottom:40px; 
            left:50px; 
            z-index:2; 
        }
        
        .pr-footer-copy { 
            font-size:0.75rem; 
            color:#C8CDD8; 
        }

        /* ══ PANEL DERECHO - VISUAL 3D ══ */
        .panel-right {
            flex:0 0 44%; 
            position:relative; 
            overflow:hidden;
            display:flex; 
            flex-direction:column; 
            justify-content:space-between; 
            padding:60px 70px;
            background:
                radial-gradient(ellipse at 20% 20%, rgba(180,210,255,0.55) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 75%, rgba(212,175,80,0.22) 0%, transparent 55%),
                radial-gradient(ellipse at 60% 10%, rgba(180,220,255,0.3) 0%, transparent 50%),
                radial-gradient(ellipse at 10% 85%, rgba(0,48,135,0.08) 0%, transparent 50%),
                linear-gradient(155deg, #dde8f8 0%, #eef3fb 40%, #f5f0e8 100%);
            order: 2;
        }
        
        .panel-right::before {
            content:''; 
            position:absolute; 
            inset:0;
            background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.03'/%3E%3C/svg%3E");
            pointer-events:none; 
            opacity:0.5;
        }

        .pl-brand { 
            position:relative; 
            z-index:5; 
            display:flex; 
            align-items:center; 
            gap:11px; 
        }
        
        .pl-brand-dot {
            width:34px; 
            height:34px;
            background:linear-gradient(135deg, var(--azul), var(--azul-med));
            border-radius:10px; 
            display:flex; 
            align-items:center; 
            justify-content:center;
            color:white; 
            font-size:15px; 
            box-shadow:0 4px 14px rgba(0,48,135,0.3);
        }
        
        .pl-brand-text { 
            font-size:0.72rem; 
            font-weight:600; 
            color:var(--azul); 
            letter-spacing:0.02em; 
            line-height:1.3; 
        }
        
        .pl-brand-text span { 
            display:block; 
            font-weight:400; 
            color:var(--texto-soft); 
            font-size:0.65rem; 
        }

        /* 🔥 ANIMACIÓN 3D - Cubos flotantes */
        .scene-3d {
            position: absolute;
            width: 400px;
            height: 400px;
            perspective: 1000px;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .cube-container {
            position: relative;
            width: 200px;
            height: 200px;
            transform-style: preserve-3d;
            animation: rotateContainer 20s linear infinite;
        }

        @keyframes rotateContainer {
            0% { transform: rotateX(0deg) rotateY(0deg); }
            100% { transform: rotateX(360deg) rotateY(360deg); }
        }

        .cube {
            position: absolute;
            width: 80px;
            height: 80px;
            transform-style: preserve-3d;
        }

        .cube-1 {
            top: 20px;
            left: 60px;
            animation: floatCube1 6s ease-in-out infinite;
        }

        .cube-2 {
            top: 80px;
            right: 40px;
            animation: floatCube2 7s ease-in-out infinite;
        }

        .cube-3 {
            bottom: 40px;
            left: 40px;
            animation: floatCube3 8s ease-in-out infinite;
        }

        @keyframes floatCube1 {
            0%, 100% { transform: translateY(0) rotateX(0deg) rotateY(0deg); }
            50% { transform: translateY(-20px) rotateX(180deg) rotateY(180deg); }
        }

        @keyframes floatCube2 {
            0%, 100% { transform: translateY(0) rotateX(180deg) rotateY(180deg); }
            50% { transform: translateY(-25px) rotateX(0deg) rotateY(0deg); }
        }

        @keyframes floatCube3 {
            0%, 100% { transform: translateY(0) rotateX(90deg) rotateY(90deg); }
            50% { transform: translateY(-15px) rotateX(270deg) rotateY(270deg); }
        }

        .cube-face {
            position: absolute;
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, rgba(0, 48, 135, 0.8), rgba(26, 82, 118, 0.6));
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 48, 135, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .cube-face:nth-child(1) { transform: rotateY(0deg) translateZ(40px); }
        .cube-face:nth-child(2) { transform: rotateY(90deg) translateZ(40px); }
        .cube-face:nth-child(3) { transform: rotateY(180deg) translateZ(40px); }
        .cube-face:nth-child(4) { transform: rotateY(-90deg) translateZ(40px); }
        .cube-face:nth-child(5) { transform: rotateX(90deg) translateZ(40px); }
        .cube-face:nth-child(6) { transform: rotateX(-90deg) translateZ(40px); }

        .pl-footer { 
            position:relative; 
            z-index:5; 
        }
        
        .pl-quote { 
            font-family:'Cormorant Garamond',serif; 
            font-size:2.2rem; 
            font-weight:600; 
            color:var(--azul); 
            line-height:1.35; 
            margin-bottom:14px; 
        }
        
        .pl-quote em { 
            font-style:normal; 
            color:var(--oro); 
        }
        
        .pl-sub { 
            font-size:1.05rem; 
            color:var(--texto-soft); 
            line-height:1.6; 
        }
        
        .pl-dots { 
            display:flex; 
            gap:8px; 
            margin-top:24px; 
        }
        
        .pl-dot { 
            width:8px; 
            height:8px; 
            border-radius:50%; 
            background:rgba(0,48,135,0.15); 
        }
        
        .pl-dot.active { 
            background:var(--azul); 
            width:28px; 
            border-radius:4px; 
        }

        .loading { 
            display:inline-block; 
            width:18px; 
            height:18px; 
            border:2.5px solid rgba(255,255,255,0.3); 
            border-radius:50%; 
            border-top-color:white; 
            animation:spin 0.8s linear infinite; 
        }
        
        @keyframes spin { 
            to{transform:rotate(360deg)} 
        }

        @media (max-width:1024px) {
            .panel-right { 
                display:none; 
            }
            .panel-left { 
                padding:40px 50px; 
            }
            .card-header h1 { 
                font-size:2.4rem; 
            }
        }
        
        @media (max-width:768px) {
            .panel-left { 
                padding:40px 30px; 
            }
            .login-card {
                padding: 45px 35px;
            }
            .card-header h1 { 
                font-size:2rem; 
            }
            .liquid-row { 
                flex-direction:column; 
            }
            .pr-nav { 
                top:30px; 
                left:30px; 
                right:30px; 
            }
            .pr-footer { 
                bottom:30px; 
                left:30px; 
            }
        }
    </style>
</head>
<body>
<div class="wrapper">
    <div class="card-outer">

        <!-- PANEL IZQUIERDO - FORMULARIO -->
        <div class="panel-left">
            <div class="pr-nav">
                <span class="pr-nav-logo">Sistema Civil Electoral</span>
                <div class="tricolor-mini">
                    <span class="tc-1"></span><span class="tc-2"></span><span class="tc-3"></span>
                </div>
            </div>

            <!-- 🔥 GLASSMORPHISM CARD -->
            <div class="login-card">
                <!-- Header de la card -->
                <div class="card-header">
                    <h1>Iniciar sesión.</h1>
                    <p>Ingresa tus credenciales para acceder al sistema.</p>
                </div>

                <!-- Alerts -->
                <% if (request.getAttribute("error") != null) { %>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><%= request.getAttribute("error") %></span>
                    </div>
                <% } %>
                
                <% if (request.getAttribute("success") != null) { %>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <span><%= request.getAttribute("success") %></span>
                    </div>
                <% } %>

                <form action="<%= request.getContextPath() %>/login" method="POST">
                    <div class="form-group">
                        <label class="form-label">Usuario o Correo Electrónico</label>
                        <div class="input-wrap">
                            <input type="text" name="username" class="form-control" placeholder="Ingresa tu usuario" required autofocus>
                            <i class="fas fa-user input-ico"></i>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Contraseña</label>
                        <div class="input-wrap">
                            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                            <i class="fas fa-lock input-ico"></i>
                        </div>
                    </div>

                    <div class="options-row">
                        <label class="remember-me">
                            <input type="checkbox" name="remember">
                            <span>Recordarme</span>
                        </label>
                        <a href="#" class="forgot-password">¿Olvidaste tu contraseña?</a>
                    </div>

                    <button type="submit" class="btn-main" id="btnLogin">
                        <i class="fas fa-sign-in-alt"></i>
                        <span>Iniciar sesión</span>
                    </button>
                </form>

                <div class="sep">
                    <div class="sep-line"></div>
                    <span class="sep-text">o continúa con</span>
                    <div class="sep-line"></div>
                </div>

                <div class="liquid-row">
                    <button type="button" class="liq-btn google">
                        <i class="fab fa-google"></i>
                        <span>Google</span>
                    </button>
                    <button type="button" class="liq-btn facebook">
                        <i class="fab fa-facebook-f"></i>
                        <span>Facebook</span>
                    </button>
                </div>

                <div class="form-foot">
                    <p>¿No tienes cuenta? <a href="<%= request.getContextPath() %>/registro-votante">Regístrate aquí</a></p>
                    
                    <!-- 🔥 Botón Volver a Inicio - ABAJO DEL ENLACE DE REGISTRO -->
                    <a href="<%= request.getContextPath() %>/" class="btn-volver">
                        <i class="fas fa-home"></i>
                        <span>Volver a Inicio</span>
                    </a>
                </div>
            </div>

            <div class="pr-footer">
                <span class="pr-footer-copy">© 2026 Registraduría Municipal de Nobsa</span>
            </div>
        </div>

        <!-- PANEL DERECHO - VISUAL 3D -->
        <div class="panel-right">
            <div class="pl-brand">
                <div class="pl-brand-dot"><i class="fas fa-landmark"></i></div>
                <div class="pl-brand-text">
                    Registraduría Municipal
                    <span>Nobsa · Boyacá, Colombia</span>
                </div>
            </div>

            <div class="scene-3d">
                <div class="cube-container">
                    <!-- Cubo 1 -->
                    <div class="cube cube-1">
                        <div class="cube-face"><i class="fas fa-shield-alt"></i></div>
                        <div class="cube-face"><i class="fas fa-shield-alt"></i></div>
                        <div class="cube-face"><i class="fas fa-shield-alt"></i></div>
                        <div class="cube-face"><i class="fas fa-shield-alt"></i></div>
                        <div class="cube-face"><i class="fas fa-shield-alt"></i></div>
                        <div class="cube-face"><i class="fas fa-shield-alt"></i></div>
                    </div>
                    <!-- Cubo 2 -->
                    <div class="cube cube-2">
                        <div class="cube-face"><i class="fas fa-id-card"></i></div>
                        <div class="cube-face"><i class="fas fa-id-card"></i></div>
                        <div class="cube-face"><i class="fas fa-id-card"></i></div>
                        <div class="cube-face"><i class="fas fa-id-card"></i></div>
                        <div class="cube-face"><i class="fas fa-id-card"></i></div>
                        <div class="cube-face"><i class="fas fa-id-card"></i></div>
                    </div>
                    <!-- Cubo 3 -->
                    <div class="cube cube-3">
                        <div class="cube-face"><i class="fas fa-vote-yea"></i></div>
                        <div class="cube-face"><i class="fas fa-vote-yea"></i></div>
                        <div class="cube-face"><i class="fas fa-vote-yea"></i></div>
                        <div class="cube-face"><i class="fas fa-vote-yea"></i></div>
                        <div class="cube-face"><i class="fas fa-vote-yea"></i></div>
                        <div class="cube-face"><i class="fas fa-vote-yea"></i></div>
                    </div>
                </div>
            </div>

            <div class="pl-footer">
                <p class="pl-quote">Tu identidad civil,<br><em>protegida y digital.</em></p>
                <p class="pl-sub">Accede a tu cuenta para consultar<br>tu lugar de votación y documentos.</p>
                <div class="pl-dots">
                    <div class="pl-dot active"></div>
                    <div class="pl-dot"></div>
                    <div class="pl-dot"></div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
    document.querySelectorAll('.form-control').forEach(inp => {
        inp.addEventListener('focus', () => { if(inp.nextElementSibling) inp.nextElementSibling.style.color='#003087'; });
        inp.addEventListener('blur',  () => { if(!inp.value && inp.nextElementSibling) inp.nextElementSibling.style.color=''; });
    });
    
    document.querySelector('form').addEventListener('submit', function() {
        const btn = document.getElementById('btnLogin');
        btn.innerHTML = '<span class="loading"></span> Iniciando sesión...';
        btn.disabled = true;
    });
</script>
</body>
</html>