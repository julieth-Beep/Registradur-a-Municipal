<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.ZonaVotacionDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.ZonaVotacionDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.ZonaVotacion" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudad" %>
<%@ page import="java.util.*" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    // Verificar si es edición o nuevo
    String idParam = request.getParameter("id");
    ZonaVotacion zona = null;
    boolean esEdicion = false;
    
    if (idParam != null && !idParam.isEmpty()) {
        try {
            ZonaVotacionDAO zonaDAO = new ZonaVotacionDAOImpl();
            zona = zonaDAO.buscarPorId(Integer.parseInt(idParam));
            esEdicion = (zona != null);
        } catch (Exception e) {
            out.println("<!-- ERROR: " + e.getMessage() + " -->");
        }
    }
    
    // Cargar ciudades para el select
    List<Ciudad> ciudades = new ArrayList<Ciudad>();
    try {
        CiudadDAO ciudadDAO = new CiudadDAOImpl();
        ciudades = ciudadDAO.listarTodos();
    } catch (Exception e) {
        out.println("<!-- ERROR: " + e.getMessage() + " -->");
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><%= esEdicion ? "Editar" : "Nueva" %> Zona de Votación - Registraduría</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0eef8; font-family: 'Inter', sans-serif; }
        .main-content { margin-left: 260px; padding: 30px; }
        @media (max-width: 992px) { .main-content { margin-left: 0; } }
        .form-card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.04);
            max-width: 700px;
            margin: 0 auto;
        }
        .form-label {
            font-weight: 600;
            color: #18122b;
            margin-bottom: 6px;
        }
        .form-control, .form-select {
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 12px;
            background: white;
        }
        .form-control:focus, .form-select:focus {
            border-color: #003366;
            box-shadow: 0 0 0 3px rgba(0,51,102,0.1);
        }
        .btn-primary {
            background: #003366;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
        }
        .btn-primary:hover {
            background: #1a5276;
        }
        .btn-secondary {
            background: #e2e8f0;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            color: #5a6a7a;
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
        .info-box {
            background: rgba(0,51,102,0.05);
            border-left: 4px solid #003366;
            padding: 16px;
            border-radius: 10px;
            margin-bottom: 24px;
        }
    </style>
</head>
<body>

<%@ include file="/includes/navbar.jsp" %>

<main class="main-content">
    <div style="margin-bottom: 24px;">
        <a href="<%= request.getContextPath() %>/admin/zonas" class="text-decoration-none" style="color: #5a6a7a;">
            <i class="fas fa-arrow-left"></i> Volver a la lista
        </a>
    </div>
    
    <div class="form-card">
        <h3 style="margin-bottom: 24px; font-weight: 700; color: #18122b;">
            <i class="fas fa-<%= esEdicion ? "edit" : "map-marker-alt" %>" style="color: #003366;"></i> 
            <%= esEdicion ? "Editar Zona de Votación" : "Registrar Nueva Zona de Votación" %>
        </h3>
        
        <div class="info-box">
            <i class="fas fa-info-circle"></i>
            <strong>Información:</strong> Una zona de votación agrupa varias mesas en un mismo puesto de votación.
        </div>
        
        <form action="<%= request.getContextPath() %>/admin/zonas" method="POST">
            <% if (esEdicion) { %>
                <input type="hidden" name="id" value="<%= zona.getId() %>">
            <% } %>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-city"></i> Ciudad *
                </label>
                <select name="idCiudad" class="form-select" required>
                    <option value="">-- Seleccione una ciudad --</option>
                    <% for (Ciudad c : ciudades) { 
                        boolean seleccionada = (zona != null && zona.getIdCiudad() == c.getId());
                    %>
                        <option value="<%= c.getId() %>" <%= seleccionada ? "selected" : "" %>>
                            <%= c.getNombre() %> - <%= c.getDepartamento() %>
                        </option>
                    <% } %>
                </select>
            </div>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-tag"></i> Nombre de la Zona *
                </label>
                <input type="text" name="nombreZona" class="form-control" 
                       placeholder="Ej: Zona Centro, Zona Norte, Zona Heroica" 
                       value="<%= zona != null ? zona.getNombreZona() : "" %>"
                       required>
            </div>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-school"></i> Puesto de Votación *
                </label>
                <input type="text" name="puestoVotacion" class="form-control" 
                       placeholder="Ej: Institución Educativa Nobsa, Colegio Técnico Industrial" 
                       value="<%= zona != null ? zona.getPuestoVotacion() : "" %>"
                       required>
            </div>
            
            <div class="mb-4">
                <label class="form-label">
                    <i class="fas fa-map-pin"></i> Dirección *
                </label>
                <input type="text" name="direccion" class="form-control" 
                       placeholder="Ej: Calle 5 # 4-32, Centro" 
                       value="<%= zona != null ? zona.getDireccion() : "" %>"
                       required>
            </div>
            
            <hr style="margin: 24px 0;">
            
            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <a href="<%= request.getContextPath() %>/admin/zonas" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <%= esEdicion ? "Actualizar" : "Guardar" %> Zona
                </button>
            </div>
        </form>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>