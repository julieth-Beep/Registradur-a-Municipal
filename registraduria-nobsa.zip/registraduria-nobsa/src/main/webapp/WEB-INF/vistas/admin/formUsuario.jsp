<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.UsuarioDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.UsuarioDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudadano" %>
<%@ page import="java.util.*" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    // Verificar si es edición o nuevo
    String idParam = request.getParameter("id");
    Usuario usuario = null;
    boolean esEdicion = false;
    
    if (idParam != null && !idParam.isEmpty()) {
        try {
            UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
            usuario = usuarioDAO.buscarPorId(Integer.parseInt(idParam));
            esEdicion = (usuario != null);
        } catch (Exception e) {
            out.println("<!-- ERROR: " + e.getMessage() + " -->");
        }
    }
    
    // Cargar ciudadanos para el select (SOLO LOS QUE NO TIENEN USUARIO ASIGNADO)
    List<Ciudadano> ciudadanosDisponibles = new ArrayList<Ciudadano>();
    try {
        CiudadanoDAO ciudadanoDAO = new CiudadanoDAOImpl();
        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
        List<Ciudadano> todosCiudadanos = ciudadanoDAO.listarTodos();
        List<Usuario> todosUsuarios = usuarioDAO.listarTodos();
        
        // Crear conjunto de documentos que ya tienen usuario
        Set<String> docsConUsuario = new HashSet<String>();
        for (Usuario u : todosUsuarios) {
            if (u.getDocumento() != null) {
                docsConUsuario.add(u.getDocumento());
            }
        }
        
        // Si es edición, permitir el documento actual
        String documentoActual = (usuario != null) ? usuario.getDocumento() : null;
        
        for (Ciudadano c : todosCiudadanos) {
            String doc = c.getNumeroDocumento();
            // Incluir si NO tiene usuario O es el documento actual (en edición)
            if (!docsConUsuario.contains(doc) || (esEdicion && doc.equals(documentoActual))) {
                ciudadanosDisponibles.add(c);
            }
        }
    } catch (Exception e) {
        out.println("<!-- ERROR: " + e.getMessage() + " -->");
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><%= esEdicion ? "Editar" : "Nuevo" %> Usuario - Registraduría</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0eef8; font-family: 'Inter', sans-serif; }
        .main-content { margin-left: 260px; padding: 30px; }
        @media (max-width: 992px) { .main-content { margin-left: 0; } }
        .form-card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.04);
            max-width: 600px;
            margin: 0 auto;
        }
        .form-label {
            font-weight: 600;
            color: #18122b;
            margin-bottom: 6px;
        }
        .form-control, .form-select {
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 12px;
            background: white;
        }
        .form-control:focus, .form-select:focus {
            border-color: #003366;
            box-shadow: 0 0 0 3px rgba(0,51,102,0.1);
        }
        .btn-primary {
            background: #003366;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
        }
        .btn-primary:hover { background: #1a5276; }
        .btn-secondary {
            background: #e2e8f0;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            color: #5a6a7a;
        }
        .btn-secondary:hover { background: #cbd5e1; }
        .info-box {
            background: rgba(0,51,102,0.05);
            border-left: 4px solid #003366;
            padding: 16px;
            border-radius: 10px;
            margin-bottom: 24px;
        }
        .warning-box {
            background: rgba(245,158,11,0.05);
            border-left: 4px solid #f59e0b;
            padding: 16px;
            border-radius: 10px;
            margin-bottom: 24px;
        }
    </style>
</head>
<body>

<%@ include file="/includes/navbar.jsp" %>

<main class="main-content">
    <div style="margin-bottom: 24px;">
        <a href="<%= request.getContextPath() %>/admin/usuarios" class="text-decoration-none" style="color: #5a6a7a;">
            <i class="fas fa-arrow-left"></i> Volver a la lista
        </a>
    </div>
    
    <div class="form-card">
        <h3 style="margin-bottom: 24px; font-weight: 700; color: #18122b;">
            <i class="fas fa-<%= esEdicion ? "edit" : "user-plus" %>" style="color: #003366;"></i> 
            <%= esEdicion ? "Editar Usuario" : "Registrar Nuevo Usuario" %>
        </h3>
        
        <% if (ciudadanosDisponibles.isEmpty() && !esEdicion) { %>
        <div class="warning-box">
            <i class="fas fa-exclamation-triangle" style="color: #f59e0b;"></i>
            <strong>Atención:</strong> No hay ciudadanos disponibles para crear usuarios. 
            Todos los ciudadanos ya tienen una cuenta asociada.
        </div>
        <% } %>
        
        <div class="info-box">
            <i class="fas fa-info-circle"></i>
            <strong>Importante:</strong> Solo se pueden crear usuarios para ciudadanos que estén registrados 
            en el sistema y que no tengan una cuenta activa.
        </div>
        
        <form action="<%= request.getContextPath() %>/admin/usuarios" method="POST">
            <% if (esEdicion) { %>
                <input type="hidden" name="id" value="<%= usuario.getId() %>">
            <% } %>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-id-card"></i> Ciudadano *
                </label>
                <select name="documento" class="form-select" required <%= esEdicion ? "disabled style='background:#f7f5fc;'" : "" %>>
                    <option value="">-- Seleccione un ciudadano --</option>
                    <% for (Ciudadano c : ciudadanosDisponibles) { 
                        boolean seleccionado = (usuario != null && c.getNumeroDocumento().equals(usuario.getDocumento()));
                    %>
                        <option value="<%= c.getNumeroDocumento() %>" <%= seleccionado ? "selected" : "" %>>
                            <%= c.getNombreCompleto() %> - CC: <%= c.getNumeroDocumento() %>
                        </option>
                    <% } %>
                </select>
                <% if (esEdicion) { %>
                    <input type="hidden" name="documento" value="<%= usuario.getDocumento() %>">
                    <small class="text-muted">El documento no se puede modificar</small>
                <% } %>
            </div>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-user"></i> Nombre de Usuario *
                </label>
                <input type="text" name="username" class="form-control" 
                       placeholder="Ej: carlos.admin" 
                       value="<%= usuario != null ? usuario.getUsername() : "" %>"
                       required minlength="4">
                <small class="text-muted">Mínimo 4 caracteres</small>
            </div>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-lock"></i> Contraseña 
                    <%= esEdicion ? "(Dejar vacío para mantener)" : "*" %>
                </label>
                <input type="password" name="password" class="form-control" 
                       placeholder="<%= esEdicion ? "••••••••" : "Mínimo 6 caracteres" %>"
                       <%= esEdicion ? "" : "required minlength='6'" %>>
                <% if (esEdicion) { %>
                    <small class="text-muted">Dejar vacío para no cambiar la contraseña</small>
                <% } else { %>
                    <small class="text-muted">Mínimo 6 caracteres</small>
                <% } %>
            </div>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-user-tag"></i> Tipo de Usuario *
                </label>
                <select name="tipoUsuario" class="form-select" required>
                    <option value="VOTANTE" <%= (usuario != null && "VOTANTE".equals(usuario.getTipoUsuario())) ? "selected" : "" %>>Votante</option>
                    <option value="ADMIN" <%= (usuario != null && "ADMIN".equals(usuario.getTipoUsuario())) ? "selected" : "" %>>Administrador</option>
                </select>
            </div>
            
            <% if (esEdicion) { %>
            <div class="mb-4">
                <label class="form-label">
                    <i class="fas fa-toggle-on"></i> Estado
                </label>
                <select name="estado" class="form-select">
                    <option value="activo" <%= (usuario != null && "activo".equals(usuario.getEstado())) ? "selected" : "" %>>Activo</option>
                    <option value="inactivo" <%= (usuario != null && "inactivo".equals(usuario.getEstado())) ? "selected" : "" %>>Inactivo</option>
                </select>
            </div>
            <% } %>
            
            <hr style="margin: 24px 0;">
            
            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <a href="<%= request.getContextPath() %>/admin/usuarios" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
                <button type="submit" class="btn btn-primary" <%= (!esEdicion && ciudadanosDisponibles.isEmpty()) ? "disabled" : "" %>>
                    <i class="fas fa-save"></i> <%= esEdicion ? "Actualizar" : "Guardar" %> Usuario
                </button>
            </div>
        </form>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>