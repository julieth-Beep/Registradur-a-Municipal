<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudad" %>
<%@ page import="java.util.*" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    // Obtener datos del request (calculados en el Servlet)
    List<Ciudad> ciudades = (List<Ciudad>) request.getAttribute("ciudades");
    Integer totalCiudades = (Integer) request.getAttribute("totalCiudades");
    Integer totalDepartamentos = (Integer) request.getAttribute("totalDepartamentos");
    Integer conCodigoDane = (Integer) request.getAttribute("conCodigoDane");
    
    // Si no vienen del servlet, calcularlos aquí (fallback)
    if (ciudades == null) {
        ciudades = new ArrayList<Ciudad>();
    }
    if (totalCiudades == null) {
        totalCiudades = ciudades.size();
    }
    if (totalDepartamentos == null) {
        Set<String> deptos = new HashSet<String>();
        conCodigoDane = 0;
        for (Ciudad c : ciudades) {
            if (c.getDepartamento() != null && !c.getDepartamento().isEmpty()) {
                deptos.add(c.getDepartamento());
            }
            if (c.getCodigoDane() != null && !c.getCodigoDane().isEmpty()) {
                conCodigoDane++;
            }
        }
        totalDepartamentos = deptos.size();
    }
    if (conCodigoDane == null) {
        conCodigoDane = 0;
        for (Ciudad c : ciudades) {
            if (c.getCodigoDane() != null && !c.getCodigoDane().isEmpty()) {
                conCodigoDane++;
            }
        }
    }
    
    // Mensajes de éxito
    String success = request.getParameter("success");
    String mensajeExito = "";
    if ("creado".equals(success)) {
        mensajeExito = "Ciudad creada exitosamente";
    } else if ("actualizado".equals(success)) {
        mensajeExito = "Ciudad actualizada exitosamente";
    } else if ("eliminado".equals(success)) {
        mensajeExito = "Ciudad eliminada exitosamente";
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Ciudades | Registraduría Municipal de Nobsa</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ═══════════════════════════════════════════════════════════ */
        /* DESIGN TOKENS - Registraduría Premium */
        /* ═══════════════════════════════════════════════════════════ */
        :root {
            --primary-900: #001a3a;
            --primary-800: #003366;
            --primary-700: #004080;
            --primary-600: #0055A4;
            --primary-500: #1a6bc4;
            --primary-100: #dbeafe;
            --primary-50: #eff6ff;
            
            --accent-red: #CE1126;
            --accent-yellow: #FCD116;
            
            --bg: #f8fafc;
            --surface: rgba(255, 255, 255, 0.85);
            --surface-2: rgba(248, 250, 252, 0.85);
            --border: rgba(0, 51, 102, 0.12);
            --txt: #0f172a;
            --txt-muted: #64748b;
            --txt-light: #94a3b8;
            
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            
            --glass-bg: rgba(255, 255, 255, 0.75);
            --glass-border: rgba(255, 255, 255, 0.25);
            --glass-shadow: 0 8px 32px rgba(0, 51, 102, 0.08);
            --glass-blur: blur(16px);
            
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.04);
            --shadow-md: 0 4px 12px rgba(0, 51, 102, 0.08);
            --shadow-lg: 0 12px 32px rgba(0, 51, 102, 0.12);
            --shadow-glow: 0 0 40px rgba(0, 85, 164, 0.15);
            
            --radius-sm: 12px;
            --radius-md: 16px;
            --radius-lg: 20px;
            --radius-xl: 24px;
            --radius-2xl: 32px;
            
            --font-sans: 'Plus Jakarta Sans', sans-serif;
            --font-display: 'Space Grotesk', sans-serif;
            
            --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
            --duration-fast: 200ms;
            --duration-normal: 350ms;
        }

        [data-theme="dark"] {
            --bg: #0f172a;
            --surface: rgba(30, 41, 59, 0.85);
            --surface-2: rgba(23, 33, 54, 0.85);
            --border: rgba(255, 255, 255, 0.12);
            --txt: #f1f5f9;
            --txt-muted: #94a3b8;
            --txt-light: #64748b;
            --glass-bg: rgba(30, 41, 59, 0.75);
            --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        
        body {
            font-family: var(--font-sans);
            background: var(--bg);
            color: var(--txt);
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        /* Ambient Background - ORIGINAL */
        .ambient-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }
        .ambient-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.08;
            animation: float 20s ease-in-out infinite;
        }
        .ambient-blob-1 {
            width: 600px; height: 600px;
            background: var(--primary-600);
            top: -100px; right: -100px;
        }
        .ambient-blob-2 {
            width: 400px; height: 400px;
            background: var(--accent-yellow);
            bottom: -50px; left: -50px;
            animation-delay: -10s;
        }
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(20px, -20px) scale(1.05); }
        }

        .grid-pattern {
            position: fixed;
            inset: 0;
            background-image: 
                linear-gradient(rgba(0, 51, 102, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 51, 102, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: 0;
            pointer-events: none;
        }

        /* Glass Card Base */
        .glass {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            -webkit-backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
        }
        .glass:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
        }

        /* Layout */
        .main-content {
            margin-left: 280px;
            padding: 40px 32px 48px;
            min-height: 100vh;
            position: relative;
            z-index: 10;
        }
        @media (max-width: 1024px) {
            .main-content { margin-left: 0; padding: 24px 20px 40px; }
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            gap: 16px;
            flex-wrap: wrap;
            animation: fadeInDown 0.6s var(--ease-out) both;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-title {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 700;
            color: var(--txt);
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0;
        }
        .page-title i { color: var(--primary-600); font-size: 24px; }

        .page-subtitle {
            font-size: 14px;
            color: var(--txt-muted);
            margin-top: 4px;
            font-weight: 500;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary-600), var(--primary-800));
            border: none;
            padding: 12px 24px;
            border-radius: var(--radius-md);
            color: white;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all var(--duration-normal) var(--ease-out);
            box-shadow: var(--shadow-md), var(--shadow-glow);
        }
        .btn-primary-custom:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg), var(--shadow-glow);
            color: white;
        }

        /* Stats Cards */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }
        @media (max-width: 768px) { .stats-row { grid-template-columns: 1fr; } }

        .stat-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-xl);
            padding: 24px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
            animation: fadeInUp 0.5s var(--ease-out) both;
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-600), var(--accent-yellow));
            transform: scaleX(0);
            transform-origin: left;
            transition: transform var(--duration-normal) var(--ease-out);
        }
        .stat-card:hover::before { transform: scaleX(1); }
        .stat-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg), var(--glass-shadow); }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .stat-icon {
            width: 56px;
            height: 56px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }
        .stat-icon.primary { background: rgba(0, 85, 164, 0.12); color: var(--primary-600); }
        .stat-icon.success { background: rgba(16, 185, 129, 0.12); color: var(--success); }
        .stat-icon.warning { background: rgba(245, 158, 11, 0.12); color: var(--warning); }

        .stat-content { flex: 1; }
        .stat-value {
            font-family: var(--font-display);
            font-size: 32px;
            font-weight: 800;
            color: var(--txt);
            line-height: 1;
            margin-bottom: 4px;
        }
        .stat-label {
            font-size: 13px;
            color: var(--txt-muted);
            font-weight: 500;
        }

        /* Toolbar */
        .toolbar {
            display: flex;
            gap: 16px;
            margin-bottom: 20px;
            padding: 16px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--glass-shadow);
            flex-wrap: wrap;
        }

        .search-box {
            flex: 1;
            min-width: 250px;
            display: flex;
            align-items: center;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 8px 16px;
        }
        .search-box input {
            border: none;
            padding: 10px;
            width: 100%;
            background: transparent;
            color: var(--txt);
            font-size: 14px;
        }
        .search-box input:focus { outline: none; }
        .search-box i { color: var(--txt-muted); }

        .filter-select {
            padding: 10px 20px;
            border-radius: var(--radius-md);
            background: var(--surface-2);
            border: 1px solid var(--border);
            color: var(--txt);
            font-size: 14px;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .filter-select:focus {
            outline: none;
            border-color: var(--primary-600);
            box-shadow: 0 0 0 3px rgba(0, 85, 164, 0.1);
        }

        .export-btn {
            padding: 10px 20px;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--txt);
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
            text-decoration: none;
        }
        .export-btn:hover {
            background: var(--primary-600);
            color: white;
            border-color: var(--primary-600);
        }

        /* ═══════════════════════════════════════════════════════════ */
        /* CITIES GRID - Visual Card Design (NO TABLE) */
        /* ═══════════════════════════════════════════════════════════ */
        
        .cities-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 24px;
        }
        @media (max-width: 768px) {
            .cities-grid { grid-template-columns: 1fr; }
        }

        .city-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-2xl);
            overflow: hidden;
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
            animation: fadeInUp 0.5s var(--ease-out) both;
            display: flex;
            flex-direction: column;
            position: relative;
        }
        .city-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-600), var(--accent-yellow));
            transform: scaleX(0);
            transform-origin: left;
            transition: transform var(--duration-normal) var(--ease-out);
        }
        .city-card:hover::before { transform: scaleX(1); }
        .city-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
            border-color: var(--primary-300);
        }

        .city-card-header {
            padding: 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 16px;
            background: var(--surface-2);
        }
        .city-icon-wrapper {
            width: 56px;
            height: 56px;
            background: linear-gradient(135deg, var(--primary-100), var(--primary-50));
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-600);
            font-size: 24px;
            flex-shrink: 0;
            box-shadow: 0 4px 12px rgba(0, 85, 164, 0.1);
        }
        .city-name {
            font-family: var(--font-display);
            font-size: 20px;
            font-weight: 700;
            color: var(--txt);
            line-height: 1.3;
        }

        .city-card-body {
            padding: 24px;
            flex: 1;
        }
        .city-info-row {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px dashed var(--border);
        }
        .city-info-row:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }
        .city-info-row i {
            width: 20px;
            text-align: center;
            font-size: 16px;
            color: var(--primary-600);
        }
        .city-info-label {
            font-size: 12px;
            color: var(--txt-muted);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            min-width: 110px;
        }
        .city-info-value {
            font-size: 15px;
            font-weight: 600;
            color: var(--txt);
            flex: 1;
        }

        .city-card-footer {
            padding: 20px 24px;
            border-top: 1px solid var(--border);
            background: var(--surface-2);
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }

        /* Badge DANE */
        .badge-dane {
            background: rgba(0, 85, 164, 0.12);
            color: var(--primary-600);
            padding: 4px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            font-family: monospace;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: var(--txt-muted);
            animation: fadeInUp 0.6s var(--ease-out) both;
        }
        .empty-state i {
            font-size: 64px;
            opacity: 0.2;
            margin-bottom: 20px;
            display: block;
        }
        .empty-state h4 {
            font-family: var(--font-display);
            font-size: 20px;
            font-weight: 700;
            color: var(--txt);
            margin-bottom: 8px;
        }
        .empty-state p {
            font-size: 14px;
            max-width: 400px;
            margin: 0 auto;
        }

        /* Alert Success */
        .alert-success {
            background: rgba(16, 185, 129, 0.12);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: var(--success);
            padding: 16px 20px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s var(--ease-out) both;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Toast Notifications */
        .toast-container {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .toast {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 16px 20px;
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 320px;
            animation: slideInRight 0.3s var(--ease-out) both;
        }
        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(100px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .toast.success { border-left: 4px solid var(--success); }
        .toast.error { border-left: 4px solid var(--error); }
        .toast.warning { border-left: 4px solid var(--warning); }
        .toast i { font-size: 18px; }
        .toast.success i { color: var(--success); }
        .toast.error i { color: var(--error); }
        .toast.warning i { color: var(--warning); }

        /* Responsive */
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: 1fr; }
            .toolbar { flex-direction: column; }
            .search-box { min-width: 100%; }
            .city-card-header { flex-direction: column; text-align: center; }
            .city-card-footer { justify-content: center; }
        }
    </style>
</head>
<body>

    <!-- Ambient Background - ORIGINAL -->
    <div class="ambient-bg">
        <div class="ambient-blob ambient-blob-1"></div>
        <div class="ambient-blob ambient-blob-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>

    <%@ include file="/includes/navbar.jsp" %>

    <main class="main-content">
        
        <!-- Success Message -->
        <% if (!mensajeExito.isEmpty()) { %>
        <div class="alert-success">
            <i class="fas fa-check-circle"></i>
            <span><%= mensajeExito %></span>
            <button onclick="this.parentElement.remove()" style="margin-left:auto;background:none;border:none;color:inherit;cursor:pointer;font-size:18px;">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <% } %>
        
        <!-- Page Header -->
        <div class="page-header">
            <div>
                <h1 class="page-title">
                    <i class="fas fa-city"></i> 
                    Gestión de Ciudades
                </h1>
                <p class="page-subtitle"><%= totalCiudades %> ciudades registradas en <%= totalDepartamentos %> departamentos</p>
            </div>
            <a href="<%= request.getContextPath() %>/admin/ciudades?action=nuevo" class="btn-primary-custom">
                <i class="fas fa-plus"></i> Nueva Ciudad
            </a>
        </div>

        <!-- Stats Cards -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-icon primary"><i class="fas fa-city"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= totalCiudades %></div>
                    <div class="stat-label">Total de Ciudades</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon success"><i class="fas fa-map-marked-alt"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= totalDepartamentos %></div>
                    <div class="stat-label">Departamentos</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon warning"><i class="fas fa-hashtag"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= conCodigoDane %></div>
                    <div class="stat-label">Con Código DANE</div>
                </div>
            </div>
        </div>

        <!-- Toolbar -->
        <div class="toolbar">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="searchInput" placeholder="Buscar por nombre, departamento o código DANE..." autocomplete="off">
            </div>
            <select id="filterDepartamento" class="filter-select">
                <option value="todos">Todos los departamentos</option>
                <% 
                Set<String> deptosUnicos = new HashSet<String>();
                for (Ciudad c : ciudades) {
                    if (c.getDepartamento() != null && !c.getDepartamento().isEmpty()) {
                        deptosUnicos.add(c.getDepartamento());
                    }
                }
                for (String depto : deptosUnicos) {
                %>
                <option value="<%= depto %>"><%= depto %></option>
                <% } %>
            </select>
            <button class="export-btn glass" onclick="exportToCSV()">
                <i class="fas fa-file-csv"></i> Exportar CSV
            </button>
        </div>

        <!-- Cities Grid - Visual Design (NO TABLE) -->
        <% if (!ciudades.isEmpty()) { %>
        <div class="cities-grid" id="citiesGrid">
            <% for (Ciudad c : ciudades) { %>
            <div class="city-card glass" 
                 data-nombre="<%= c.getNombre() != null ? c.getNombre().toLowerCase() : "" %>"
                 data-departamento="<%= c.getDepartamento() != null ? c.getDepartamento().toLowerCase() : "" %>"
                 data-dane="<%= c.getCodigoDane() != null ? c.getCodigoDane() : "" %>">
                
                <!-- Card Header -->
                <div class="city-card-header">
                    <div class="city-icon-wrapper">
                        <i class="fas fa-city"></i>
                    </div>
                    <div class="city-name"><%= c.getNombre() %></div>
                </div>
                
                <!-- Card Body -->
                <div class="city-card-body">
                    <div class="city-info-row">
                        <i class="fas fa-map-pin"></i>
                        <span class="city-info-label">Departamento:</span>
                        <span class="city-info-value"><%= c.getDepartamento() != null ? c.getDepartamento() : "—" %></span>
                    </div>
                    <div class="city-info-row">
                        <i class="fas fa-hashtag"></i>
                        <span class="city-info-label">Código DANE:</span>
                        <span class="city-info-value">
                            <% if (c.getCodigoDane() != null && !c.getCodigoDane().isEmpty()) { %>
                                <span class="badge-dane"><%= c.getCodigoDane() %></span>
                            <% } else { %>
                                <span style="color:var(--txt-light);">—</span>
                            <% } %>
                        </span>
                    </div>
                </div>
                
                <!-- Card Footer with Actions -->
                <div class="city-card-footer">
                    <a href="<%= request.getContextPath() %>/admin/ciudades?action=editar&id=<%= c.getId() %>" 
                       class="btn-action btn-edit" title="Editar ciudad">
                        <i class="fas fa-edit"></i> Editar
                    </a>
                    <a href="<%= request.getContextPath() %>/admin/ciudades?action=eliminar&id=<%= c.getId() %>" 
                       class="btn-action btn-delete" title="Eliminar ciudad"
                       onclick="return confirm('¿Está seguro de eliminar <%= c.getNombre() %>? Esta acción no se puede deshacer.')">
                        <i class="fas fa-trash"></i> Eliminar
                    </a>
                </div>
            </div>
            <% } %>
        </div>
        <% } else { %>
        <!-- Empty State -->
        <div class="empty-state">
            <i class="fas fa-city"></i>
            <h4>No hay ciudades registradas</h4>
            <p style="margin-top:8px;">Comienza agregando una nueva ciudad al sistema</p>
            <a href="<%= request.getContextPath() %>/admin/ciudades?action=nuevo" class="btn-primary-custom" style="margin-top:16px;">
                <i class="fas fa-plus"></i> Agregar Ciudad
            </a>
        </div>
        <% } %>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ═══════════════════════════════════════════════════════════
        // SEARCH & FILTER - Updated for Cards
        // ═══════════════════════════════════════════════════════════
        const searchInput = document.getElementById('searchInput');
        const filterDepartamento = document.getElementById('filterDepartamento');
        const cityCards = document.querySelectorAll('.city-card');
        
        function filterCities() {
            const searchTerm = searchInput.value.toLowerCase();
            const deptoFilter = filterDepartamento.value;
            
            cityCards.forEach(card => {
                const nombre = card.dataset.nombre || '';
                const departamento = card.dataset.departamento || '';
                const dane = card.dataset.dane || '';
                
                const matchesSearch = nombre.includes(searchTerm) || 
                                      departamento.includes(searchTerm) || 
                                      dane.includes(searchTerm);
                const matchesDepto = deptoFilter === 'todos' || departamento === deptoFilter.toLowerCase();
                
                card.style.display = (matchesSearch && matchesDepto) ? '' : 'none';
            });
        }
        
        searchInput.addEventListener('keyup', filterCities);
        filterDepartamento.addEventListener('change', filterCities);

        // ═══════════════════════════════════════════════════════════
        // EXPORT TO CSV
        // ═══════════════════════════════════════════════════════════
        function exportToCSV() {
            const visibleCards = Array.from(cityCards).filter(c => c.style.display !== 'none');
            if (visibleCards.length === 0) {
                showToast('No hay datos para exportar', 'warning');
                return;
            }
            
            let csv = 'Nombre,Departamento,CodigoDANE\n';
            visibleCards.forEach(card => {
                const nombre = card.querySelector('.city-name').textContent.trim();
                const departamento = card.querySelector('.city-info-value').textContent.trim();
                const dane = card.querySelector('.badge-dane')?.textContent || '—';
                
                csv += `"${nombre}","${departamento}","${dane}"\n`;
            });
            
            const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'ciudades_' + new Date().toISOString().split('T')[0] + '.csv';
            link.click();
            showToast('Exportación completada exitosamente', 'success');
        }

        // ═══════════════════════════════════════════════════════════
        // TOAST NOTIFICATIONS
        // ═══════════════════════════════════════════════════════════
        function showToast(message, type = 'success') {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            
            const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle' };
            toast.innerHTML = `<i class="fas ${icons[type]}"></i><span>${message}</span>`;
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(100px)';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        // ═══════════════════════════════════════════════════════════
        // KEYBOARD SHORTCUTS
        // ═══════════════════════════════════════════════════════════
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
                e.preventDefault();
                window.location.href = '<%= request.getContextPath() %>/admin/ciudades?action=nuevo';
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                searchInput.focus();
            }
        });

        // Theme toggle
        (function() {
            const saved = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', saved);
        })();
    </script>
</body>
</html>