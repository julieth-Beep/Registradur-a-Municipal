<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.MesaVotacionDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.MesaVotacionDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.MesaVotacion" %>
<%@ page import="java.util.*" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    List<MesaVotacion> mesas = new ArrayList<MesaVotacion>();
    
    try {
        MesaVotacionDAO mesaDAO = new MesaVotacionDAOImpl();
        mesas = mesaDAO.listarTodos();
    } catch (Exception e) {
        out.println("<!-- ERROR: " + e.getMessage() + " -->");
    }
    
    // Estadísticas avanzadas
    int totalMesas = mesas.size();
    int capacidadTotal = 0;
    Set<String> zonasSet = new HashSet<String>();
    Set<String> ciudadesSet = new HashSet<String>();
    
    for (MesaVotacion m : mesas) {
        if (m.getCapacidad() != null) {
            capacidadTotal += m.getCapacidad();
        } else {
            capacidadTotal += 200; // default
        }
        if (m.getNombreZona() != null && !m.getNombreZona().isEmpty()) {
            zonasSet.add(m.getNombreZona());
        }
        if (m.getNombreCiudad() != null && !m.getNombreCiudad().isEmpty()) {
            ciudadesSet.add(m.getNombreCiudad());
        }
    }
    
    int promedioVotantesPorMesa = totalMesas > 0 ? capacidadTotal / totalMesas : 0;
    
    // Mensajes
    String error = (String) session.getAttribute("error");
    String success = (String) session.getAttribute("success");
    if (error != null) session.removeAttribute("error");
    if (success != null) session.removeAttribute("success");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mesas de Votación | Registraduría Municipal de Nobsa</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ═══════════════════════════════════════════════════════════ */
        /* DESIGN TOKENS - Registraduría Premium */
        /* ═══════════════════════════════════════════════════════════ */
        :root {
            --primary-900: #001a3a;
            --primary-800: #003366;
            --primary-700: #004080;
            --primary-600: #0055A4;
            --primary-500: #1a6bc4;
            --primary-100: #dbeafe;
            --primary-50: #eff6ff;
            
            --accent-red: #CE1126;
            --accent-yellow: #FCD116;
            
            --bg: #f8fafc;
            --surface: rgba(255, 255, 255, 0.85);
            --surface-2: rgba(248, 250, 252, 0.85);
            --border: rgba(0, 51, 102, 0.12);
            --txt: #0f172a;
            --txt-muted: #64748b;
            --txt-light: #94a3b8;
            
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            --info: #0ea5e9;
            
            --glass-bg: rgba(255, 255, 255, 0.75);
            --glass-border: rgba(255, 255, 255, 0.25);
            --glass-shadow: 0 8px 32px rgba(0, 51, 102, 0.08);
            --glass-blur: blur(16px);
            
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.04);
            --shadow-md: 0 4px 12px rgba(0, 51, 102, 0.08);
            --shadow-lg: 0 12px 32px rgba(0, 51, 102, 0.12);
            --shadow-glow: 0 0 40px rgba(0, 85, 164, 0.15);
            
            --radius-sm: 12px;
            --radius-md: 16px;
            --radius-lg: 20px;
            --radius-xl: 24px;
            --radius-2xl: 32px;
            
            --font-sans: 'Plus Jakarta Sans', sans-serif;
            --font-display: 'Space Grotesk', sans-serif;
            
            --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
            --duration-fast: 200ms;
            --duration-normal: 350ms;
        }

        [data-theme="dark"] {
            --bg: #0f172a;
            --surface: rgba(30, 41, 59, 0.85);
            --surface-2: rgba(23, 33, 54, 0.85);
            --border: rgba(255, 255, 255, 0.12);
            --txt: #f1f5f9;
            --txt-muted: #94a3b8;
            --txt-light: #64748b;
            --glass-bg: rgba(30, 41, 59, 0.75);
            --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        
        body {
            font-family: var(--font-sans);
            background: var(--bg);
            color: var(--txt);
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        /* Ambient Background */
        .ambient-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }
        .ambient-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.08;
            animation: float 20s ease-in-out infinite;
        }
        .ambient-blob-1 {
            width: 600px; height: 600px;
            background: var(--primary-600);
            top: -100px; right: -100px;
        }
        .ambient-blob-2 {
            width: 400px; height: 400px;
            background: var(--accent-yellow);
            bottom: -50px; left: -50px;
            animation-delay: -10s;
        }
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(20px, -20px) scale(1.05); }
        }

        .grid-pattern {
            position: fixed;
            inset: 0;
            background-image: 
                linear-gradient(rgba(0, 51, 102, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 51, 102, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: 0;
            pointer-events: none;
        }

        /* Glass Card Base */
        .glass {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            -webkit-backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
        }
        .glass:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
        }

        /* Layout */
        .main-content {
            margin-left: 280px;
            padding: 40px 32px 48px;
            min-height: 100vh;
            position: relative;
            z-index: 10;
        }
        @media (max-width: 1024px) {
            .main-content { margin-left: 0; padding: 24px 20px 40px; }
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            gap: 16px;
            flex-wrap: wrap;
            animation: fadeInDown 0.6s var(--ease-out) both;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-title {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 700;
            color: var(--txt);
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0;
        }
        .page-title i { color: var(--primary-600); font-size: 24px; }

        .page-subtitle {
            font-size: 14px;
            color: var(--txt-muted);
            margin-top: 4px;
            font-weight: 500;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary-600), var(--primary-800));
            border: none;
            padding: 12px 24px;
            border-radius: var(--radius-md);
            color: white;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all var(--duration-normal) var(--ease-out);
            box-shadow: var(--shadow-md), var(--shadow-glow);
        }
        .btn-primary-custom:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg), var(--shadow-glow);
            color: white;
        }

        /* Stats Cards */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }
        @media (max-width: 1200px) { .stats-row { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 768px) { .stats-row { grid-template-columns: 1fr; } }

        .stat-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-xl);
            padding: 24px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
            animation: fadeInUp 0.5s var(--ease-out) both;
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-600), var(--accent-yellow));
            transform: scaleX(0);
            transform-origin: left;
            transition: transform var(--duration-normal) var(--ease-out);
        }
        .stat-card:hover::before { transform: scaleX(1); }
        .stat-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg), var(--glass-shadow); }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .stat-icon {
            width: 56px;
            height: 56px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }
        .stat-icon.primary { background: rgba(0, 85, 164, 0.12); color: var(--primary-600); }
        .stat-icon.success { background: rgba(16, 185, 129, 0.12); color: var(--success); }
        .stat-icon.warning { background: rgba(245, 158, 11, 0.12); color: var(--warning); }
        .stat-icon.info { background: rgba(14, 165, 233, 0.12); color: var(--info); }

        .stat-content { flex: 1; }
        .stat-value {
            font-family: var(--font-display);
            font-size: 32px;
            font-weight: 800;
            color: var(--txt);
            line-height: 1;
            margin-bottom: 4px;
        }
        .stat-label {
            font-size: 13px;
            color: var(--txt-muted);
            font-weight: 500;
        }

        /* Visual Summary Cards */
        .visual-summary {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 32px;
        }
        @media (max-width: 992px) { .visual-summary { grid-template-columns: 1fr; } }

        .summary-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-xl);
            padding: 24px;
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
        }
        .summary-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
        }

        .summary-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
        }
        .summary-title {
            font-size: 14px;
            font-weight: 600;
            color: var(--txt-muted);
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }
        .summary-icon {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        .summary-value {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 800;
            color: var(--txt);
            margin-bottom: 8px;
        }

        .progress-bar-container {
            height: 8px;
            background: var(--surface-2);
            border-radius: 4px;
            overflow: hidden;
            margin-top: 12px;
        }
        .progress-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 0.6s var(--ease-out);
        }
        .progress-fill.primary { background: linear-gradient(90deg, var(--primary-600), var(--primary-800)); }
        .progress-fill.success { background: linear-gradient(90deg, var(--success), #059669); }
        .progress-fill.warning { background: linear-gradient(90deg, var(--warning), #d97706); }

        /* Toolbar */
        .toolbar {
            display: flex;
            gap: 16px;
            margin-bottom: 20px;
            padding: 16px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--glass-shadow);
            flex-wrap: wrap;
        }

        .search-box {
            flex: 1;
            min-width: 250px;
            display: flex;
            align-items: center;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 8px 16px;
        }
        .search-box input {
            border: none;
            padding: 10px;
            width: 100%;
            background: transparent;
            color: var(--txt);
            font-size: 14px;
        }
        .search-box input:focus { outline: none; }
        .search-box i { color: var(--txt-muted); }

        .filter-select {
            padding: 10px 20px;
            border-radius: var(--radius-md);
            background: var(--surface-2);
            border: 1px solid var(--border);
            color: var(--txt);
            font-size: 14px;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .filter-select:focus {
            outline: none;
            border-color: var(--primary-600);
            box-shadow: 0 0 0 3px rgba(0, 85, 164, 0.1);
        }

        .export-btn {
            padding: 10px 20px;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--txt);
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
            text-decoration: none;
        }
        .export-btn:hover {
            background: var(--primary-600);
            color: white;
            border-color: var(--primary-600);
        }

        /* Table Container */
        .table-container {
            background: var(--glass-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-2xl);
            box-shadow: var(--glass-shadow);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: var(--surface-2);
            padding: 16px 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--txt-muted);
            text-align: left;
            border-bottom: 2px solid var(--border);
        }

        td {
            padding: 14px 20px;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
            color: var(--txt);
            font-size: 14px;
        }

        tr { transition: all var(--duration-fast) var(--ease-out); }
        tr:hover {
            background: rgba(0, 85, 164, 0.05);
            transform: translateX(4px);
        }
        tr:last-child td { border-bottom: none; }

        .btn-action {
            padding: 6px 12px;
            border-radius: var(--radius-sm);
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all var(--duration-fast) var(--ease-out);
            margin-right: 4px;
            border: none;
            cursor: pointer;
        }
        .btn-edit { background: rgba(245, 158, 11, 0.12); color: var(--warning); }
        .btn-edit:hover { background: var(--warning); color: white; }
        .btn-delete { background: rgba(239, 68, 68, 0.12); color: var(--error); }
        .btn-delete:hover { background: var(--error); color: white; }

        /* Badges */
        .badge-zona {
            background: rgba(20, 184, 166, 0.12);
            color: #14b8a6;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .badge-capacidad {
            background: rgba(0, 85, 164, 0.12);
            color: var(--primary-600);
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--txt-muted);
        }
        .empty-state i {
            font-size: 48px;
            opacity: 0.3;
            margin-bottom: 16px;
            display: block;
        }

        /* Alerts */
        .alert {
            padding: 16px 20px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s var(--ease-out) both;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .alert-success {
            background: rgba(16, 185, 129, 0.12);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: var(--success);
        }
        .alert-danger {
            background: rgba(239, 68, 68, 0.12);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: var(--error);
        }

        /* Toast Notifications */
        .toast-container {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .toast {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 16px 20px;
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 320px;
            animation: slideInRight 0.3s var(--ease-out) both;
        }
        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(100px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .toast.success { border-left: 4px solid var(--success); }
        .toast.error { border-left: 4px solid var(--error); }
        .toast.warning { border-left: 4px solid var(--warning); }
        .toast i { font-size: 18px; }
        .toast.success i { color: var(--success); }
        .toast.error i { color: var(--error); }
        .toast.warning i { color: var(--warning); }

        /* Responsive */
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: 1fr; }
            .visual-summary { grid-template-columns: 1fr; }
            .toolbar { flex-direction: column; }
            .search-box { min-width: 100%; }
        }
    </style>
</head>
<body>

    <!-- Ambient Background -->
    <div class="ambient-bg">
        <div class="ambient-blob ambient-blob-1"></div>
        <div class="ambient-blob ambient-blob-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>

    <%@ include file="/includes/navbar.jsp" %>

    <main class="main-content">
        
        <!-- Alerts -->
        <% if (success != null) { %>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            <span><%= success %></span>
            <button onclick="this.parentElement.remove()" style="margin-left:auto;background:none;border:none;color:inherit;cursor:pointer;font-size:18px;">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <% } %>
        <% if (error != null) { %>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <span><%= error %></span>
            <button onclick="this.parentElement.remove()" style="margin-left:auto;background:none;border:none;color:inherit;cursor:pointer;font-size:18px;">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <% } %>
        
        <!-- Page Header -->
        <div class="page-header">
            <div>
                <h1 class="page-title">
                    <i class="fas fa-table"></i> 
                    Mesas de Votación
                </h1>
                <p class="page-subtitle"><%= totalMesas %> mesas registradas · Capacidad total: <%= capacidadTotal %> votantes</p>
            </div>
            <a href="<%= request.getContextPath() %>/admin/mesas?action=nuevo" class="btn-primary-custom">
                <i class="fas fa-plus"></i> Nueva Mesa
            </a>
        </div>

        <!-- Stats Cards -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-icon primary"><i class="fas fa-table"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= totalMesas %></div>
                    <div class="stat-label">Total de Mesas</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon success"><i class="fas fa-users"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= capacidadTotal %></div>
                    <div class="stat-label">Capacidad Total</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon warning"><i class="fas fa-map-marked-alt"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= zonasSet.size() %></div>
                    <div class="stat-label">Zonas Cubiertas</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon info"><i class="fas fa-city"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= ciudadesSet.size() %></div>
                    <div class="stat-label">Ciudades</div>
                </div>
            </div>
        </div>

        <!-- Visual Summary -->
        <div class="visual-summary">
            <div class="summary-card">
                <div class="summary-header">
                    <span class="summary-title">Promedio por Mesa</span>
                    <div class="summary-icon" style="background:rgba(0,85,164,0.12);color:var(--primary-600);">
                        <i class="fas fa-chart-line"></i>
                    </div>
                </div>
                <div class="summary-value"><%= promedioVotantesPorMesa %></div>
                <div style="font-size:13px;color:var(--txt-muted);">votantes promedio</div>
                <div class="progress-bar-container">
                    <div class="progress-fill primary" style="width:<%= Math.min(100, (promedioVotantesPorMesa * 100) / 300) %>%"></div>
                </div>
            </div>
            
            <div class="summary-card">
                <div class="summary-header">
                    <span class="summary-title">Distribución por Zona</span>
                    <div class="summary-icon" style="background:rgba(20,184,166,0.12);color:#14b8a6;">
                        <i class="fas fa-layer-group"></i>
                    </div>
                </div>
                <div class="summary-value"><%= zonasSet.size() %></div>
                <div style="font-size:13px;color:var(--txt-muted);">zonas activas</div>
                <div class="progress-bar-container">
                    <div class="progress-fill success" style="width:<%= Math.min(100, (zonasSet.size() * 100) / 20) %>%"></div>
                </div>
            </div>
            
            <div class="summary-card">
                <div class="summary-header">
                    <span class="summary-title">Cobertura Urbana</span>
                    <div class="summary-icon" style="background:rgba(245,158,11,0.12);color:var(--warning);">
                        <i class="fas fa-building"></i>
                    </div>
                </div>
                <div class="summary-value"><%= ciudadesSet.size() %></div>
                <div style="font-size:13px;color:var(--txt-muted);">ciudades cubiertas</div>
                <div class="progress-bar-container">
                    <div class="progress-fill warning" style="width:<%= Math.min(100, (ciudadesSet.size() * 100) / 15) %>%"></div>
                </div>
            </div>
        </div>

        <!-- Toolbar -->
        <div class="toolbar">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="searchInput" placeholder="Buscar por número de mesa, zona o ciudad..." autocomplete="off">
            </div>
            <select id="filterZona" class="filter-select">
                <option value="todos">Todas las zonas</option>
                <% for (String zona : zonasSet) { %>
                <option value="<%= zona %>"><%= zona %></option>
                <% } %>
            </select>
            <select id="filterCiudad" class="filter-select">
                <option value="todos">Todas las ciudades</option>
                <% for (String ciudad : ciudadesSet) { %>
                <option value="<%= ciudad %>"><%= ciudad %></option>
                <% } %>
            </select>
            <button class="export-btn glass" onclick="exportToCSV()">
                <i class="fas fa-file-csv"></i> Exportar CSV
            </button>
        </div>

        <!-- Table -->
        <div class="table-container">
            <div class="table-responsive">
                <table id="mesasTable">
                    <thead>
                        <tr>
                            <th>N° Mesa</th>
                            <th>Zona</th>
                            <th>Ciudad</th>
                            <th>Capacidad</th>
                            <th style="width: 140px;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% if (!mesas.isEmpty()) {
                            for (MesaVotacion m : mesas) {
                                int cap = m.getCapacidad() != null ? m.getCapacidad() : 200;
                        %>
                        <tr class="mesa-row" 
                            data-mesa="<%= m.getNumeroMesa() %>"
                            data-zona="<%= m.getNombreZona() != null ? m.getNombreZona().toLowerCase() : "" %>"
                            data-ciudad="<%= m.getNombreCiudad() != null ? m.getNombreCiudad().toLowerCase() : "" %>"
                            data-capacidad="<%= cap %>">
                            <td>
                                <strong style="font-size: 16px; color: var(--primary-800);">
                                    Mesa #<%= m.getNumeroMesa() %>
                                </strong>
                            </td>
                            <td>
                                <% if (m.getNombreZona() != null && !m.getNombreZona().isEmpty()) { %>
                                    <span class="badge-zona">
                                        <i class="fas fa-map-marker-alt"></i> <%= m.getNombreZona() %>
                                    </span>
                                <% } else { %>
                                    <span style="color:var(--txt-light);">—</span>
                                <% } %>
                            </td>
                            <td><%= m.getNombreCiudad() != null ? m.getNombreCiudad() : "<span style='color:var(--txt-light);'>—</span>" %></td>
                            <td>
                                <span class="badge-capacidad">
                                    <i class="fas fa-users"></i> <%= cap %> votantes
                                </span>
                            </td>
                            <td>
                                <a href="<%= request.getContextPath() %>/admin/mesas?action=editar&id=<%= m.getId() %>" 
                                   class="btn-action btn-edit" title="Editar mesa">
                                    <i class="fas fa-edit"></i> Editar
                                </a>
                                <a href="<%= request.getContextPath() %>/admin/mesas?action=eliminar&id=<%= m.getId() %>" 
                                   class="btn-action btn-delete" title="Eliminar mesa"
                                   onclick="return confirm('¿Está seguro de eliminar la Mesa #<%= m.getNumeroMesa() %>? Esta acción no se puede deshacer.')">
                                    <i class="fas fa-trash"></i> Eliminar
                                </a>
                            </td>
                        </tr>
                        <% }
                        } else { %>
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">
                                    <i class="fas fa-table"></i>
                                    <p><strong>No hay mesas de votación registradas</strong></p>
                                    <p style="margin-top:8px;">Comienza agregando una nueva mesa al sistema</p>
                                    <a href="<%= request.getContextPath() %>/admin/mesas?action=nuevo" class="btn-primary-custom" style="margin-top:16px;">
                                        <i class="fas fa-plus"></i> Agregar Mesa
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ═══════════════════════════════════════════════════════════
        // SEARCH & FILTER
        // ═══════════════════════════════════════════════════════════
        const searchInput = document.getElementById('searchInput');
        const filterZona = document.getElementById('filterZona');
        const filterCiudad = document.getElementById('filterCiudad');
        const rows = document.querySelectorAll('.mesa-row');
        
        function filterTable() {
            const searchTerm = searchInput.value.toLowerCase();
            const zonaFilter = filterZona.value;
            const ciudadFilter = filterCiudad.value;
            
            rows.forEach(row => {
                const mesa = row.dataset.mesa || '';
                const zona = row.dataset.zona || '';
                const ciudad = row.dataset.ciudad || '';
                
                const matchesSearch = mesa.includes(searchTerm) || 
                                      zona.includes(searchTerm) || 
                                      ciudad.includes(searchTerm);
                const matchesZona = zonaFilter === 'todos' || zona === zonaFilter.toLowerCase();
                const matchesCiudad = ciudadFilter === 'todos' || ciudad === ciudadFilter.toLowerCase();
                
                row.style.display = (matchesSearch && matchesZona && matchesCiudad) ? '' : 'none';
            });
        }
        
        searchInput.addEventListener('keyup', filterTable);
        filterZona.addEventListener('change', filterTable);
        filterCiudad.addEventListener('change', filterTable);

        // ═══════════════════════════════════════════════════════════
        // EXPORT TO CSV
        // ═══════════════════════════════════════════════════════════
        function exportToCSV() {
            const visibleRows = Array.from(rows).filter(r => r.style.display !== 'none');
            if (visibleRows.length === 0) {
                showToast('No hay datos para exportar', 'warning');
                return;
            }
            
            let csv = 'NumeroMesa,Zona,Ciudad,Capacidad\n';
            visibleRows.forEach(row => {
                const cells = row.querySelectorAll('td');
                if (cells.length >= 4) {
                    const data = [
                        cells[0].textContent.trim(),
                        cells[1].textContent.trim(),
                        cells[2].textContent.trim(),
                        cells[3].textContent.trim()
                    ];
                    csv += data.map(d => `"${d.replace(/"/g, '""')}"`).join(',') + '\n';
                }
            });
            
            const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'mesas_votacion_' + new Date().toISOString().split('T')[0] + '.csv';
            link.click();
            showToast('Exportación completada exitosamente', 'success');
        }

        // ═══════════════════════════════════════════════════════════
        // TOAST NOTIFICATIONS
        // ═══════════════════════════════════════════════════════════
        function showToast(message, type = 'success') {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            
            const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle' };
            toast.innerHTML = `<i class="fas ${icons[type]}"></i><span>${message}</span>`;
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(100px)';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        // ═══════════════════════════════════════════════════════════
        // KEYBOARD SHORTCUTS
        // ═══════════════════════════════════════════════════════════
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
                e.preventDefault();
                window.location.href = '<%= request.getContextPath() %>/admin/mesas?action=nuevo';
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                searchInput.focus();
            }
        });

        // Theme toggle
        (function() {
            const saved = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', saved);
        })();
    </script>
    <script src="<%= request.getContextPath() %>/js/registraduria.js"></script>
</body>
</html>