<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.MesaVotacionDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.MesaVotacionDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.ZonaVotacionDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.ZonaVotacionDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.MesaVotacion" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.ZonaVotacion" %>
<%@ page import="java.util.*" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    // Verificar si es edición o nuevo
    String idParam = request.getParameter("id");
    MesaVotacion mesa = null;
    boolean esEdicion = false;
    
    if (idParam != null && !idParam.isEmpty()) {
        try {
            MesaVotacionDAO mesaDAO = new MesaVotacionDAOImpl();
            mesa = mesaDAO.buscarPorId(Integer.parseInt(idParam));
            esEdicion = (mesa != null);
        } catch (Exception e) {
            out.println("<!-- ERROR: " + e.getMessage() + " -->");
        }
    }
    
    // Cargar zonas para el select
    List<ZonaVotacion> zonas = new ArrayList<ZonaVotacion>();
    try {
        ZonaVotacionDAO zonaDAO = new ZonaVotacionDAOImpl();
        zonas = zonaDAO.listarTodos();
    } catch (Exception e) {
        out.println("<!-- ERROR: " + e.getMessage() + " -->");
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><%= esEdicion ? "Editar" : "Nueva" %> Mesa - Registraduría</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0eef8; font-family: 'Inter', sans-serif; }
        .main-content { margin-left: 260px; padding: 30px; }
        @media (max-width: 992px) { .main-content { margin-left: 0; } }
        .form-card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.04);
            max-width: 600px;
            margin: 0 auto;
        }
        .form-label {
            font-weight: 600;
            color: #18122b;
            margin-bottom: 6px;
        }
        .form-control, .form-select {
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 12px;
            background: white;
        }
        .form-control:focus, .form-select:focus {
            border-color: #003366;
            box-shadow: 0 0 0 3px rgba(0,51,102,0.1);
        }
        .btn-primary {
            background: #003366;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
        }
        .btn-primary:hover {
            background: #1a5276;
        }
        .btn-secondary {
            background: #e2e8f0;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            color: #5a6a7a;
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
    </style>
</head>
<body>

<%@ include file="/includes/navbar.jsp" %>

<main class="main-content">
    <div style="margin-bottom: 24px;">
        <a href="<%= request.getContextPath() %>/admin/mesas" class="text-decoration-none" style="color: #5a6a7a;">
            <i class="fas fa-arrow-left"></i> Volver a la lista
        </a>
    </div>
    
    <div class="form-card">
        <h3 style="margin-bottom: 24px; font-weight: 700; color: #18122b;">
            <i class="fas fa-<%= esEdicion ? "edit" : "table" %>" style="color: #003366;"></i> 
            <%= esEdicion ? "Editar Mesa de Votación" : "Nueva Mesa de Votación" %>
        </h3>
        
        <form action="<%= request.getContextPath() %>/admin/mesas" method="POST">
            <% if (esEdicion) { %>
                <input type="hidden" name="id" value="<%= mesa.getId() %>">
            <% } %>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-map-marker-alt"></i> Zona de Votación *
                </label>
                <select name="idZona" class="form-select" required>
                    <option value="">-- Seleccione una zona --</option>
                    <% for (ZonaVotacion z : zonas) { 
                        boolean seleccionada = (mesa != null && mesa.getIdZona() == z.getId());
                    %>
                        <option value="<%= z.getId() %>" <%= seleccionada ? "selected" : "" %>>
                            <%= z.getNombreZona() %> - <%= z.getNombreCiudad() %>
                        </option>
                    <% } %>
                </select>
            </div>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-hashtag"></i> Número de Mesa *
                </label>
                <input type="number" name="numeroMesa" class="form-control" 
                       placeholder="Ej: 1, 2, 3..." 
                       value="<%= mesa != null ? mesa.getNumeroMesa() : "" %>"
                       min="1" required>
            </div>
            
            <div class="mb-4">
                <label class="form-label">
                    <i class="fas fa-users"></i> Capacidad
                </label>
                <input type="number" name="capacidad" class="form-control" 
                       placeholder="Ej: 200" 
                       value="<%= mesa != null && mesa.getCapacidad() != null ? mesa.getCapacidad() : "200" %>"
                       min="1">
                <small class="text-muted">Por defecto: 200 votantes</small>
            </div>
            
            <hr style="margin: 24px 0;">
            
            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <a href="<%= request.getContextPath() %>/admin/mesas" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <%= esEdicion ? "Actualizar" : "Guardar" %> Mesa
                </button>
            </div>
        </form>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>