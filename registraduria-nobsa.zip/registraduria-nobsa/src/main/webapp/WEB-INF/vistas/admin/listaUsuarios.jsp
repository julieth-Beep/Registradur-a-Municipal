<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.UsuarioDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.UsuarioDAOImpl" %>
<%@ page import="java.util.*" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    List<Usuario> usuarios = new ArrayList<Usuario>();
    
    try {
        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
        usuarios = usuarioDAO.listarTodos();
    } catch (Exception e) {
        out.println("<!-- ERROR: " + e.getMessage() + " -->");
    }
    
    // Estadísticas
    int totalUsuarios = usuarios.size();
    int totalAdmin = 0, totalVotante = 0, totalActivos = 0, totalInactivos = 0;
    for (Usuario u : usuarios) {
        if ("ADMIN".equalsIgnoreCase(u.getTipoUsuario())) totalAdmin++;
        else totalVotante++;
        if ("activo".equalsIgnoreCase(u.getEstado())) totalActivos++;
        else totalInactivos++;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios | Registraduría Municipal de Nobsa</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ═══════════════════════════════════════════════════════════ */
        /* DESIGN TOKENS - Registraduría Premium */
        /* ═══════════════════════════════════════════════════════════ */
        :root {
            --primary-900: #001a3a;
            --primary-800: #003366;
            --primary-700: #004080;
            --primary-600: #0055A4;
            --primary-500: #1a6bc4;
            --primary-100: #dbeafe;
            --primary-50: #eff6ff;
            
            --accent-red: #CE1126;
            --accent-yellow: #FCD116;
            
            --bg: #f8fafc;
            --surface: rgba(255, 255, 255, 0.85);
            --surface-2: rgba(248, 250, 252, 0.85);
            --border: rgba(0, 51, 102, 0.12);
            --txt: #0f172a;
            --txt-muted: #64748b;
            --txt-light: #94a3b8;
            
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            --info: #0ea5e9;
            
            --glass-bg: rgba(255, 255, 255, 0.75);
            --glass-border: rgba(255, 255, 255, 0.25);
            --glass-shadow: 0 8px 32px rgba(0, 51, 102, 0.08);
            --glass-blur: blur(16px);
            
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.04);
            --shadow-md: 0 4px 12px rgba(0, 51, 102, 0.08);
            --shadow-lg: 0 12px 32px rgba(0, 51, 102, 0.12);
            --shadow-glow: 0 0 40px rgba(0, 85, 164, 0.15);
            
            --radius-sm: 12px;
            --radius-md: 16px;
            --radius-lg: 20px;
            --radius-xl: 24px;
            --radius-2xl: 32px;
            
            --font-sans: 'Plus Jakarta Sans', sans-serif;
            --font-display: 'Space Grotesk', sans-serif;
            
            --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
            --duration-fast: 200ms;
            --duration-normal: 350ms;
        }

        [data-theme="dark"] {
            --bg: #0f172a;
            --surface: rgba(30, 41, 59, 0.85);
            --surface-2: rgba(23, 33, 54, 0.85);
            --border: rgba(255, 255, 255, 0.12);
            --txt: #f1f5f9;
            --txt-muted: #94a3b8;
            --txt-light: #64748b;
            --glass-bg: rgba(30, 41, 59, 0.75);
            --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        
        body {
            font-family: var(--font-sans);
            background: var(--bg);
            color: var(--txt);
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        /* Ambient Background - ORIGINAL */
        .ambient-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }
        .ambient-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.08;
            animation: float 20s ease-in-out infinite;
        }
        .ambient-blob-1 {
            width: 600px; height: 600px;
            background: var(--primary-600);
            top: -100px; right: -100px;
        }
        .ambient-blob-2 {
            width: 400px; height: 400px;
            background: var(--accent-yellow);
            bottom: -50px; left: -50px;
            animation-delay: -10s;
        }
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(20px, -20px) scale(1.05); }
        }

        .grid-pattern {
            position: fixed;
            inset: 0;
            background-image: 
                linear-gradient(rgba(0, 51, 102, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 51, 102, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: 0;
            pointer-events: none;
        }

        /* Glass Base */
        .glass {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            -webkit-backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
        }

        /* Layout */
        .main-content {
            margin-left: 280px;
            padding: 40px 32px 48px;
            min-height: 100vh;
            position: relative;
            z-index: 10;
        }
        @media (max-width: 1024px) {
            .main-content { margin-left: 0; padding: 24px 20px 40px; }
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            gap: 16px;
            flex-wrap: wrap;
            animation: fadeInDown 0.6s var(--ease-out) both;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-title {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 700;
            color: var(--txt);
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0;
        }
        .page-title i { color: var(--primary-600); font-size: 24px; }
        .page-subtitle {
            font-size: 14px;
            color: var(--txt-muted);
            margin-top: 4px;
            font-weight: 500;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary-600), var(--primary-800));
            border: none;
            padding: 12px 24px;
            border-radius: var(--radius-md);
            color: white;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all var(--duration-normal) var(--ease-out);
            box-shadow: var(--shadow-md), var(--shadow-glow);
        }
        .btn-primary-custom:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg), var(--shadow-glow);
            color: white;
        }

        /* Stats Cards */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }
        @media (max-width: 1200px) { .stats-row { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 768px) { .stats-row { grid-template-columns: 1fr; } }

        .stat-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-xl);
            padding: 24px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
            animation: fadeInUp 0.5s var(--ease-out) both;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .stat-icon {
            width: 56px;
            height: 56px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }
        .stat-icon.primary { background: rgba(0, 85, 164, 0.12); color: var(--primary-600); }
        .stat-icon.success { background: rgba(16, 185, 129, 0.12); color: var(--success); }
        .stat-icon.warning { background: rgba(245, 158, 11, 0.12); color: var(--warning); }
        .stat-icon.danger { background: rgba(239, 68, 68, 0.12); color: var(--error); }
        .stat-content { flex: 1; }
        .stat-value {
            font-family: var(--font-display);
            font-size: 32px;
            font-weight: 800;
            color: var(--txt);
            line-height: 1;
            margin-bottom: 4px;
        }
        .stat-label {
            font-size: 13px;
            color: var(--txt-muted);
            font-weight: 500;
        }

        /* Toolbar */
        .toolbar {
            display: flex;
            gap: 16px;
            margin-bottom: 20px;
            padding: 16px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--glass-shadow);
            flex-wrap: wrap;
        }
        .search-box {
            flex: 1;
            min-width: 250px;
            display: flex;
            align-items: center;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 8px 16px;
        }
        .search-box input {
            border: none;
            padding: 10px;
            width: 100%;
            background: transparent;
            color: var(--txt);
            font-size: 14px;
        }
        .search-box input:focus { outline: none; }
        .search-box i { color: var(--txt-muted); }
        .filter-select {
            padding: 10px 20px;
            border-radius: var(--radius-md);
            background: var(--surface-2);
            border: 1px solid var(--border);
            color: var(--txt);
            font-size: 14px;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .filter-select:focus {
            outline: none;
            border-color: var(--primary-600);
            box-shadow: 0 0 0 3px rgba(0, 85, 164, 0.1);
        }
        .export-btn {
            padding: 10px 20px;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--txt);
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
            text-decoration: none;
        }
        .export-btn:hover {
            background: var(--primary-600);
            color: white;
            border-color: var(--primary-600);
        }

        /* ═══════════════════════════════════════════════════════════ */
        /* MODERN LIST VIEW - Enhanced Rows (NOT Table, NOT Cards) */
        /* ═══════════════════════════════════════════════════════════ */
        
        .users-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .user-item {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-xl);
            padding: 20px 24px;
            display: grid;
            grid-template-columns: auto 1fr auto;
            align-items: center;
            gap: 20px;
            transition: all var(--duration-normal) var(--ease-out);
            animation: fadeInUp 0.4s var(--ease-out) both;
            position: relative;
            overflow: hidden;
        }
        .user-item::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: linear-gradient(180deg, var(--primary-600), var(--accent-yellow));
            transform: scaleY(0);
            transform-origin: top;
            transition: transform var(--duration-normal) var(--ease-out);
        }
        .user-item:hover::before { transform: scaleY(1); }
        .user-item:hover {
            transform: translateX(4px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
            border-color: var(--primary-300);
        }

        /* Left: Avatar + Quick Info */
        .user-left {
            display: flex;
            align-items: center;
            gap: 16px;
            min-width: 220px;
        }
        .user-avatar {
            width: 52px;
            height: 52px;
            background: linear-gradient(135deg, var(--primary-100), var(--primary-50));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: 700;
            color: var(--primary-600);
            flex-shrink: 0;
            box-shadow: 0 4px 12px rgba(0, 85, 164, 0.1);
        }
        .user-quick-info {
            min-width: 0;
        }
        .user-name {
            font-family: var(--font-display);
            font-size: 16px;
            font-weight: 700;
            color: var(--txt);
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .user-username {
            font-size: 13px;
            color: var(--txt-muted);
            display: flex;
            align-items: center;
            gap: 4px;
        }

        /* Center: Details */
        .user-center {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            padding: 0 20px;
            border-left: 1px dashed var(--border);
            border-right: 1px dashed var(--border);
        }
        @media (max-width: 1024px) {
            .user-center { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 768px) {
            .user-center { grid-template-columns: 1fr; border: none; padding: 12px 0 0; }
        }
        .user-detail {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .user-detail-label {
            font-size: 11px;
            color: var(--txt-muted);
            text-transform: uppercase;
            letter-spacing: 0.03em;
            font-weight: 600;
        }
        .user-detail-value {
            font-size: 14px;
            font-weight: 600;
            color: var(--txt);
        }

        /* Right: Badges + Actions */
        .user-right {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 12px;
            min-width: 180px;
        }
        .user-badges {
            display: flex;
            flex-direction: column;
            gap: 6px;
            align-items: flex-end;
        }
        .badge-admin {
            background: rgba(239, 68, 68, 0.12);
            color: var(--error);
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .badge-votante {
            background: rgba(0, 85, 164, 0.12);
            color: var(--primary-600);
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .badge-activo {
            background: rgba(16, 185, 129, 0.12);
            color: var(--success);
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .badge-inactivo {
            background: rgba(107, 114, 128, 0.12);
            color: var(--txt-muted);
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .user-actions {
            display: flex;
            gap: 6px;
            opacity: 0;
            transform: translateX(10px);
            transition: all var(--duration-fast) var(--ease-out);
        }
        .user-item:hover .user-actions {
            opacity: 1;
            transform: translateX(0);
        }
        .btn-action {
            padding: 6px 10px;
            border-radius: var(--radius-sm);
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all var(--duration-fast) var(--ease-out);
            border: none;
            cursor: pointer;
        }
        .btn-edit { background: rgba(245, 158, 11, 0.12); color: var(--warning); }
        .btn-edit:hover { background: var(--warning); color: white; }
        .btn-toggle { background: rgba(14, 165, 233, 0.12); color: var(--info); }
        .btn-toggle:hover { background: var(--info); color: white; }
        .btn-delete { background: rgba(239, 68, 68, 0.12); color: var(--error); }
        .btn-delete:hover { background: var(--error); color: white; }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: var(--txt-muted);
            animation: fadeInUp 0.6s var(--ease-out) both;
        }
        .empty-state i {
            font-size: 64px;
            opacity: 0.2;
            margin-bottom: 20px;
            display: block;
        }
        .empty-state h4 {
            font-family: var(--font-display);
            font-size: 20px;
            font-weight: 700;
            color: var(--txt);
            margin-bottom: 8px;
        }
        .empty-state p {
            font-size: 14px;
            max-width: 400px;
            margin: 0 auto;
        }

        /* Toast Notifications */
        .toast-container {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .toast {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 16px 20px;
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 320px;
            animation: slideInRight 0.3s var(--ease-out) both;
        }
        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(100px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .toast.success { border-left: 4px solid var(--success); }
        .toast.error { border-left: 4px solid var(--error); }
        .toast.warning { border-left: 4px solid var(--warning); }
        .toast i { font-size: 18px; }
        .toast.success i { color: var(--success); }
        .toast.error i { color: var(--error); }
        .toast.warning i { color: var(--warning); }

        /* Responsive */
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: 1fr; }
            .toolbar { flex-direction: column; }
            .search-box { min-width: 100%; }
            .user-item {
                grid-template-columns: 1fr;
                text-align: center;
                padding: 16px;
            }
            .user-left { justify-content: center; }
            .user-center { border: none; padding: 12px 0 0; }
            .user-right { align-items: center; }
            .user-actions { opacity: 1; transform: none; }
        }
    </style>
</head>
<body>

    <!-- Ambient Background - ORIGINAL -->
    <div class="ambient-bg">
        <div class="ambient-blob ambient-blob-1"></div>
        <div class="ambient-blob ambient-blob-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>

    <%@ include file="/includes/navbar.jsp" %>

    <main class="main-content">
        
        <!-- Page Header -->
        <div class="page-header">
            <div>
                <h1 class="page-title">
                    <i class="fas fa-user-shield"></i> 
                    Usuarios del Sistema
                </h1>
                <p class="page-subtitle"><%= totalUsuarios %> usuarios registrados · <%= totalActivos %> activos</p>
            </div>
            <a href="<%= request.getContextPath() %>/admin/usuarios?action=nuevo" class="btn-primary-custom">
                <i class="fas fa-plus"></i> Nuevo Usuario
            </a>
        </div>

        <!-- Stats Cards -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-icon primary"><i class="fas fa-users"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= totalUsuarios %></div>
                    <div class="stat-label">Total Usuarios</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon danger"><i class="fas fa-shield-alt"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= totalAdmin %></div>
                    <div class="stat-label">Administradores</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon success"><i class="fas fa-user-check"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= totalActivos %></div>
                    <div class="stat-label">Usuarios Activos</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon warning"><i class="fas fa-user-times"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= totalInactivos %></div>
                    <div class="stat-label">Usuarios Inactivos</div>
                </div>
            </div>
        </div>

        <!-- Toolbar -->
        <div class="toolbar">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="searchInput" placeholder="Buscar por username, nombre o documento..." autocomplete="off">
            </div>
            <select id="filterTipo" class="filter-select">
                <option value="todos">Todos los roles</option>
                <option value="ADMIN">Administradores</option>
                <option value="VOTANTE">Votantes</option>
            </select>
            <select id="filterEstado" class="filter-select">
                <option value="todos">Todos los estados</option>
                <option value="activo">Activos</option>
                <option value="inactivo">Inactivos</option>
            </select>
            <button class="export-btn glass" onclick="exportToCSV()">
                <i class="fas fa-file-csv"></i> Exportar CSV
            </button>
        </div>

        <!-- Modern List View (NOT Table, NOT Cards) -->
        <% if (!usuarios.isEmpty()) { %>
        <div class="users-list" id="usersList">
            <% for (Usuario u : usuarios) {
                boolean isAdmin = "ADMIN".equalsIgnoreCase(u.getTipoUsuario());
                boolean isActive = "activo".equalsIgnoreCase(u.getEstado());
            %>
            <div class="user-item glass" 
                 data-username="<%= u.getUsername() != null ? u.getUsername().toLowerCase() : "" %>"
                 data-nombre="<%= (u.getNombres() + " " + u.getApellidos()).toLowerCase() %>"
                 data-documento="<%= u.getDocumento() != null ? u.getDocumento() : "" %>"
                 data-tipo="<%= u.getTipoUsuario() != null ? u.getTipoUsuario().toUpperCase() : "" %>"
                 data-estado="<%= u.getEstado() != null ? u.getEstado().toLowerCase() : "" %>">
                
                <!-- Left: Avatar + Identity -->
                <div class="user-left">
                    <div class="user-avatar">
                        <%= u.getNombres() != null && u.getNombres().length() > 0 ? u.getNombres().charAt(0) : 'U' %>
                    </div>
                    <div class="user-quick-info">
                        <div class="user-name"><%= u.getNombres() %> <%= u.getApellidos() %></div>
                        <div class="user-username">
                            <i class="fas fa-at"></i> <%= u.getUsername() %>
                        </div>
                    </div>
                </div>
                
                <!-- Center: Details Grid -->
                <div class="user-center">
                    <div class="user-detail">
                        <span class="user-detail-label">Documento</span>
                        <span class="user-detail-value"><%= u.getDocumento() %></span>
                    </div>
                    <div class="user-detail">
                        <span class="user-detail-label">Rol</span>
                        <span class="user-detail-value">
                            <% if (isAdmin) { %>
                                <span class="badge-admin"><i class="fas fa-shield-alt"></i> ADMIN</span>
                            <% } else { %>
                                <span class="badge-votante"><i class="fas fa-user"></i> VOTANTE</span>
                            <% } %>
                        </span>
                    </div>
                    <div class="user-detail">
                        <span class="user-detail-label">Estado</span>
                        <span class="user-detail-value">
                            <% if (isActive) { %>
                                <span class="badge-activo"><i class="fas fa-check"></i> Activo</span>
                            <% } else { %>
                                <span class="badge-inactivo"><i class="fas fa-ban"></i> Inactivo</span>
                            <% } %>
                        </span>
                    </div>
                </div>
                
                <!-- Right: Actions (appear on hover) -->
                <div class="user-right">
                    <div class="user-badges"></div>
                    <div class="user-actions">
                        <a href="<%= request.getContextPath() %>/admin/usuarios?action=editar&id=<%= u.getId() %>" 
                           class="btn-action btn-edit" title="Editar">
                            <i class="fas fa-edit"></i>
                        </a>
                        <a href="<%= request.getContextPath() %>/admin/usuarios?action=cambiarEstado&id=<%= u.getId() %>&estado=<%= isActive ? "inactivo" : "activo" %>" 
                           class="btn-action btn-toggle" title="<%= isActive ? "Desactivar" : "Activar" %>"
                           onclick="return confirm('¿Cambiar estado a <%= isActive ? "INACTIVO" : "ACTIVO" %>?')">
                            <i class="fas fa-sync-alt"></i>
                        </a>
                        <a href="<%= request.getContextPath() %>/admin/usuarios?action=eliminar&id=<%= u.getId() %>" 
                           class="btn-action btn-delete" title="Eliminar"
                           onclick="return confirm('¿Eliminar <%= u.getUsername() %>?')">
                            <i class="fas fa-trash"></i>
                        </a>
                    </div>
                </div>
            </div>
            <% } %>
        </div>
        <% } else { %>
        <!-- Empty State -->
        <div class="empty-state">
            <i class="fas fa-user-shield"></i>
            <h4>No hay usuarios registrados</h4>
            <p style="margin-top:8px;">Comienza agregando un nuevo usuario al sistema</p>
            <a href="<%= request.getContextPath() %>/admin/usuarios?action=nuevo" class="btn-primary-custom" style="margin-top:16px;">
                <i class="fas fa-plus"></i> Agregar Usuario
            </a>
        </div>
        <% } %>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ═══════════════════════════════════════════════════════════
        // SEARCH & FILTER - Updated for List Items
        // ═══════════════════════════════════════════════════════════
        const searchInput = document.getElementById('searchInput');
        const filterTipo = document.getElementById('filterTipo');
        const filterEstado = document.getElementById('filterEstado');
        const userItems = document.querySelectorAll('.user-item');
        
        function filterUsers() {
            const searchTerm = searchInput.value.toLowerCase();
            const tipoFilter = filterTipo.value;
            const estadoFilter = filterEstado.value;
            
            userItems.forEach(item => {
                const username = item.dataset.username || '';
                const nombre = item.dataset.nombre || '';
                const documento = item.dataset.documento || '';
                const tipo = item.dataset.tipo || '';
                const estado = item.dataset.estado || '';
                
                const matchesSearch = username.includes(searchTerm) || 
                                      nombre.includes(searchTerm) || 
                                      documento.includes(searchTerm);
                const matchesTipo = tipoFilter === 'todos' || tipo === tipoFilter.toUpperCase();
                const matchesEstado = estadoFilter === 'todos' || estado === estadoFilter.toLowerCase();
                
                item.style.display = (matchesSearch && matchesTipo && matchesEstado) ? '' : 'none';
            });
        }
        
        searchInput.addEventListener('keyup', filterUsers);
        filterTipo.addEventListener('change', filterUsers);
        filterEstado.addEventListener('change', filterUsers);

        // ═══════════════════════════════════════════════════════════
        // EXPORT TO CSV
        // ═══════════════════════════════════════════════════════════
        function exportToCSV() {
            const visibleItems = Array.from(userItems).filter(i => i.style.display !== 'none');
            if (visibleItems.length === 0) {
                showToast('No hay datos para exportar', 'warning');
                return;
            }
            
            let csv = 'Username,NombreCompleto,Documento,Rol,Estado\n';
            visibleItems.forEach(item => {
                const username = item.querySelector('.user-username').textContent.replace('@', '').trim();
                const nombre = item.querySelector('.user-name').textContent.trim();
                const documento = item.querySelectorAll('.user-detail-value')[0].textContent.trim();
                const rol = item.querySelector('.badge-admin, .badge-votante')?.textContent.trim() || '—';
                const estado = item.querySelector('.badge-activo, .badge-inactivo')?.textContent.trim() || '—';
                
                csv += `"${username}","${nombre}","${documento}","${rol}","${estado}"\n`;
            });
            
            const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'usuarios_sistema_' + new Date().toISOString().split('T')[0] + '.csv';
            link.click();
            showToast('Exportación completada exitosamente', 'success');
        }

        // ═══════════════════════════════════════════════════════════
        // TOAST NOTIFICATIONS
        // ═══════════════════════════════════════════════════════════
        function showToast(message, type = 'success') {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            
            const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle' };
            toast.innerHTML = `<i class="fas ${icons[type]}"></i><span>${message}</span>`;
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(100px)';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        // ═══════════════════════════════════════════════════════════
        // KEYBOARD SHORTCUTS
        // ═══════════════════════════════════════════════════════════
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
                e.preventDefault();
                window.location.href = '<%= request.getContextPath() %>/admin/usuarios?action=nuevo';
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                searchInput.focus();
            }
        });

        // Theme toggle
        (function() {
            const saved = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', saved);
        })();
    </script>
    <script src="<%= request.getContextPath() %>/js/registraduria.js"></script>
</body>
</html>