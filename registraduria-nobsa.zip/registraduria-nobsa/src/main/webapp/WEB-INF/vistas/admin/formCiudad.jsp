<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudad" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    // Verificar si es edición o nuevo
    String idParam = request.getParameter("id");
    Ciudad ciudad = null;
    boolean esEdicion = false;
    
    if (idParam != null && !idParam.isEmpty()) {
        try {
            CiudadDAO ciudadDAO = new CiudadDAOImpl();
            ciudad = ciudadDAO.buscarPorId(Integer.parseInt(idParam));
            esEdicion = (ciudad != null);
        } catch (Exception e) {
            out.println("<!-- ERROR: " + e.getMessage() + " -->");
        }
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><%= esEdicion ? "Editar" : "Nueva" %> Ciudad - Registraduría</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0eef8; font-family: 'Inter', sans-serif; }
        .main-content { margin-left: 260px; padding: 30px; }
        @media (max-width: 992px) { .main-content { margin-left: 0; } }
        .form-card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.04);
            max-width: 600px;
            margin: 0 auto;
        }
        .form-label {
            font-weight: 600;
            color: #18122b;
            margin-bottom: 6px;
        }
        .form-control {
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 12px;
            background: white;
        }
        .form-control:focus {
            border-color: #003366;
            box-shadow: 0 0 0 3px rgba(0,51,102,0.1);
        }
        .btn-primary {
            background: #003366;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
        }
        .btn-primary:hover {
            background: #1a5276;
        }
        .btn-secondary {
            background: #e2e8f0;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            color: #5a6a7a;
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
    </style>
</head>
<body>

<%@ include file="/includes/navbar.jsp" %>

<main class="main-content">
    <div style="margin-bottom: 24px;">
        <a href="<%= request.getContextPath() %>/admin/ciudades" class="text-decoration-none" style="color: #5a6a7a;">
            <i class="fas fa-arrow-left"></i> Volver a la lista
        </a>
    </div>
    
    <div class="form-card">
        <h3 style="margin-bottom: 24px; font-weight: 700; color: #18122b;">
            <i class="fas fa-<%= esEdicion ? "edit" : "city" %>" style="color: #003366;"></i> 
            <%= esEdicion ? "Editar Ciudad" : "Registrar Nueva Ciudad" %>
        </h3>
        
        <form action="<%= request.getContextPath() %>/admin/ciudades" method="POST">
            <% if (esEdicion) { %>
                <input type="hidden" name="id" value="<%= ciudad.getId() %>">
            <% } %>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-building"></i> Nombre de la Ciudad *
                </label>
                <input type="text" name="nombre" class="form-control" 
                       placeholder="Ej: Nobsa, Sogamoso, Duitama" 
                       value="<%= ciudad != null ? ciudad.getNombre() : "" %>"
                       required>
            </div>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-map"></i> Departamento
                </label>
                <input type="text" name="departamento" class="form-control" 
                       placeholder="Ej: Boyacá" 
                       value="<%= ciudad != null && ciudad.getDepartamento() != null ? ciudad.getDepartamento() : "Boyacá" %>">
                <small class="text-muted">Por defecto: Boyacá</small>
            </div>
            
            <div class="mb-4">
                <label class="form-label">
                    <i class="fas fa-barcode"></i> Código DANE
                </label>
                <input type="text" name="codigoDane" class="form-control" 
                       placeholder="Ej: 15491"
                       value="<%= ciudad != null && ciudad.getCodigoDane() != null ? ciudad.getCodigoDane() : "" %>">
                <small class="text-muted">Código único del municipio (opcional)</small>
            </div>
            
            <hr style="margin: 24px 0;">
            
            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <a href="<%= request.getContextPath() %>/admin/ciudades" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <%= esEdicion ? "Actualizar" : "Guardar" %> Ciudad
                </button>
            </div>
        </form>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>