<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.DocumentoDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.DocumentoDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudadano" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.DocumentoExpedido" %>
<%@ page import="java.util.*" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    List<DocumentoExpedido> documentos = new ArrayList<DocumentoExpedido>();
    Ciudadano ciudadano = null;
    String nombreCompleto = "";
    
    try {
        CiudadanoDAO ciudadanoDAO = new CiudadanoDAOImpl();
        ciudadano = ciudadanoDAO.buscarPorDocumento(usuario.getDocumento());
        
        if (ciudadano != null) {
            nombreCompleto = ciudadano.getNombreCompleto();
            DocumentoDAO documentoDAO = new DocumentoDAOImpl();
            documentos = documentoDAO.listarPorCiudadano(ciudadano.getId());
        }
    } catch (Exception e) {
        out.println("<!-- ERROR: " + e.getMessage() + " -->");
    }
    
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    
    // Estadísticas personales
    int totalDocs = documentos.size();
    int vigentes = 0, vencidos = 0, proximos = 0, cancelados = 0;
    
    java.time.LocalDate hoy = java.time.LocalDate.now();
    for (DocumentoExpedido d : documentos) {
        String estado = d.getEstado() != null ? d.getEstado().toLowerCase() : "vigente";
        if ("cancelado".equals(estado)) {
            cancelados++;
        } else if (d.getFechaVencimiento() != null) {
            try {
                java.time.LocalDate fv = d.getFechaVencimiento().toInstant()
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                if (fv.isBefore(hoy)) {
                    vencidos++;
                } else if (fv.isBefore(hoy.plusDays(30))) {
                    proximos++;
                } else {
                    vigentes++;
                }
            } catch (Exception e) {
                vigentes++;
            }
        } else {
            vigentes++;
        }
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Documentos | Registraduría Municipal de Nobsa</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ═══════════════════════════════════════════════════════════ */
        /* DESIGN TOKENS - Registraduría Premium */
        /* ═══════════════════════════════════════════════════════════ */
        :root {
            --primary-900: #001a3a;
            --primary-800: #003366;
            --primary-700: #004080;
            --primary-600: #0055A4;
            --primary-500: #1a6bc4;
            --primary-100: #dbeafe;
            --primary-50: #eff6ff;
            
            --accent-red: #CE1126;
            --accent-yellow: #FCD116;
            
            --bg: #f8fafc;
            --surface: rgba(255, 255, 255, 0.85);
            --surface-2: rgba(248, 250, 252, 0.85);
            --border: rgba(0, 51, 102, 0.12);
            --txt: #0f172a;
            --txt-muted: #64748b;
            --txt-light: #94a3b8;
            
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            --info: #0ea5e9;
            
            --glass-bg: rgba(255, 255, 255, 0.75);
            --glass-border: rgba(255, 255, 255, 0.25);
            --glass-shadow: 0 8px 32px rgba(0, 51, 102, 0.08);
            --glass-blur: blur(16px);
            
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.04);
            --shadow-md: 0 4px 12px rgba(0, 51, 102, 0.08);
            --shadow-lg: 0 12px 32px rgba(0, 51, 102, 0.12);
            --shadow-glow: 0 0 40px rgba(0, 85, 164, 0.15);
            
            --radius-sm: 12px;
            --radius-md: 16px;
            --radius-lg: 20px;
            --radius-xl: 24px;
            --radius-2xl: 32px;
            
            --font-sans: 'Plus Jakarta Sans', sans-serif;
            --font-display: 'Space Grotesk', sans-serif;
            
            --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
            --duration-fast: 200ms;
            --duration-normal: 350ms;
        }

        [data-theme="dark"] {
            --bg: #0f172a;
            --surface: rgba(30, 41, 59, 0.85);
            --surface-2: rgba(23, 33, 54, 0.85);
            --border: rgba(255, 255, 255, 0.12);
            --txt: #f1f5f9;
            --txt-muted: #94a3b8;
            --txt-light: #64748b;
            --glass-bg: rgba(30, 41, 59, 0.75);
            --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        
        body {
            font-family: var(--font-sans);
            background: var(--bg);
            color: var(--txt);
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        /* Ambient Background */
        .ambient-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }
        .ambient-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.08;
            animation: float 20s ease-in-out infinite;
        }
        .ambient-blob-1 {
            width: 600px; height: 600px;
            background: var(--primary-600);
            top: -100px; right: -100px;
        }
        .ambient-blob-2 {
            width: 400px; height: 400px;
            background: var(--accent-yellow);
            bottom: -50px; left: -50px;
            animation-delay: -10s;
        }
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(20px, -20px) scale(1.05); }
        }

        .grid-pattern {
            position: fixed;
            inset: 0;
            background-image: 
                linear-gradient(rgba(0, 51, 102, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 51, 102, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: 0;
            pointer-events: none;
        }

        /* Glass Card Base */
        .glass {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            -webkit-backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
        }
        .glass:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
        }

        /* Layout */
        .main-content {
            margin-left: 280px;
            padding: 40px 32px 48px;
            min-height: 100vh;
            position: relative;
            z-index: 10;
        }
        @media (max-width: 1024px) {
            .main-content { margin-left: 0; padding: 24px 20px 40px; }
        }

        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--txt-muted);
            text-decoration: none;
            font-weight: 500;
            padding: 8px 16px;
            border-radius: var(--radius-md);
            transition: all var(--duration-fast) var(--ease-out);
            margin-bottom: 24px;
        }
        .back-btn:hover {
            background: var(--primary-50);
            color: var(--primary-600);
        }

        /* Page Header */
        .page-header {
            margin-bottom: 32px;
            animation: fadeInDown 0.6s var(--ease-out) both;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-title {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 700;
            color: var(--txt);
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0 0 8px;
        }
        .page-title i { color: var(--primary-600); font-size: 24px; }

        .page-subtitle {
            font-size: 14px;
            color: var(--txt-muted);
            font-weight: 500;
        }

        /* Profile Card */
        .profile-card {
            background: linear-gradient(135deg, var(--primary-800), var(--primary-900));
            border-radius: var(--radius-2xl);
            padding: 32px;
            color: white;
            margin-bottom: 32px;
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.6s var(--ease-out) 0.1s both;
            box-shadow: var(--shadow-lg), 0 0 40px rgba(0, 85, 164, 0.2);
        }
        .profile-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(252,209,22,0.1) 0%, transparent 60%);
            pointer-events: none;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .profile-content {
            display: flex;
            align-items: center;
            gap: 24px;
            position: relative;
            z-index: 2;
        }
        .profile-avatar {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.15);
            border-radius: var(--radius-xl);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            flex-shrink: 0;
            border: 2px solid rgba(255,255,255,0.2);
        }
        .profile-info h3 {
            font-family: var(--font-display);
            font-size: 24px;
            font-weight: 700;
            margin: 0 0 4px;
            color: white;
        }
        .profile-info p {
            font-size: 14px;
            color: rgba(255,255,255,0.8);
            margin: 0;
        }
        .profile-stats {
            margin-left: auto;
            display: flex;
            gap: 16px;
        }
        .profile-stat {
            text-align: center;
            padding: 12px 20px;
            background: rgba(255,255,255,0.1);
            border-radius: var(--radius-lg);
            border: 1px solid rgba(255,255,255,0.15);
        }
        .profile-stat-value {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 800;
            color: white;
            line-height: 1;
        }
        .profile-stat-label {
            font-size: 12px;
            color: rgba(255,255,255,0.7);
            margin-top: 4px;
        }

        /* Stats Cards */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 32px;
        }
        @media (max-width: 1200px) { .stats-row { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 768px) { .stats-row { grid-template-columns: 1fr; } }

        .stat-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-xl);
            padding: 24px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
            animation: fadeInUp 0.5s var(--ease-out) both;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
        }

        .stat-icon {
            width: 52px;
            height: 52px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            flex-shrink: 0;
        }
        .stat-icon.success { background: rgba(16, 185, 129, 0.12); color: var(--success); }
        .stat-icon.warning { background: rgba(245, 158, 11, 0.12); color: var(--warning); }
        .stat-icon.error { background: rgba(239, 68, 68, 0.12); color: var(--error); }
        .stat-icon.muted { background: rgba(107, 114, 128, 0.12); color: var(--txt-muted); }

        .stat-content { flex: 1; }
        .stat-value {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 800;
            color: var(--txt);
            line-height: 1;
            margin-bottom: 4px;
        }
        .stat-label {
            font-size: 13px;
            color: var(--txt-muted);
            font-weight: 500;
        }

        /* Alert Banner */
        .alert-banner {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(245, 158, 11, 0.05));
            border: 1px solid rgba(245, 158, 11, 0.2);
            border-radius: var(--radius-lg);
            padding: 16px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 24px;
            animation: fadeInUp 0.5s var(--ease-out) 0.2s both;
        }
        .alert-banner i {
            font-size: 20px;
            color: var(--warning);
        }
        .alert-banner-content {
            flex: 1;
        }
        .alert-banner-title {
            font-weight: 600;
            color: var(--txt);
            font-size: 14px;
            margin-bottom: 2px;
        }
        .alert-banner-text {
            font-size: 13px;
            color: var(--txt-muted);
        }

        /* Document Cards Grid */
        .docs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }
        @media (max-width: 768px) { .docs-grid { grid-template-columns: 1fr; } }

        .doc-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-xl);
            padding: 24px;
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
            animation: fadeInUp 0.5s var(--ease-out) both;
            position: relative;
            overflow: hidden;
        }
        .doc-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-600), var(--accent-yellow));
            transform: scaleX(0);
            transform-origin: left;
            transition: transform var(--duration-normal) var(--ease-out);
        }
        .doc-card:hover::before { transform: scaleX(1); }
        .doc-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
        }

        .doc-card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            margin-bottom: 16px;
        }
        .doc-type {
            font-family: var(--font-display);
            font-size: 18px;
            font-weight: 700;
            color: var(--txt);
        }
        .doc-status {
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .status-vigente { background: rgba(16, 185, 129, 0.12); color: var(--success); }
        .status-vencido { background: rgba(239, 68, 68, 0.12); color: var(--error); }
        .status-proximo { background: rgba(245, 158, 11, 0.12); color: var(--warning); }
        .status-cancelado { background: rgba(107, 114, 128, 0.12); color: var(--txt-muted); }

        .doc-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 16px;
        }
        .doc-detail {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .doc-detail-label {
            font-size: 11px;
            color: var(--txt-muted);
            text-transform: uppercase;
            letter-spacing: 0.03em;
            font-weight: 600;
        }
        .doc-detail-value {
            font-size: 14px;
            font-weight: 600;
            color: var(--txt);
        }

        .doc-series {
            background: var(--surface-2);
            padding: 12px;
            border-radius: var(--radius-md);
            font-family: monospace;
            font-size: 13px;
            color: var(--txt-muted);
            word-break: break-all;
        }

        .doc-observations {
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px solid var(--border);
            font-size: 13px;
            color: var(--txt-muted);
        }

        /* ═══════════════════════════════════════════════════════════ */
        /* DOCUMENT ATTACHMENT - Visualización y Descarga */
        /* ═══════════════════════════════════════════════════════════ */
        .doc-attachment {
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px dashed var(--border);
        }
        .doc-attachment.has-file {
            border-top-style: solid;
            border-top-color: var(--primary-100);
        }
        
        .attachment-preview {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: var(--surface-2);
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
        }
        
        .attachment-preview.image {
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .attachment-preview.image:hover {
            border-color: var(--primary-600);
            transform: translateX(4px);
        }
        
        .attachment-preview img {
            width: 60px;
            height: 45px;
            object-fit: cover;
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
            flex-shrink: 0;
        }
        
        .attachment-preview .pdf-icon {
            width: 60px;
            height: 45px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--error);
            font-size: 20px;
            flex-shrink: 0;
        }
        
        .attachment-info {
            flex: 1;
            min-width: 0;
        }
        .attachment-name {
            font-size: 13px;
            font-weight: 600;
            color: var(--txt);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .attachment-hint {
            font-size: 11px;
            color: var(--txt-muted);
            margin-top: 2px;
        }
        
        .attachment-actions {
            display: flex;
            gap: 6px;
            flex-shrink: 0;
        }
        .btn-attachment {
            padding: 8px 12px;
            border-radius: var(--radius-sm);
            font-size: 11px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            text-decoration: none;
            transition: all var(--duration-fast) var(--ease-out);
            border: none;
            cursor: pointer;
        }
        .btn-view {
            background: rgba(14, 165, 233, 0.12);
            color: var(--info);
        }
        .btn-view:hover {
            background: var(--info);
            color: white;
        }
        .btn-download {
            background: rgba(16, 185, 129, 0.12);
            color: var(--success);
        }
        .btn-download:hover {
            background: var(--success);
            color: white;
        }
        
        .no-attachment {
            text-align: center;
            padding: 12px;
            color: var(--txt-muted);
            font-size: 12px;
        }
        .no-attachment i {
            margin-right: 4px;
            opacity: 0.5;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: var(--txt-muted);
            animation: fadeInUp 0.6s var(--ease-out) both;
        }
        .empty-state i {
            font-size: 64px;
            opacity: 0.2;
            margin-bottom: 20px;
            display: block;
        }
        .empty-state h4 {
            font-family: var(--font-display);
            font-size: 20px;
            font-weight: 700;
            color: var(--txt);
            margin-bottom: 8px;
        }
        .empty-state p {
            font-size: 14px;
            max-width: 400px;
            margin: 0 auto;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .profile-content { flex-direction: column; text-align: center; }
            .profile-stats { margin-left: 0; margin-top: 16px; }
            .stats-row { grid-template-columns: 1fr; }
            .doc-details { grid-template-columns: 1fr; }
            .attachment-preview { flex-direction: column; text-align: center; }
            .attachment-actions { justify-content: center; }
        }
    </style>
</head>
<body>

    <!-- Ambient Background -->
    <div class="ambient-bg">
        <div class="ambient-blob ambient-blob-1"></div>
        <div class="ambient-blob ambient-blob-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <%@ include file="/includes/navbar.jsp" %>

    <main class="main-content">

        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">
                <i class="fas fa-id-card"></i> 
                Mis Documentos Expedidos
            </h1>
            <p class="page-subtitle">Consulta y gestiona tus documentos oficiales</p>
        </div>

        <% if (ciudadano != null) { %>
        
        <!-- Profile Card -->
        <div class="profile-card">
            <div class="profile-content">
                <div class="profile-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="profile-info">
                    <h3><%= nombreCompleto %></h3>
                    <p><i class="fas fa-id-card"></i> CC: <%= ciudadano.getNumeroDocumento() %></p>
                </div>
                <div class="profile-stats">
                    <div class="profile-stat">
                        <div class="profile-stat-value"><%= totalDocs %></div>
                        <div class="profile-stat-label">Documentos</div>
                    </div>
                    <div class="profile-stat">
                        <div class="profile-stat-value"><%= vigentes %></div>
                        <div class="profile-stat-label">Vigentes</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Alert Banner (if there are expiring documents) -->
        <% if (proximos > 0) { %>
        <div class="alert-banner">
            <i class="fas fa-exclamation-triangle"></i>
            <div class="alert-banner-content">
                <div class="alert-banner-title">Atención: <%= proximos %> documento(s) próximo(s) a vencer</div>
                <div class="alert-banner-text">Tienes documentos que vencerán en los próximos 30 días. Te recomendamos renovarlos.</div>
            </div>
        </div>
        <% } %>

        <!-- Stats Cards -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-icon success"><i class="fas fa-check-circle"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= vigentes %></div>
                    <div class="stat-label">Vigentes</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon warning"><i class="fas fa-clock"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= proximos %></div>
                    <div class="stat-label">Próximos a Vencer</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon error"><i class="fas fa-times-circle"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= vencidos %></div>
                    <div class="stat-label">Vencidos</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon muted"><i class="fas fa-ban"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><%= cancelados %></div>
                    <div class="stat-label">Cancelados</div>
                </div>
            </div>
        </div>

        <!-- Documents Grid -->
        <% if (!documentos.isEmpty()) { %>
        <div class="docs-grid">
            <% for (DocumentoExpedido d : documentos) { 
                String estadoClass = "status-vigente";
                String estadoIcon = "fa-check-circle";
                String estadoTexto = d.getEstado() != null ? d.getEstado() : "Vigente";
                
                if ("cancelado".equalsIgnoreCase(d.getEstado())) {
                    estadoClass = "status-cancelado";
                    estadoIcon = "fa-ban";
                    estadoTexto = "Cancelado";
                } else if (d.getFechaVencimiento() != null) {
                    try {
                        java.time.LocalDate fv = d.getFechaVencimiento().toInstant()
                            .atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                        if (fv.isBefore(hoy)) {
                            estadoClass = "status-vencido";
                            estadoIcon = "fa-times-circle";
                            estadoTexto = "Vencido";
                        } else if (fv.isBefore(hoy.plusDays(30))) {
                            estadoClass = "status-proximo";
                            estadoIcon = "fa-clock";
                            estadoTexto = "Próximo a vencer";
                        }
                    } catch (Exception e) {}
                }
                
                // Preparar datos del archivo adjunto
                String archivoUrl = "";
                String archivoTipo = "";
                String archivoNombre = "";
                boolean tieneArchivo = false;
                
                if (d.getImagenDocumento() != null && !d.getImagenDocumento().isEmpty()) {
                    tieneArchivo = true;
                    archivoNombre = d.getImagenDocumento();
                    archivoUrl = request.getContextPath() + "/uploads/documentos/" + archivoNombre;
                    String ext = archivoNombre.substring(archivoNombre.lastIndexOf('.')).toLowerCase();
                    archivoTipo = ext.equals(".pdf") ? "pdf" : "image";
                }
            %>
            <div class="doc-card">
                <div class="doc-card-header">
                    <div class="doc-type"><%= d.getTipoDocumento() %></div>
                    <span class="doc-status <%= estadoClass %>">
                        <i class="fas <%= estadoIcon %>"></i> <%= estadoTexto %>
                    </span>
                </div>
                
                <div class="doc-details">
                    <div class="doc-detail">
                        <span class="doc-detail-label">Expedición</span>
                        <span class="doc-detail-value">
                            <%= d.getFechaExpedicion() != null ? sdf.format(d.getFechaExpedicion()) : "—" %>
                        </span>
                    </div>
                    <div class="doc-detail">
                        <span class="doc-detail-label">Vencimiento</span>
                        <span class="doc-detail-value">
                            <%= d.getFechaVencimiento() != null ? sdf.format(d.getFechaVencimiento()) : "N/A" %>
                        </span>
                    </div>
                </div>
                
                <div class="doc-series">
                    <i class="fas fa-barcode"></i> Serie: <%= d.getNumeroSerie() != null ? d.getNumeroSerie() : "No registrada" %>
                </div>
                
                <% if (d.getObservaciones() != null && !d.getObservaciones().isEmpty()) { %>
                <div class="doc-observations">
                    <i class="fas fa-info-circle"></i> <%= d.getObservaciones() %>
                </div>
                <% } %>
                
                <!-- ═══════════════════════════════════════════════════════════ -->
                <!-- SECCIÓN DE ARCHIVO ADJUNTO - Visualización y Descarga -->
                <!-- ═══════════════════════════════════════════════════════════ -->
                <div class="doc-attachment <%= tieneArchivo ? "has-file" : "" %>">
                    <% if (tieneArchivo) { %>
                        <div class="attachment-preview <%= archivoTipo %>">
                            <% if ("pdf".equals(archivoTipo)) { %>
                                <div class="pdf-icon">
                                    <i class="fas fa-file-pdf"></i>
                                </div>
                            <% } else { %>
                                <img src="<%= archivoUrl %>" alt="Vista previa" 
                                     onerror="this.parentElement.innerHTML='<div class=\'pdf-icon\'><i class=\'fas fa-image\'></i></div>'">
                            <% } %>
                            
                            <div class="attachment-info">
                                <div class="attachment-name"><%= archivoNombre %></div>
                                <div class="attachment-hint">
                                    <% if ("pdf".equals(archivoTipo)) { %>
                                        <i class="fas fa-file-pdf"></i> Documento PDF
                                    <% } else { %>
                                        <i class="fas fa-image"></i> Imagen <%= archivoNombre.substring(archivoNombre.lastIndexOf('.')).toUpperCase() %>
                                    <% } %>
                                </div>
                            </div>
                            
                            <div class="attachment-actions">
                                <a href="<%= archivoUrl %>" target="_blank" class="btn-attachment btn-view" title="Ver en nueva pestaña">
                                    <i class="fas fa-eye"></i> Ver
                                </a>
                                <a href="<%= archivoUrl %>?download=true" class="btn-attachment btn-download" title="Descargar archivo">
                                    <i class="fas fa-download"></i> Descargar
                                </a>
                            </div>
                        </div>
                    <% } else { %>
                        <div class="no-attachment">
                            <i class="fas fa-paperclip"></i> Sin archivo adjunto
                        </div>
                    <% } %>
                </div>
                
            </div>
            <% } %>
        </div>
        <% } else { %>
        <!-- Empty State -->
        <div class="empty-state">
            <i class="fas fa-folder-open"></i>
            <h4>No tienes documentos expedidos</h4>
            <p>Cuando se te expida un documento oficial, aparecerá aquí automáticamente.</p>
        </div>
        <% } %>
        
        <% } else { %>
        <!-- Error State -->
        <div class="empty-state">
            <i class="fas fa-exclamation-triangle"></i>
            <h4>Error al cargar información</h4>
            <p>No se pudo encontrar tu información de ciudadano. Por favor, contacta a la Registraduría.</p>
        </div>
        <% } %>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Theme toggle
        (function() {
            const saved = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', saved);
        })();
        
        // Click en preview de imagen para abrir en nueva pestaña
        document.querySelectorAll('.attachment-preview.image').forEach(preview => {
            preview.addEventListener('click', function(e) {
                // Solo abrir si no se hizo clic en los botones de acción
                if (!e.target.closest('.btn-attachment')) {
                    const img = this.querySelector('img');
                    if (img && img.src) {
                        window.open(img.src, '_blank');
                    }
                }
            });
        });
    </script>
    <script src="<%= request.getContextPath() %>/js/registraduria.js"></script>
</body>
</html>