<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil - Registraduría</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0eef8; font-family: 'Inter', sans-serif; }
        .main-content { margin-left: 260px; padding: 30px; }
        @media (max-width: 992px) { .main-content { margin-left: 0; } }
        .form-card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.04);
            max-width: 500px;
            margin: 0 auto;
        }
        .form-label {
            font-weight: 600;
            color: #18122b;
            margin-bottom: 6px;
        }
        .form-control {
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 12px;
            background: white;
        }
        .form-control:focus {
            border-color: #003366;
            box-shadow: 0 0 0 3px rgba(0,51,102,0.1);
        }
        .btn-primary {
            background: #003366;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            color: white;
        }
        .btn-primary:hover { background: #1a5276; }
        .btn-secondary {
            background: #e2e8f0;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            color: #5a6a7a;
            text-decoration: none;
        }
    </style>
</head>
<body>

<%@ include file="/includes/navbar.jsp" %>

<main class="main-content">
    <div style="margin-bottom: 24px;">
        <a href="<%= request.getContextPath() %>/votante/perfil" class="text-decoration-none" style="color: #5a6a7a;">
            <i class="fas fa-arrow-left"></i> Volver al Perfil
        </a>
    </div>
    
    <div class="form-card">
        <h3 style="margin-bottom: 24px; font-weight: 700; color: #18122b;">
            <i class="fas fa-key"></i> Editar Credenciales
        </h3>
        
        <% if (session.getAttribute("error") != null) { %>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <%= session.getAttribute("error") %>
            </div>
            <% session.removeAttribute("error"); %>
        <% } %>
        
        <% if (session.getAttribute("success") != null) { %>
            <div class="alert alert-success" style="background: #d4edda; color: #155724; padding: 16px; border-radius: 10px; margin-bottom: 20px;">
                <i class="fas fa-check-circle"></i> <%= session.getAttribute("success") %>
            </div>
            <% session.removeAttribute("success"); %>
        <% } %>
        
        <form action="<%= request.getContextPath() %>/votante/editar-perfil" method="POST">
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-user"></i> Nombre de Usuario
                </label>
                <input type="text" name="username" class="form-control" 
                       value="<%= usuario.getUsername() %>" required minlength="4">
                <small class="text-muted">Mínimo 4 caracteres</small>
            </div>
            
            <div class="mb-3">
                <label class="form-label">
                    <i class="fas fa-lock"></i> Nueva Contraseña
                </label>
                <input type="password" name="password" class="form-control" 
                       placeholder="Dejar vacío para no cambiar" minlength="6">
                <small class="text-muted">Mínimo 6 caracteres (opcional)</small>
            </div>
            
            <div class="mb-4">
                <label class="form-label">
                    <i class="fas fa-lock"></i> Confirmar Contraseña
                </label>
                <input type="password" name="confirmPassword" class="form-control" 
                       placeholder="Repite la nueva contraseña">
            </div>
            
            <hr style="margin: 24px 0;">
            
            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <a href="<%= request.getContextPath() %>/votante/perfil" class="btn-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
                <button type="submit" class="btn-primary">
                    <i class="fas fa-save"></i> Guardar Cambios
                </button>
            </div>
        </form>
    </div>
</main>

</body>
</html>