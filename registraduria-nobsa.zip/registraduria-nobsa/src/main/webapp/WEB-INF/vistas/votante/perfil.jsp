<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudadano" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    Ciudadano ciudadano = null;
    try {
        CiudadanoDAO ciudadanoDAO = new CiudadanoDAOImpl();
        ciudadano = ciudadanoDAO.buscarPorDocumento(usuario.getDocumento());
    } catch (Exception e) {
        out.println("<!-- ERROR: " + e.getMessage() + " -->");
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil | Registraduría Municipal de Nobsa</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ═══════════════════════════════════════════════════════════ */
        /* DESIGN TOKENS - Original Background */
        /* ═══════════════════════════════════════════════════════════ */
        :root {
            --primary-900: #001a3a;
            --primary-800: #003366;
            --primary-700: #004080;
            --primary-600: #0055A4;
            --primary-500: #1a6bc4;
            --primary-100: #dbeafe;
            --primary-50: #eff6ff;
            
            --accent-red: #CE1126;
            --accent-yellow: #FCD116;
            
            --bg: #f8fafc;
            --surface: rgba(255, 255, 255, 0.85);
            --surface-2: rgba(248, 250, 252, 0.85);
            --border: rgba(0, 51, 102, 0.12);
            --txt: #0f172a;
            --txt-muted: #64748b;
            --txt-light: #94a3b8;
            
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            
            --glass-bg: rgba(255, 255, 255, 0.75);
            --glass-border: rgba(255, 255, 255, 0.25);
            --glass-shadow: 0 8px 32px rgba(0, 51, 102, 0.08);
            --glass-blur: blur(16px);
            
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.04);
            --shadow-md: 0 4px 12px rgba(0, 51, 102, 0.08);
            --shadow-lg: 0 12px 32px rgba(0, 51, 102, 0.12);
            
            --radius-sm: 12px;
            --radius-md: 16px;
            --radius-lg: 20px;
            --radius-xl: 24px;
            --radius-2xl: 32px;
            
            --font-sans: 'Plus Jakarta Sans', sans-serif;
            --font-display: 'Space Grotesk', sans-serif;
            
            --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
            --duration-fast: 200ms;
            --duration-normal: 350ms;
        }

        [data-theme="dark"] {
            --bg: #0f172a;
            --surface: rgba(30, 41, 59, 0.85);
            --surface-2: rgba(23, 33, 54, 0.85);
            --border: rgba(255, 255, 255, 0.12);
            --txt: #f1f5f9;
            --txt-muted: #94a3b8;
            --txt-light: #64748b;
            --glass-bg: rgba(30, 41, 59, 0.75);
            --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        
        body {
            font-family: var(--font-sans);
            background: var(--bg);
            color: var(--txt);
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        /* ═══════════════════════════════════════════════════════════ */
        /* ORIGINAL BACKGROUND WITH BLOBS */
        /* ═══════════════════════════════════════════════════════════ */
        .ambient-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }
        .ambient-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.08;
            animation: float 20s ease-in-out infinite;
        }
        .ambient-blob-1 {
            width: 600px; height: 600px;
            background: var(--primary-600);
            top: -100px; right: -100px;
        }
        .ambient-blob-2 {
            width: 400px; height: 400px;
            background: var(--accent-yellow);
            bottom: -50px; left: -50px;
            animation-delay: -10s;
        }
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(20px, -20px) scale(1.05); }
        }

        .grid-pattern {
            position: fixed;
            inset: 0;
            background-image: 
                linear-gradient(rgba(0, 51, 102, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 51, 102, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: 0;
            pointer-events: none;
        }

        /* Layout */
        .main-content {
            margin-left: 280px;
            padding: 40px 32px 48px;
            min-height: 100vh;
            position: relative;
            z-index: 10;
        }
        @media (max-width: 1024px) {
            .main-content { margin-left: 0; padding: 24px 20px 40px; }
        }

        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--txt-muted);
            text-decoration: none;
            font-weight: 500;
            padding: 8px 16px;
            border-radius: var(--radius-md);
            transition: all var(--duration-fast) var(--ease-out);
            margin-bottom: 24px;
        }
        .back-btn:hover {
            background: var(--primary-50);
            color: var(--primary-600);
        }

        /* Page Header */
        .page-header {
            margin-bottom: 40px;
            animation: fadeInDown 0.6s var(--ease-out) both;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-title {
            font-family: var(--font-display);
            font-size: 32px;
            font-weight: 700;
            color: var(--txt);
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0 0 8px;
        }
        .page-title i { color: var(--primary-600); font-size: 28px; }

        .page-subtitle {
            font-size: 15px;
            color: var(--txt-muted);
            font-weight: 500;
        }

        /* Profile Container - Structured Layout */
        .profile-container {
            max-width: 1000px;
            margin: 0 auto;
            animation: fadeInUp 0.6s var(--ease-out) 0.1s both;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Profile Header Card */
        .profile-header-card {
            background: linear-gradient(135deg, var(--primary-800), var(--primary-900));
            border-radius: var(--radius-2xl);
            padding: 40px;
            color: white;
            margin-bottom: 32px;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-lg), 0 0 60px rgba(0, 85, 164, 0.2);
        }
        .profile-header-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(252,209,22,0.1) 0%, transparent 60%);
            pointer-events: none;
        }

        .profile-header-content {
            display: flex;
            align-items: center;
            gap: 24px;
            position: relative;
            z-index: 2;
        }
        @media (max-width: 768px) { .profile-header-content { flex-direction: column; text-align: center; } }

        .profile-avatar-large {
            width: 100px;
            height: 100px;
            background: rgba(255,255,255,0.15);
            border-radius: var(--radius-xl);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            font-weight: 700;
            flex-shrink: 0;
            border: 2px solid rgba(255,255,255,0.2);
        }

        .profile-header-info h2 {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 700;
            margin: 0 0 4px;
            color: white;
        }
        .profile-header-info p {
            font-size: 15px;
            color: rgba(255,255,255,0.8);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .profile-role-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.25);
            padding: 6px 14px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            color: white;
            margin-top: 12px;
        }

        /* Info Sections */
        .info-section {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-2xl);
            padding: 32px 40px;
            margin-bottom: 24px;
            box-shadow: var(--glass-shadow);
            animation: fadeInUp 0.5s var(--ease-out) both;
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border);
        }
        .section-header i {
            color: var(--primary-600);
            font-size: 20px;
        }
        .section-header h3 {
            font-family: var(--font-display);
            font-size: 20px;
            font-weight: 700;
            color: var(--txt);
            margin: 0;
        }

        /* Info Grid */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        @media (max-width: 768px) { .info-grid { grid-template-columns: 1fr; } }

        .info-item {
            padding: 16px 0;
            border-bottom: 1px solid var(--border);
        }
        .info-item:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }
        .info-label {
            font-size: 12px;
            color: var(--txt-muted);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 600;
            margin-bottom: 6px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .info-label i {
            color: var(--primary-600);
            font-size: 14px;
        }
        .info-value {
            font-size: 16px;
            font-weight: 600;
            color: var(--txt);
            line-height: 1.4;
        }
        .info-value.highlight {
            color: var(--primary-600);
            font-size: 18px;
        }

        /* Status Badge */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-active {
            background: rgba(16, 185, 129, 0.12);
            color: var(--success);
        }

        /* Action Footer */
        .action-footer {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-2xl);
            padding: 24px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--glass-shadow);
            animation: fadeInUp 0.5s var(--ease-out) 0.3s both;
        }
        @media (max-width: 768px) { .action-footer { flex-direction: column; gap: 16px; } }

        .footer-note {
            font-size: 13px;
            color: var(--txt-muted);
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .btn-edit-profile {
            padding: 14px 28px;
            background: linear-gradient(135deg, var(--primary-600), var(--primary-800));
            border: none;
            border-radius: var(--radius-md);
            color: white;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: all var(--duration-normal) var(--ease-out);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            box-shadow: 0 4px 16px rgba(0, 85, 164, 0.2);
        }
        .btn-edit-profile:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0, 85, 164, 0.3);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .page-title { font-size: 24px; }
            .profile-header-card { padding: 24px; }
            .info-section { padding: 24px; }
            .action-footer { padding: 20px; }
            .btn-edit-profile { width: 100%; justify-content: center; }
        }
    </style>
</head>
<body>

    <!-- Ambient Background - ORIGINAL -->
    <div class="ambient-bg">
        <div class="ambient-blob ambient-blob-1"></div>
        <div class="ambient-blob ambient-blob-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <%@ include file="/includes/navbar.jsp" %>

    <main class="main-content">

        
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">
                <i class="fas fa-user-circle"></i> 
                Mi Perfil
            </h1>
            <p class="page-subtitle">Información de tu cuenta y datos personales registrados</p>
        </div>
        
        <div class="profile-container">
            
            <!-- Profile Header Card -->
            <div class="profile-header-card">
                <div class="profile-header-content">
                    <div class="profile-avatar-large">
                        <%= usuario.getNombres() != null && usuario.getNombres().length() > 0 ? usuario.getNombres().charAt(0) : 'U' %>
                        <%= usuario.getApellidos() != null && usuario.getApellidos().length() > 0 ? usuario.getApellidos().charAt(0) : 'S' %>
                    </div>
                    <div class="profile-header-info">
                        <h2><%= usuario.getNombres() %> <%= usuario.getApellidos() %></h2>
                        <p><i class="fas fa-id-card"></i> C.C. <%= usuario.getDocumento() %></p>
                        <div class="profile-role-badge">
                            <i class="fas fa-user-tag"></i> <%= usuario.getTipoUsuario() %>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Account Information Section -->
            <div class="info-section">
                <div class="section-header">
                    <i class="fas fa-user-circle"></i>
                    <h3>Información de Cuenta</h3>
                </div>
                
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-at"></i> Nombre de Usuario</div>
                        <div class="info-value"><%= usuario.getUsername() %></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-lock"></i> Contraseña</div>
                        <div class="info-value">••••••••</div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-check-circle"></i> Estado</div>
                        <div class="info-value">
                            <span class="status-badge status-active">
                                <i class="fas fa-check-circle"></i> <%= usuario.getEstado() %>
                            </span>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-calendar-alt"></i> Fecha de Registro</div>
                        <div class="info-value"><%= usuario.getFechaRegistro() != null ? usuario.getFechaRegistro() : "—" %></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-clock"></i> Último Acceso</div>
                        <div class="info-value"><%= usuario.getUltimoAcceso() != null ? usuario.getUltimoAcceso() : "—" %></div>
                    </div>
                </div>
            </div>
            
            <!-- Personal Information Section -->
            <% if (ciudadano != null) { %>
            <div class="info-section">
                <div class="section-header">
                    <i class="fas fa-id-card"></i>
                    <h3>Información Personal</h3>
                </div>
                
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-user"></i> Nombre Completo</div>
                        <div class="info-value"><%= ciudadano.getNombreCompleto() %></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-id-card"></i> Número de Documento</div>
                        <div class="info-value highlight"><%= ciudadano.getNumeroDocumento() %></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-birthday-cake"></i> Fecha de Nacimiento</div>
                        <div class="info-value"><%= ciudadano.getFechaNacimiento() %></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-map-marker-alt"></i> Vereda/Barrio</div>
                        <div class="info-value"><%= ciudadano.getVeredaBarrio() != null ? ciudadano.getVeredaBarrio() : "—" %></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-phone"></i> Teléfono</div>
                        <div class="info-value"><%= ciudadano.getTelefono() != null ? ciudadano.getTelefono() : "—" %></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-envelope"></i> Correo Electrónico</div>
                        <div class="info-value"><%= ciudadano.getCorreo() != null ? ciudadano.getCorreo() : "—" %></div>
                    </div>
                </div>
            </div>
            
            <!-- Voting Information Section -->
            <div class="info-section">
                <div class="section-header">
                    <i class="fas fa-vote-yea"></i>
                    <h3>Información de Votación</h3>
                </div>
                
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-table"></i> Mesa Asignada</div>
                        <div class="info-value">
                            <% if (ciudadano.getIdMesa() != null && ciudadano.getIdMesa() > 0) { %>
                                <span class="highlight">Mesa #<%= ciudadano.getNumeroMesa() %></span>
                            <% } else { %>
                                <span style="color: var(--warning);"><i class="fas fa-exclamation-triangle"></i> No asignada</span>
                            <% } %>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-map-marked-alt"></i> Zona de Votación</div>
                        <div class="info-value"><%= ciudadano.getNombreZona() != null ? ciudadano.getNombreZona() : "—" %></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-building"></i> Puesto de Votación</div>
                        <div class="info-value"><%= ciudadano.getPuestoVotacion() != null ? ciudadano.getPuestoVotacion() : "—" %></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-road"></i> Dirección</div>
                        <div class="info-value"><%= ciudadano.getDireccionZona() != null ? ciudadano.getDireccionZona() : "—" %></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label"><i class="fas fa-city"></i> Ciudad</div>
                        <div class="info-value"><%= ciudadano.getNombreCiudad() != null ? ciudadano.getNombreCiudad() : "—" %></div>
                    </div>
                </div>
            </div>
            <% } %>
            
            <!-- Action Footer with Edit Button -->
            <div class="action-footer">
                <div class="footer-note">
                    <i class="fas fa-shield-alt"></i> Tu información está protegida y es confidencial
                </div>
                <a href="<%= request.getContextPath() %>/votante/editar-perfil" class="btn-edit-profile">
                    <i class="fas fa-edit"></i> Editar Perfil
                </a>
            </div>
            
        </div>
    </main>

    <script>
        // Theme toggle
        (function() {
            const saved = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', saved);
        })();
    </script>
    <script src="<%= request.getContextPath() %>/js/registraduria.js"></script>
</body>
</html>