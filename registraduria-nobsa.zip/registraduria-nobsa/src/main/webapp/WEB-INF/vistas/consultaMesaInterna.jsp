<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.CiudadanoDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudadano" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    CiudadanoDAO ciudadanoDAO = new CiudadanoDAOImpl();
    Ciudadano ciudadano = null;
    boolean tieneMesa = false;
    String mensaje = null;
    
    try {
        ciudadano = ciudadanoDAO.buscarConZonaYMesa(usuario.getDocumento());
        if (ciudadano != null) {
            tieneMesa = (ciudadano.getIdMesa() != null && ciudadano.getIdMesa() > 0);
            if (!tieneMesa) {
                mensaje = "Usted no está inscrito en ninguna mesa de votación. Comuníquese con la Registraduría.";
            }
        } else {
            mensaje = "No se encontró su información de ciudadano en el sistema.";
        }
    } catch (Exception e) {
        mensaje = "Error al consultar: " + e.getMessage();
    }
    
    String ctxPath = request.getContextPath();
    boolean esAdmin = usuario.isAdmin();
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Lugar de Votación | Registraduría Municipal de Nobsa</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ═══════════════════════════════════════════════════════════ */
        /* DESIGN TOKENS - Light & Clean Glassmorphism */
        /* ═══════════════════════════════════════════════════════════ */
        :root {
            --primary: #0055A4;
            --primary-light: #1a73e8;
            --primary-dark: #003d7a;
            --accent-yellow: #FCD116;
            --accent-red: #CE1126;
            
            --bg: #f0f4f8;
            --surface: rgba(255, 255, 255, 0.85);
            --surface-solid: #ffffff;
            --border: rgba(0, 85, 164, 0.12);
            --txt: #1e293b;
            --txt-muted: #64748b;
            --txt-light: #94a3b8;
            
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            
            --glass-bg: rgba(255, 255, 255, 0.7);
            --glass-border: rgba(255, 255, 255, 0.4);
            --glass-shadow: 0 8px 32px rgba(0, 85, 164, 0.08);
            --glass-blur: blur(20px);
            
            --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.04);
            --shadow-md: 0 4px 16px rgba(0, 85, 164, 0.08);
            --shadow-lg: 0 8px 32px rgba(0, 85, 164, 0.12);
            
            --radius-sm: 12px;
            --radius-md: 16px;
            --radius-lg: 20px;
            --radius-xl: 24px;
            --radius-2xl: 32px;
            
            --font-sans: 'Plus Jakarta Sans', sans-serif;
            --font-display: 'Space Grotesk', sans-serif;
            
            --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
            --duration-fast: 200ms;
            --duration-normal: 350ms;
        }

        [data-theme="dark"] {
            --bg: #0f172a;
            --surface: rgba(30, 41, 59, 0.85);
            --surface-solid: #1e293b;
            --border: rgba(255, 255, 255, 0.12);
            --txt: #f1f5f9;
            --txt-muted: #94a3b8;
            --txt-light: #64748b;
            --glass-bg: rgba(30, 41, 59, 0.7);
            --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        
        body {
            font-family: var(--font-sans);
            background: linear-gradient(135deg, #e0e7ff 0%, #f0f4f8 50%, #dbeafe 100%);
            color: var(--txt);
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
        }

        /* Ambient Background Soft */
        .ambient-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }
        .ambient-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.15;
            animation: float 25s ease-in-out infinite;
        }
        .ambient-blob-1 {
            width: 500px; height: 500px;
            background: #bfdbfe;
            top: -100px; right: -100px;
        }
        .ambient-blob-2 {
            width: 400px; height: 400px;
            background: #fef3c7;
            bottom: -50px; left: -50px;
            animation-delay: -12s;
        }
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(30px, -30px) scale(1.05); }
        }

        /* Layout */
        .main-content {
            margin-left: 280px;
            padding: 40px 32px 48px;
            min-height: 100vh;
            position: relative;
            z-index: 10;
        }
        @media (max-width: 1024px) {
            .main-content { margin-left: 0; padding: 24px 20px 40px; }
        }

        /* Page Header */
        .page-header {
            text-align: center;
            margin-bottom: 40px;
            animation: fadeInDown 0.6s var(--ease-out) both;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-title {
            font-family: var(--font-display);
            font-size: 32px;
            font-weight: 700;
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin: 0 0 8px;
        }
        .page-title i { font-size: 28px; }

        .page-subtitle {
            font-size: 15px;
            color: var(--txt-muted);
            font-weight: 500;
        }

        /* Glass Card Base */
        .glass-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            -webkit-backdrop-filter: var(--glass-blur);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-2xl);
            box-shadow: var(--glass-shadow), var(--shadow-md);
            transition: all var(--duration-normal) var(--ease-out);
        }
        .glass-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
        }

        /* Search Card for Admin */
        .search-card {
            max-width: 600px;
            margin: 0 auto 40px;
            padding: 40px;
            animation: fadeInUp 0.6s var(--ease-out) 0.1s both;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .search-icon-wrapper {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            box-shadow: 0 8px 24px rgba(0, 85, 164, 0.2);
        }
        .search-icon-wrapper i {
            font-size: 32px;
            color: white;
        }

        .search-card h2 {
            font-family: var(--font-display);
            font-size: 24px;
            font-weight: 700;
            color: var(--txt);
            text-align: center;
            margin: 0 0 8px;
        }
        .search-card p {
            text-align: center;
            color: var(--txt-muted);
            font-size: 14px;
            margin: 0 0 32px;
        }

        .search-input-group {
            position: relative;
            margin-bottom: 20px;
        }
        .search-input {
            width: 100%;
            padding: 16px 20px 16px 52px;
            border: 2px solid var(--border);
            border-radius: var(--radius-lg);
            font-size: 16px;
            background: var(--surface-solid);
            color: var(--txt);
            transition: all var(--duration-fast) var(--ease-out);
        }
        .search-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(0, 85, 164, 0.1);
        }
        .search-input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--txt-muted);
            font-size: 18px;
        }

        .btn-search {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border: none;
            border-radius: var(--radius-lg);
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all var(--duration-normal) var(--ease-out);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 4px 16px rgba(0, 85, 164, 0.2);
        }
        .btn-search:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0, 85, 164, 0.3);
        }

        /* Electoral Credential Card */
        .credential-card {
            max-width: 900px;
            margin: 0 auto;
            overflow: hidden;
            animation: slideInCard 0.8s var(--ease-out) both;
        }
        @keyframes slideInCard {
            from { opacity: 0; transform: translateY(30px) scale(0.98); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        .credential-top-bar {
            height: 6px;
            background: linear-gradient(90deg, var(--accent-yellow), var(--primary), var(--accent-red));
        }

        .credential-header {
            padding: 32px 40px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--border);
        }
        .credential-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(0, 85, 164, 0.08);
            border: 1px solid rgba(0, 85, 164, 0.15);
            padding: 8px 16px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
            color: var(--primary);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .credential-status {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            font-weight: 600;
            color: var(--success);
        }
        .credential-status i {
            font-size: 18px;
        }

        .credential-body {
            padding: 40px;
        }

        .citizen-profile {
            display: flex;
            align-items: center;
            gap: 24px;
            margin-bottom: 32px;
            padding-bottom: 32px;
            border-bottom: 1px solid var(--border);
        }
        .citizen-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: var(--radius-xl);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            color: white;
            flex-shrink: 0;
            box-shadow: 0 4px 16px rgba(0, 85, 164, 0.2);
        }
        .citizen-info h3 {
            font-family: var(--font-display);
            font-size: 24px;
            font-weight: 700;
            color: var(--txt);
            margin: 0 0 4px;
        }
        .citizen-info p {
            font-size: 14px;
            color: var(--txt-muted);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .voting-details-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        @media (max-width: 768px) { .voting-details-grid { grid-template-columns: 1fr; } }

        .detail-item {
            background: var(--surface-solid);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 20px;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .detail-item:hover {
            border-color: var(--primary);
            box-shadow: var(--shadow-sm);
        }
        .detail-label {
            font-size: 11px;
            color: var(--txt-muted);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 600;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .detail-label i {
            color: var(--primary);
            font-size: 14px;
        }
        .detail-value {
            font-family: var(--font-display);
            font-size: 18px;
            font-weight: 700;
            color: var(--txt);
            line-height: 1.3;
        }
        .detail-value.highlight {
            font-size: 24px;
            color: var(--primary);
        }

        .credential-footer {
            padding: 24px 40px;
            border-top: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .footer-note {
            font-size: 13px;
            color: var(--txt-muted);
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .btn-print {
            padding: 12px 24px;
            background: var(--surface-solid);
            border: 2px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--txt);
            font-weight: 600;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .btn-print:hover {
            border-color: var(--primary);
            color: var(--primary);
            transform: translateY(-2px);
            box-shadow: var(--shadow-sm);
        }

        /* Message Cards */
        .message-card {
            max-width: 700px;
            margin: 0 auto 32px;
            padding: 24px 32px;
            display: flex;
            align-items: flex-start;
            gap: 16px;
            animation: fadeInUp 0.5s var(--ease-out) both;
        }
        .message-card.warning {
            border-left: 4px solid var(--warning);
        }
        .message-card.error {
            border-left: 4px solid var(--error);
        }
        .message-icon {
            width: 48px;
            height: 48px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
        }
        .message-icon.warning { background: rgba(245, 158, 11, 0.1); color: var(--warning); }
        .message-icon.error { background: rgba(239, 68, 68, 0.1); color: var(--error); }
        .message-content h4 {
            font-size: 16px;
            font-weight: 700;
            color: var(--txt);
            margin: 0 0 4px;
        }
        .message-content p {
            font-size: 14px;
            color: var(--txt-muted);
            margin: 0;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .credential-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .citizen-profile { flex-direction: column; text-align: center; }
            .credential-footer { flex-direction: column; gap: 16px; }
            .btn-print { width: 100%; justify-content: center; }
            .page-title { font-size: 24px; }
        }
    </style>
</head>
<body>

    <!-- Ambient Background -->
    <div class="ambient-bg">
        <div class="ambient-blob ambient-blob-1"></div>
        <div class="ambient-blob ambient-blob-2"></div>
    </div>

    <%@ include file="/includes/navbar.jsp" %>

    <main class="main-content">
        
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">
                <i class="fas fa-map-marker-alt"></i> 
                <%= esAdmin ? "Consultar Lugar de Votación" : "Mi Lugar de Votación" %>
            </h1>
            <p class="page-subtitle">
                <%= esAdmin ? "Ingrese un número de cédula para consultar la información electoral" : "Información oficial de su puesto de votación asignado" %>
            </p>
        </div>
        
        <%-- SEARCH CARD FOR ADMIN --%>
        <% if (esAdmin) { %>
        <div class="glass-card search-card">
            <div class="search-icon-wrapper">
                <i class="fas fa-search"></i>
            </div>
            <h2>Buscar Ciudadano</h2>
            <p>Ingrese el número de documento para consultar su lugar de votación</p>
            
            <form method="GET" action="<%= ctxPath %>/consulta-mesa-interna">
                <div class="search-input-group">
                    <i class="fas fa-id-card search-input-icon"></i>
                    <input type="text" name="documento" class="search-input" 
                           placeholder="Ej: 1052345678" required maxlength="20">
                </div>
                <button type="submit" class="btn-search">
                    <i class="fas fa-search"></i> Consultar Ahora
                </button>
            </form>
        </div>
        <% } %>
        
        <%-- MESSAGES FOR VOTER --%>
        <% if (!esAdmin && mensaje != null) { %>
        <div class="glass-card message-card warning">
            <div class="message-icon warning">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="message-content">
                <h4>Información Importante</h4>
                <p><%= mensaje %></p>
            </div>
        </div>
        <% } %>
        
        <%-- ERROR MESSAGE --%>
        <% if (request.getAttribute("error") != null) { %>
        <div class="glass-card message-card error">
            <div class="message-icon error">
                <i class="fas fa-times-circle"></i>
            </div>
            <div class="message-content">
                <h4>Error de Consulta</h4>
                <p><%= request.getAttribute("error") %></p>
            </div>
        </div>
        <% } %>
        
        <%-- CREDENTIAL CARD FOR VOTER --%>
        <% if (!esAdmin && ciudadano != null && tieneMesa) { %>
        <div class="glass-card credential-card">
            <div class="credential-top-bar"></div>
            
            <div class="credential-header">
                <div class="credential-badge">
                    <i class="fas fa-shield-alt"></i> Credencial Electoral
                </div>
                <div class="credential-status">
                    <i class="fas fa-check-circle"></i> Habilitado para Votar
                </div>
            </div>
            
            <div class="credential-body">
                <div class="citizen-profile">
                    <div class="citizen-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="citizen-info">
                        <h3><%= ciudadano.getNombreCompleto() %></h3>
                        <p><i class="fas fa-id-card"></i> C.C. <%= ciudadano.getNumeroDocumento() %></p>
                    </div>
                </div>
                
                <div class="voting-details-grid">
                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-city"></i> Municipio
                        </div>
                        <div class="detail-value">
                            <%= ciudadano.getNombreCiudad() != null ? ciudadano.getNombreCiudad() : "No disponible" %>
                        </div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-map-marked-alt"></i> Zona de Votación
                        </div>
                        <div class="detail-value">
                            <%= ciudadano.getNombreZona() != null ? ciudadano.getNombreZona() : "No asignada" %>
                        </div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-building"></i> Puesto de Votación
                        </div>
                        <div class="detail-value">
                            <%= ciudadano.getPuestoVotacion() != null ? ciudadano.getPuestoVotacion() : "No asignado" %>
                        </div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-road"></i> Dirección
                        </div>
                        <div class="detail-value" style="font-size:16px;">
                            <%= ciudadano.getDireccionZona() != null ? ciudadano.getDireccionZona() : "No disponible" %>
                        </div>
                    </div>
                    
                    <div class="detail-item" style="grid-column: span 2;">
                        <div class="detail-label">
                            <i class="fas fa-table"></i> Mesa de Votación Asignada
                        </div>
                        <div class="detail-value highlight">
                            Mesa N° <%= ciudadano.getNumeroMesa() > 0 ? ciudadano.getNumeroMesa() : "No asignada" %>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="credential-footer">
                <div class="footer-note">
                    <i class="fas fa-info-circle"></i> Presente este documento el día de las elecciones
                </div>
                <button onclick="window.print()" class="btn-print">
                    <i class="fas fa-print"></i> Imprimir Credencial
                </button>
            </div>
        </div>
        <% } %>
        
        <%-- RESULT FOR ADMIN SEARCH --%>
        <% if (esAdmin && request.getAttribute("resultado") != null) { 
            Ciudadano resultado = (Ciudadano) request.getAttribute("resultado");
            Boolean tieneMesaAdmin = (Boolean) request.getAttribute("tieneMesa");
        %>
        <div class="glass-card credential-card">
            <div class="credential-top-bar"></div>
            
            <div class="credential-header">
                <div class="credential-badge">
                    <i class="fas fa-shield-alt"></i> Resultado de Búsqueda
                </div>
                <div class="credential-status" style="color:<%= tieneMesaAdmin ? "var(--success)" : "var(--warning)" %>;">
                    <i class="fas fa-<%= tieneMesaAdmin ? "check-circle" : "exclamation-triangle" %>"></i>
                    <%= tieneMesaAdmin ? "Habilitado" : "Sin Mesa" %>
                </div>
            </div>
            
            <div class="credential-body">
                <div class="citizen-profile">
                    <div class="citizen-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="citizen-info">
                        <h3><%= resultado.getNombreCompleto() %></h3>
                        <p><i class="fas fa-id-card"></i> C.C. <%= resultado.getNumeroDocumento() %></p>
                    </div>
                </div>
                
                <% if (tieneMesaAdmin) { %>
                <div class="voting-details-grid">
                    <div class="detail-item">
                        <div class="detail-label"><i class="fas fa-city"></i> Municipio</div>
                        <div class="detail-value"><%= resultado.getNombreCiudad() != null ? resultado.getNombreCiudad() : "No disponible" %></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label"><i class="fas fa-map-marked-alt"></i> Zona de Votación</div>
                        <div class="detail-value"><%= resultado.getNombreZona() != null ? resultado.getNombreZona() : "No asignada" %></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label"><i class="fas fa-building"></i> Puesto de Votación</div>
                        <div class="detail-value"><%= resultado.getPuestoVotacion() != null ? resultado.getPuestoVotacion() : "No asignado" %></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label"><i class="fas fa-road"></i> Dirección</div>
                        <div class="detail-value" style="font-size:16px;"><%= resultado.getDireccionZona() != null ? resultado.getDireccionZona() : "No disponible" %></div>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <div class="detail-label"><i class="fas fa-table"></i> Mesa de Votación</div>
                        <div class="detail-value highlight">Mesa N° <%= resultado.getNumeroMesa() > 0 ? resultado.getNumeroMesa() : "No asignada" %></div>
                    </div>
                </div>
                <% } else { %>
                <div class="glass-card message-card warning" style="margin:0;max-width:100%;">
                    <div class="message-icon warning"><i class="fas fa-info-circle"></i></div>
                    <div class="message-content">
                        <h4>Ciudadano sin Mesa Asignada</h4>
                        <p><%= request.getAttribute("mensaje") != null ? request.getAttribute("mensaje") : "Este ciudadano no tiene mesa de votación asignada." %></p>
                    </div>
                </div>
                <% } %>
            </div>
            
            <div class="credential-footer">
                <div class="footer-note">
                    <i class="fas fa-info-circle"></i> Información consultada por administrador
                </div>
                <button onclick="window.print()" class="btn-print">
                    <i class="fas fa-print"></i> Imprimir
                </button>
            </div>
        </div>
        <% } %>
    </main>

    <script>
        // Theme toggle
        (function() {
            const saved = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', saved);
        })();
    </script>
    <script src="<%= request.getContextPath() %>/js/registraduria.js"></script>
</body>
</html>