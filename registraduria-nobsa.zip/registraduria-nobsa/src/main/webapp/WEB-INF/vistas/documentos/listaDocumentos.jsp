<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.DocumentoDAO" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.DocumentoDAOImpl" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.DocumentoExpedido" %>
<%@ page import="java.util.*" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    // Cargar documentos
    DocumentoDAO documentoDAO = new DocumentoDAOImpl();
    List<DocumentoExpedido> todosDocumentos = new ArrayList<DocumentoExpedido>();
    
    try {
        todosDocumentos = documentoDAO.listarTodos();
    } catch (Exception e) {
        out.println("<!-- ERROR: " + e.getMessage() + " -->");
    }
    
    // Contar por tipo
    int countCedula = 0, countTarjeta = 0, countRegistro = 0, countExtranjeria = 0;
    int countVigente = 0, countVencido = 0, countReemplazado = 0;
    for (DocumentoExpedido doc : todosDocumentos) {
        String tipo = doc.getTipoDocumento();
        if (tipo != null) {
            if (tipo.contains("Cedula") || tipo.contains("Cédula")) countCedula++;
            else if (tipo.contains("Tarjeta")) countTarjeta++;
            else if (tipo.contains("Registro")) countRegistro++;
            else if (tipo.contains("Extranjeria")) countExtranjeria++;
        }
        String est = doc.getEstado() != null ? doc.getEstado() : "vigente";
        if ("vigente".equals(est)) countVigente++;
        else if ("vencido".equals(est)) countVencido++;
        else if ("reemplazado".equals(est)) countReemplazado++;
    }
    
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentos Expedidos | Registraduría Municipal de Nobsa</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ═══════════════════════════════════════════════════════════ */
        /* DESIGN TOKENS - Registraduría Premium */
        /* ═══════════════════════════════════════════════════════════ */
        :root {
            --primary-900: #001a3a;
            --primary-800: #003366;
            --primary-700: #004080;
            --primary-600: #0055A4;
            --primary-500: #1a6bc4;
            --primary-100: #dbeafe;
            --primary-50: #eff6ff;
            
            --accent-red: #CE1126;
            --accent-yellow: #FCD116;
            --accent-yellow-light: #FFE066;
            
            --bg: #f8fafc;
            --surface: rgba(255, 255, 255, 0.85);
            --surface-2: rgba(248, 250, 252, 0.85);
            --border: rgba(0, 51, 102, 0.12);
            --txt: #0f172a;
            --txt-muted: #64748b;
            --txt-light: #94a3b8;
            
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            --info: #0ea5e9;
            
            --glass-bg: rgba(255, 255, 255, 0.75);
            --glass-border: rgba(255, 255, 255, 0.25);
            --glass-shadow: 0 8px 32px rgba(0, 51, 102, 0.08);
            --glass-blur: blur(16px);
            
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.04);
            --shadow-md: 0 4px 12px rgba(0, 51, 102, 0.08);
            --shadow-lg: 0 12px 32px rgba(0, 51, 102, 0.12);
            --shadow-glow: 0 0 40px rgba(0, 85, 164, 0.15);
            
            --radius-sm: 12px;
            --radius-md: 16px;
            --radius-lg: 20px;
            --radius-xl: 24px;
            --radius-2xl: 32px;
            
            --font-sans: 'Plus Jakarta Sans', sans-serif;
            --font-display: 'Space Grotesk', sans-serif;
            
            --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
            --duration-fast: 200ms;
            --duration-normal: 350ms;
        }

        [data-theme="dark"] {
            --bg: #0f172a;
            --surface: rgba(30, 41, 59, 0.85);
            --surface-2: rgba(23, 33, 54, 0.85);
            --border: rgba(255, 255, 255, 0.12);
            --txt: #f1f5f9;
            --txt-muted: #94a3b8;
            --txt-light: #64748b;
            --glass-bg: rgba(30, 41, 59, 0.75);
            --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        
        body {
            font-family: var(--font-sans);
            background: var(--bg);
            color: var(--txt);
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        /* Ambient Background */
        .ambient-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }
        .ambient-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.08;
            animation: float 20s ease-in-out infinite;
        }
        .ambient-blob-1 {
            width: 600px; height: 600px;
            background: var(--primary-600);
            top: -100px; right: -100px;
        }
        .ambient-blob-2 {
            width: 400px; height: 400px;
            background: var(--accent-yellow);
            bottom: -50px; left: -50px;
            animation-delay: -10s;
        }
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(20px, -20px) scale(1.05); }
        }

        .grid-pattern {
            position: fixed;
            inset: 0;
            background-image: 
                linear-gradient(rgba(0, 51, 102, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 51, 102, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: 0;
            pointer-events: none;
        }

        /* Glass Card Base */
        .glass {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            -webkit-backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
        }
        .glass:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
        }

        /* Layout */
        .main-content {
            margin-left: 280px;
            padding: 40px 32px 48px;
            min-height: 100vh;
            position: relative;
            z-index: 10;
        }
        @media (max-width: 1024px) {
            .main-content { margin-left: 0; padding: 24px 20px 40px; }
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            gap: 16px;
            flex-wrap: wrap;
            animation: fadeInDown 0.6s var(--ease-out) both;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-title {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 700;
            color: var(--txt);
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0;
        }
        .page-title i { color: var(--primary-600); font-size: 24px; }

        .page-subtitle {
            font-size: 14px;
            color: var(--txt-muted);
            margin-top: 4px;
            font-weight: 500;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary-600), var(--primary-800));
            border: none;
            padding: 12px 24px;
            border-radius: var(--radius-md);
            color: white;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all var(--duration-normal) var(--ease-out);
            box-shadow: var(--shadow-md), var(--shadow-glow);
        }
        .btn-primary-custom:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg), var(--shadow-glow);
            color: white;
        }

        /* Stats Cards */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }
        @media (max-width: 1200px) { .stats-row { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 768px) { .stats-row { grid-template-columns: 1fr; } }

        .stat-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-xl);
            padding: 24px;
            text-align: center;
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
            animation: fadeInUp 0.5s var(--ease-out) both;
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-600), var(--accent-yellow));
            transform: scaleX(0);
            transform-origin: left;
            transition: transform var(--duration-normal) var(--ease-out);
        }
        .stat-card:hover::before { transform: scaleX(1); }
        .stat-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg), var(--glass-shadow); }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .stat-icon {
            width: 56px;
            height: 56px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin: 0 auto 16px;
        }
        .stat-icon.primary { background: rgba(0, 85, 164, 0.12); color: var(--primary-600); }
        .stat-icon.success { background: rgba(16, 185, 129, 0.12); color: var(--success); }
        .stat-icon.warning { background: rgba(245, 158, 11, 0.12); color: var(--warning); }
        .stat-icon.danger { background: rgba(239, 68, 68, 0.12); color: var(--error); }

        .stat-value {
            font-family: var(--font-display);
            font-size: 32px;
            font-weight: 800;
            color: var(--txt);
            line-height: 1;
            margin-bottom: 4px;
        }
        .stat-label {
            font-size: 13px;
            color: var(--txt-muted);
            font-weight: 500;
        }

        /* Section Title */
        .section-title {
            font-family: var(--font-display);
            font-size: 20px;
            font-weight: 700;
            color: var(--txt);
            margin: 32px 0 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .section-title i { color: var(--primary-600); }

        /* Recent Activity Grid */
        .recientes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 16px;
            margin-bottom: 32px;
        }

        .rec-card {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 16px 20px;
            display: flex;
            align-items: center;
            gap: 14px;
            box-shadow: var(--glass-shadow);
            transition: all var(--duration-normal) var(--ease-out);
            animation: fadeInUp 0.5s var(--ease-out) both;
        }
        .rec-card:hover {
            transform: translateY(-3px) translateX(4px);
            box-shadow: var(--shadow-lg), var(--glass-shadow);
            border-color: var(--primary-300);
        }

        .rec-av {
            width: 48px;
            height: 48px;
            border-radius: var(--radius-md);
            background: linear-gradient(135deg, var(--primary-600), var(--primary-800));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 16px;
            flex-shrink: 0;
        }

        .rec-info { flex: 1; }
        .rec-nm {
            font-weight: 600;
            color: var(--txt);
            font-size: 14px;
        }
        .rec-sub {
            font-size: 12px;
            color: var(--txt-muted);
            margin-top: 3px;
        }

        .badge {
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .badge-vigente { background: rgba(16, 185, 129, 0.12); color: var(--success); }
        .badge-vencido { background: rgba(239, 68, 68, 0.12); color: var(--error); }
        .badge-reemplazado { background: rgba(100, 116, 139, 0.12); color: var(--txt-muted); }

        /* Toolbar */
        .toolbar {
            display: flex;
            gap: 16px;
            margin-bottom: 20px;
            padding: 16px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--glass-shadow);
            flex-wrap: wrap;
        }

        .search-box {
            flex: 1;
            min-width: 250px;
            display: flex;
            align-items: center;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 8px 16px;
        }
        .search-box input {
            border: none;
            padding: 10px;
            width: 100%;
            background: transparent;
            color: var(--txt);
            font-size: 14px;
        }
        .search-box input:focus { outline: none; }
        .search-box i { color: var(--txt-muted); }

        .filter-select {
            padding: 10px 20px;
            border-radius: var(--radius-md);
            background: var(--surface-2);
            border: 1px solid var(--border);
            color: var(--txt);
            font-size: 14px;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .filter-select:focus {
            outline: none;
            border-color: var(--primary-600);
            box-shadow: 0 0 0 3px rgba(0, 85, 164, 0.1);
        }

        .export-btn {
            padding: 10px 20px;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--txt);
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .export-btn:hover {
            background: var(--primary-600);
            color: white;
            border-color: var(--primary-600);
        }

        /* Table Container */
        .table-container {
            background: var(--glass-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-2xl);
            box-shadow: var(--glass-shadow);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: var(--surface-2);
            padding: 16px 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--txt-muted);
            text-align: left;
            border-bottom: 2px solid var(--border);
        }

        td {
            padding: 14px 20px;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
            color: var(--txt);
            font-size: 14px;
        }

        tr { transition: all var(--duration-fast) var(--ease-out); }
        tr:hover {
            background: rgba(0, 85, 164, 0.05);
            transform: translateX(4px);
        }
        tr:last-child td { border-bottom: none; }

        .btn-action {
            padding: 6px 12px;
            border-radius: var(--radius-sm);
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all var(--duration-fast) var(--ease-out);
            margin-right: 4px;
            border: none;
            cursor: pointer;
        }
        .btn-view { background: rgba(14, 165, 233, 0.12); color: var(--info); }
        .btn-view:hover { background: var(--info); color: white; }
        .btn-edit { background: rgba(245, 158, 11, 0.12); color: var(--warning); }
        .btn-edit:hover { background: var(--warning); color: white; }
        .btn-delete { background: rgba(239, 68, 68, 0.12); color: var(--error); }
        .btn-delete:hover { background: var(--error); color: white; }

        /* Modal Glass */
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(8px);
            z-index: 9999;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s var(--ease-out);
        }
        .modal-overlay.active { display: flex; }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            -webkit-backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-2xl);
            width: 90%;
            max-width: 850px;
            max-height: 85vh;
            overflow: hidden;
            box-shadow: var(--shadow-lg), 0 0 60px rgba(0, 0, 0, 0.2);
            animation: slideUp 0.4s var(--ease-out);
        }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .modal-header {
            padding: 24px 28px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(135deg, var(--primary-800), var(--primary-900));
            color: white;
        }
        .modal-header h3 {
            margin: 0;
            font-family: var(--font-display);
            font-size: 18px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .modal-close {
            width: 36px;
            height: 36px;
            border-radius: var(--radius-sm);
            background: rgba(255, 255, 255, 0.15);
            border: none;
            cursor: pointer;
            font-size: 20px;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .modal-close:hover { background: var(--error); transform: rotate(90deg); }

        .modal-body {
            padding: 28px;
            overflow-y: auto;
            max-height: calc(85vh - 80px);
        }

        .ciudadano-info {
            background: var(--surface-2);
            border-radius: var(--radius-lg);
            padding: 24px;
            margin-bottom: 24px;
            border: 1px solid var(--border);
        }
        .ciudadano-info h4 {
            margin-bottom: 20px;
            color: var(--primary-800);
            font-family: var(--font-display);
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .info-item {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .info-label {
            font-size: 11px;
            font-weight: 600;
            color: var(--txt-muted);
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }
        .info-value {
            font-size: 15px;
            font-weight: 600;
            color: var(--txt);
        }

        .documentos-section h5 {
            font-family: var(--font-display);
            font-size: 16px;
            font-weight: 700;
            color: var(--txt);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .documento-item {
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 20px;
            margin-bottom: 12px;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .documento-item:hover {
            border-color: var(--primary-300);
            transform: translateX(4px);
        }

        .documento-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--border);
        }
        .documento-header strong {
            font-size: 16px;
            color: var(--primary-800);
            font-family: var(--font-display);
        }

        .documento-detalle {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            font-size: 13px;
            color: var(--txt-muted);
        }
        .documento-detalle span {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .documento-detalle i { color: var(--primary-600); font-size: 12px; }

        /* Image/PDF Preview in Modal */
        .doc-preview-container {
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px dashed var(--border);
        }
        .doc-preview-image {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .doc-preview-image img {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid var(--border);
            cursor: pointer;
            transition: transform 0.2s;
        }
        .doc-preview-image img:hover {
            transform: scale(1.05);
        }
        .doc-preview-pdf {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .doc-preview-pdf .pdf-icon {
            width: 50px;
            height: 50px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--error);
            font-size: 24px;
        }
        .doc-preview-info {
            flex: 1;
        }
        .doc-preview-info .title {
            font-size: 13px;
            font-weight: 600;
            color: var(--txt);
        }
        .doc-preview-info .subtitle {
            font-size: 11px;
            color: var(--txt-muted);
            margin-top: 2px;
        }
        .doc-preview-actions {
            display: flex;
            gap: 8px;
        }
        .btn-preview-action {
            padding: 8px 12px;
            border-radius: var(--radius-sm);
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all var(--duration-fast) var(--ease-out);
        }
        .btn-preview-action.view {
            background: rgba(14, 165, 233, 0.12);
            color: var(--info);
        }
        .btn-preview-action.view:hover {
            background: var(--info);
            color: white;
        }
        .no-image-notice {
            margin-top: 12px;
            padding: 10px;
            background: var(--surface-2);
            border-radius: 8px;
            text-align: center;
            font-size: 12px;
            color: var(--txt-muted);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--txt-muted);
        }
        .empty-state i {
            font-size: 48px;
            opacity: 0.3;
            margin-bottom: 16px;
            display: block;
        }

        /* Toast Notifications */
        .toast-container {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .toast {
            background: var(--glass-bg);
            backdrop-filter: var(--glass-blur);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 16px 20px;
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 320px;
            animation: slideInRight 0.3s var(--ease-out) both;
        }
        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(100px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .toast.success { border-left: 4px solid var(--success); }
        .toast.error { border-left: 4px solid var(--error); }
        .toast.warning { border-left: 4px solid var(--warning); }
        .toast i { font-size: 18px; }
        .toast.success i { color: var(--success); }
        .toast.error i { color: var(--error); }
        .toast.warning i { color: var(--warning); }

        /* Responsive */
        @media (max-width: 1200px) {
            .info-grid { grid-template-columns: 1fr; }
            .documento-detalle { grid-template-columns: 1fr; }
        }
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: 1fr; }
            .recientes-grid { grid-template-columns: 1fr; }
            .toolbar { flex-direction: column; }
            .search-box { min-width: 100%; }
            .modal-content { width: 95%; max-height: 90vh; }
        }
    </style>
</head>
<body>

    <!-- Ambient Background -->
    <div class="ambient-bg">
        <div class="ambient-blob ambient-blob-1"></div>
        <div class="ambient-blob ambient-blob-2"></div>
    </div>
    <div class="grid-pattern"></div>

    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>

    <%@ include file="/includes/navbar.jsp" %>

    <main class="main-content">
        
        <!-- Page Header -->
        <div class="page-header">
            <div>
                <h1 class="page-title">
                    <i class="fas fa-id-card"></i> 
                    Documentos Expedidos
                </h1>
                <p class="page-subtitle"><%= todosDocumentos.size() %> documentos registrados en el sistema</p>
            </div>
            <a href="<%= request.getContextPath() %>/documentos?action=nuevo" class="btn-primary-custom">
                <i class="fas fa-plus"></i> Expedir Documento
            </a>
        </div>

        <!-- Stats Cards -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-icon primary"><i class="fas fa-id-card"></i></div>
                <div class="stat-value"><%= countCedula %></div>
                <div class="stat-label">Cédulas de Ciudadanía</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon success"><i class="fas fa-id-badge"></i></div>
                <div class="stat-value"><%= countTarjeta %></div>
                <div class="stat-label">Tarjetas de Identidad</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon warning"><i class="fas fa-baby"></i></div>
                <div class="stat-value"><%= countRegistro %></div>
                <div class="stat-label">Registros Civiles</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon danger"><i class="fas fa-globe"></i></div>
                <div class="stat-value"><%= countExtranjeria %></div>
                <div class="stat-label">Cédulas de Extranjería</div>
            </div>
        </div>

        <!-- Additional Stats Row -->
        <div class="stats-row" style="margin-top: -4px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(16,185,129,0.12); color: var(--success);"><i class="fas fa-check-circle"></i></div>
                <div class="stat-value"><%= countVigente %></div>
                <div class="stat-label">Documentos Vigentes</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(239,68,68,0.12); color: var(--error);"><i class="fas fa-times-circle"></i></div>
                <div class="stat-value"><%= countVencido %></div>
                <div class="stat-label">Documentos Vencidos</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(100,116,139,0.12); color: var(--txt-muted);"><i class="fas fa-exchange-alt"></i></div>
                <div class="stat-value"><%= countReemplazado %></div>
                <div class="stat-label">Reemplazados</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(14,165,233,0.12); color: var(--info);"><i class="fas fa-chart-pie"></i></div>
                <div class="stat-value"><%= todosDocumentos.size() > 0 ? Math.round(countVigente * 100.0 / todosDocumentos.size()) : 0 %>%</div>
                <div class="stat-label">Tasa de Vigencia</div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="section-title">
            <i class="fas fa-clock"></i> Actividad Reciente
        </div>
        
        <div class="recientes-grid">
            <% 
            int count = 0;
            for (DocumentoExpedido doc : todosDocumentos) {
                if (count >= 6) break;
                String nom = doc.getNombresCiudadano() != null ? doc.getNombresCiudadano() : "";
                String ape = doc.getApellidosCiudadano() != null ? doc.getApellidosCiudadano() : "";
                String ini = (nom.length() > 0 ? nom.substring(0,1) : "?") + (ape.length() > 0 ? ape.substring(0,1) : "");
                String est = doc.getEstado() != null ? doc.getEstado() : "vigente";
                String badgeClass = "badge-vigente";
                String badgeIcon = "fa-check-circle";
                if ("vencido".equals(est)) { badgeClass = "badge-vencido"; badgeIcon = "fa-times-circle"; }
                else if ("reemplazado".equals(est)) { badgeClass = "badge-reemplazado"; badgeIcon = "fa-exchange-alt"; }
                count++;
            %>
            <div class="rec-card">
                <div class="rec-av"><%= ini.toUpperCase() %></div>
                <div class="rec-info">
                    <div class="rec-nm"><%= nom %> <%= ape %></div>
                    <div class="rec-sub"><%= doc.getTipoDocumento() %> · <%= sdf.format(doc.getFechaExpedicion()) %></div>
                </div>
                <span class="badge <%= badgeClass %>">
                    <i class="fas <%= badgeIcon %>"></i> <%= est %>
                </span>
            </div>
            <% } %>
        </div>

        <!-- All Documents Section -->
        <div class="section-title">
            <i class="fas fa-list"></i> Todos los Documentos
            <span style="font-size: 14px; color: var(--txt-muted); margin-left: 10px; font-weight: 400;">
                (<%= todosDocumentos.size() %> registros)
            </span>
        </div>

        <!-- Toolbar -->
        <div class="toolbar">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="searchInput" placeholder="Buscar por nombre, apellido o documento..." autocomplete="off">
            </div>
            <select id="filterTipo" class="filter-select">
                <option value="todos">Todos los tipos</option>
                <option value="Cedula">Cédula de Ciudadanía</option>
                <option value="Tarjeta">Tarjeta de Identidad</option>
                <option value="Registro">Registro Civil</option>
                <option value="Extranjeria">Cédula de Extranjería</option>
            </select>
            <button class="export-btn" onclick="exportToCSV()">
                <i class="fas fa-file-csv"></i> Exportar CSV
            </button>
            <button class="export-btn" onclick="imprimirListado()">
                <i class="fas fa-print"></i> Imprimir
            </button>
        </div>

        <!-- Table -->
        <div class="table-container">
            <div class="table-responsive">
                <table id="documentosTable">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Documento</th>
                            <th>Tipo</th>
                            <th>Estado</th>
                            <th style="width: 140px;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% if (!todosDocumentos.isEmpty()) {
                            for (DocumentoExpedido doc : todosDocumentos) {
                                String tipoDoc = doc.getTipoDocumento() != null ? doc.getTipoDocumento() : "";
                                String tipoData = "";
                                if (tipoDoc.contains("Cedula")) tipoData = "Cedula";
                                else if (tipoDoc.contains("Tarjeta")) tipoData = "Tarjeta";
                                else if (tipoDoc.contains("Registro")) tipoData = "Registro";
                                else if (tipoDoc.contains("Extranjeria")) tipoData = "Extranjeria";
                                
                                String est = doc.getEstado() != null ? doc.getEstado() : "vigente";
                                String badgeClass = "badge-vigente";
                                String badgeIcon = "fa-check-circle";
                                if ("vencido".equals(est)) { badgeClass = "badge-vencido"; badgeIcon = "fa-times-circle"; }
                                else if ("reemplazado".equals(est)) { badgeClass = "badge-reemplazado"; badgeIcon = "fa-exchange-alt"; }
                        %>
                        <tr class="documento-row" 
                            data-nombre="<%= doc.getNombresCiudadano() != null ? doc.getNombresCiudadano().toLowerCase() : "" %>"
                            data-apellido="<%= doc.getApellidosCiudadano() != null ? doc.getApellidosCiudadano().toLowerCase() : "" %>"
                            data-documento="<%= doc.getNumeroDocumento() != null ? doc.getNumeroDocumento() : "" %>"
                            data-tipo="<%= tipoData %>"
                            data-idciudadano="<%= doc.getIdCiudadano() %>">
                            <td><strong><%= doc.getNombresCiudadano() %></strong></td>
                            <td><%= doc.getApellidosCiudadano() %></td>
                            <td><%= doc.getNumeroDocumento() %></td>
                            <td><%= tipoDoc %></td>
                            <td>
                                <span class="badge <%= badgeClass %>">
                                    <i class="fas <%= badgeIcon %>"></i> <%= est %>
                                </span>
                            </td>
                            <td>
                                <button class="btn-action btn-view" onclick="verDetalles(<%= doc.getIdCiudadano() %>)" title="Ver detalles completos">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <a href="<%= request.getContextPath() %>/documentos?action=editar&id=<%= doc.getId() %>" class="btn-action btn-edit" title="Editar documento">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<%= request.getContextPath() %>/documentos?action=eliminar&id=<%= doc.getId() %>" 
                                   class="btn-action btn-delete" title="Eliminar documento"
                                   onclick="return confirm('¿Está seguro de eliminar este documento? Esta acción no se puede deshacer.')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <% }
                        } else { %>
                        <tr>
                            <td colspan="6">
                                <div class="empty-state">
                                    <i class="fas fa-id-card"></i>
                                    <p><strong>No hay documentos registrados</strong></p>
                                    <p style="margin-top:8px;">Comienza expedendo un nuevo documento</p>
                                    <a href="<%= request.getContextPath() %>/documentos?action=nuevo" class="btn-primary-custom" style="margin-top:16px;">
                                        <i class="fas fa-plus"></i> Expedir Documento
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Detail Modal -->
    <div class="modal-overlay" id="detalleModal" onclick="if(event.target === this) cerrarModal()">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-circle"></i> Detalles del Ciudadano</h3>
                <button class="modal-close" onclick="cerrarModal()">&times;</button>
            </div>
            <div class="modal-body" id="modalBody">
                <div style="text-align: center; padding: 40px; color: var(--txt-muted);">
                    <i class="fas fa-spinner fa-spin" style="font-size: 32px; margin-bottom: 16px; display: block;"></i>
                    Cargando información...
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const ctx = '<%= request.getContextPath() %>';
        
        // ═══════════════════════════════════════════════════════════
        // SEARCH & FILTER
        // ═══════════════════════════════════════════════════════════
        const searchInput = document.getElementById('searchInput');
        const filterTipo = document.getElementById('filterTipo');
        const rows = document.querySelectorAll('.documento-row');
        
        function filterTable() {
            const searchTerm = searchInput.value.toLowerCase();
            const tipoFilter = filterTipo.value;
            
            rows.forEach(row => {
                const nombre = row.dataset.nombre || '';
                const apellido = row.dataset.apellido || '';
                const documento = row.dataset.documento || '';
                const tipo = row.dataset.tipo || '';
                
                const nombreCompleto = nombre + ' ' + apellido;
                const matchesSearch = nombreCompleto.includes(searchTerm) || documento.includes(searchTerm);
                const matchesTipo = tipoFilter === 'todos' || tipo === tipoFilter;
                
                row.style.display = (matchesSearch && matchesTipo) ? '' : 'none';
            });
        }
        
        searchInput.addEventListener('keyup', filterTable);
        filterTipo.addEventListener('change', filterTable);

        // ═══════════════════════════════════════════════════════════
        // EXPORT TO CSV
        // ═══════════════════════════════════════════════════════════
        function exportToCSV() {
            const visibleRows = Array.from(rows).filter(r => r.style.display !== 'none');
            if (visibleRows.length === 0) {
                showToast('No hay datos para exportar', 'warning');
                return;
            }
            
            let csv = 'Nombre,Apellido,Documento,Tipo,Estado\n';
            visibleRows.forEach(row => {
                const cells = row.querySelectorAll('td');
                if (cells.length >= 5) {
                    const data = [
                        cells[0].textContent.trim(),
                        cells[1].textContent.trim(),
                        cells[2].textContent.trim(),
                        cells[3].textContent.trim(),
                        cells[4].textContent.trim()
                    ];
                    csv += data.map(d => `"${d.replace(/"/g, '""')}"`).join(',') + '\n';
                }
            });
            
            const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'documentos_' + new Date().toISOString().split('T')[0] + '.csv';
            link.click();
            showToast('Exportación completada exitosamente', 'success');
        }

        // ═══════════════════════════════════════════════════════════
        // IMPRESIÓN BONITA - SOLO LISTADO DE DOCUMENTOS
        // ═══════════════════════════════════════════════════════════
        function imprimirListado() {
            const visibleRows = Array.from(rows).filter(r => r.style.display !== 'none');
            
            const totalCedula = '<%= countCedula %>';
            const totalTarjeta = '<%= countTarjeta %>';
            const totalRegistro = '<%= countRegistro %>';
            const totalExtranjeria = '<%= countExtranjeria %>';
            const totalVigente = '<%= countVigente %>';
            const totalVencido = '<%= countVencido %>';
            const totalReemplazado = '<%= countReemplazado %>';
            
            const printWindow = window.open('', '_blank', 'width=1000,height=700');
            
            printWindow.document.write(`
                <!DOCTYPE html>
                <html lang="es">
                <head>
                    <meta charset="UTF-8">
                    <title>Listado de Documentos Expedidos - Registraduría Nobsa</title>
                    <style>
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        body {
                            font-family: 'Segoe UI', 'Inter', Arial, sans-serif;
                            background: white;
                            padding: 30px 40px;
                            color: #1e293b;
                        }
                        
                        .print-header {
                            text-align: center;
                            margin-bottom: 30px;
                            padding-bottom: 20px;
                            border-bottom: 3px solid #003366;
                        }
                        
                        .print-header h1 {
                            font-size: 28px;
                            font-weight: 700;
                            color: #003366;
                            margin-bottom: 5px;
                        }
                        
                        .print-header h2 {
                            font-size: 16px;
                            font-weight: 500;
                            color: #64748b;
                            margin-bottom: 10px;
                        }
                        
                        .print-header .date {
                            font-size: 13px;
                            color: #94a3b8;
                        }
                        
                        .stats-mini {
                            display: flex;
                            justify-content: center;
                            gap: 30px;
                            margin-bottom: 25px;
                            padding: 15px;
                            background: #f8fafc;
                            border-radius: 10px;
                            flex-wrap: wrap;
                        }
                        
                        .stat-item {
                            text-align: center;
                        }
                        
                        .stat-item .stat-num {
                            font-size: 22px;
                            font-weight: 800;
                            color: #003366;
                        }
                        
                        .stat-item .stat-lbl {
                            font-size: 11px;
                            color: #64748b;
                            text-transform: uppercase;
                            letter-spacing: 0.5px;
                        }
                        
                        table {
                            width: 100%;
                            border-collapse: collapse;
                            margin-top: 20px;
                            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
                        }
                        
                        th {
                            background: #003366;
                            color: white;
                            padding: 12px 15px;
                            font-size: 13px;
                            font-weight: 600;
                            text-transform: uppercase;
                            letter-spacing: 0.5px;
                            text-align: left;
                        }
                        
                        td {
                            padding: 10px 15px;
                            border-bottom: 1px solid #e2e8f0;
                            font-size: 13px;
                        }
                        
                        tr:nth-child(even) {
                            background: #f8fafc;
                        }
                        
                        .badge {
                            display: inline-block;
                            padding: 4px 10px;
                            border-radius: 20px;
                            font-size: 11px;
                            font-weight: 600;
                        }
                        
                        .badge-success {
                            background: #d4edda;
                            color: #155724;
                        }
                        
                        .badge-danger {
                            background: #f8d7da;
                            color: #721c24;
                        }
                        
                        .badge-secondary {
                            background: #e2e3e5;
                            color: #383d41;
                        }
                        
                        .print-footer {
                            margin-top: 30px;
                            padding-top: 15px;
                            border-top: 1px solid #e2e8f0;
                            text-align: center;
                            font-size: 11px;
                            color: #94a3b8;
                        }
                        
                        @media print {
                            body { padding: 20px; }
                        }
                    </style>
                </head>
                <body>
                    <div class="print-header">
                        <h1>🇨🇴 Registraduría Municipal de Nobsa</h1>
                        <h2>Listado Oficial de Documentos Expedidos</h2>
                        <div class="date">Fecha de impresión: ${new Date().toLocaleDateString('es-CO', { 
                            year: 'numeric', month: 'long', day: 'numeric' 
                        })}</div>
                    </div>
                    
                    <div class="stats-mini">
                        <div class="stat-item">
                            <div class="stat-num">${totalCedula}</div>
                            <div class="stat-lbl">Cédulas</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-num">${totalTarjeta}</div>
                            <div class="stat-lbl">Tarjetas</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-num">${totalRegistro}</div>
                            <div class="stat-lbl">Registros</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-num">${totalExtranjeria}</div>
                            <div class="stat-lbl">Extranjería</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-num">${totalVigente}</div>
                            <div class="stat-lbl">Vigentes</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-num">${totalVencido}</div>
                            <div class="stat-lbl">Vencidos</div>
                        </div>
                    </div>
                    
                    <table>
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Documento</th>
                                <th>Tipo</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
            `);
            
            visibleRows.forEach(row => {
                const cells = row.querySelectorAll('td');
                if (cells.length >= 5) {
                    const nombre = cells[0].textContent.trim();
                    const apellido = cells[1].textContent.trim();
                    const documento = cells[2].textContent.trim();
                    const tipo = cells[3].textContent.trim();
                    const estadoHtml = cells[4].innerHTML;
                    
                    let estadoTexto = estadoHtml.replace(/<[^>]*>/g, '').trim();
                    let badgeClass = 'badge-success';
                    if (estadoTexto.toLowerCase().includes('vencido')) badgeClass = 'badge-danger';
                    else if (estadoTexto.toLowerCase().includes('reemplazado')) badgeClass = 'badge-secondary';
                    
                    printWindow.document.write(`
                        <tr>
                            <td>${nombre}</td>
                            <td>${apellido}</td>
                            <td>${documento}</td>
                            <td>${tipo}</td>
                            <td><span class="badge ${badgeClass}">${estadoTexto}</span></td>
                        </tr>
                    `);
                }
            });
            
            printWindow.document.write(`
                        </tbody>
                    </table>
                    
                    <div class="print-footer">
                        <p>© 2026 Registraduría Municipal de Nobsa - Boyacá, Colombia</p>
                        <p>Documento generado electrónicamente - Válido para consulta</p>
                        <p>Total de registros: ${visibleRows.length}</p>
                    </div>
                    
                    <script>
                        window.onload = function() {
                            window.print();
                            setTimeout(function() { window.close(); }, 500);
                        };
                    <\/script>
                </body>
                </html>
            `);
            
            printWindow.document.close();
        }

        // ═══════════════════════════════════════════════════════════
        // MODAL DETAILS - CON VISUALIZACIÓN DE IMÁGENES/PDFS
        // ═══════════════════════════════════════════════════════════
        const modal = document.getElementById('detalleModal');
        
        function cerrarModal() {
            modal.classList.remove('active');
        }
        
        function verDetalles(idCiudadano) {
            modal.classList.add('active');
            document.getElementById('modalBody').innerHTML = `
                <div style="text-align: center; padding: 40px; color: var(--txt-muted);">
                    <i class="fas fa-spinner fa-spin" style="font-size: 32px; margin-bottom: 16px; display: block;"></i>
                    Cargando información...
                </div>
            `;
            
            fetch(ctx + '/documentos?action=detalleCiudadano&id=' + idCiudadano)
                .then(r => r.json())
                .then(data => {
                    if (data.error) {
                        document.getElementById('modalBody').innerHTML = `
                            <div style="text-align: center; padding: 40px; color: var(--error);">
                                <i class="fas fa-exclamation-circle" style="font-size: 48px; margin-bottom: 16px; display: block;"></i>
                                ${data.error}
                            </div>
                        `;
                        return;
                    }
                    
                    let html = '<div class="ciudadano-info">';
                    html += '<h4><i class="fas fa-user-circle"></i> ' + (data.nombres || '') + ' ' + (data.apellidos || '') + '</h4>';
                    html += '<div class="info-grid">';
                    html += '<div class="info-item"><span class="info-label">Documento</span><span class="info-value">' + (data.numeroDocumento || '—') + '</span></div>';
                    html += '<div class="info-item"><span class="info-label">Fecha Nacimiento</span><span class="info-value">' + (data.fechaNacimiento || '—') + '</span></div>';
                    html += '<div class="info-item"><span class="info-label">Vereda/Barrio</span><span class="info-value">' + (data.veredaBarrio || '—') + '</span></div>';
                    html += '<div class="info-item"><span class="info-label">Teléfono</span><span class="info-value">' + (data.telefono || '—') + '</span></div>';
                    html += '<div class="info-item"><span class="info-label">Correo Electrónico</span><span class="info-value">' + (data.correo || '—') + '</span></div>';
                    if (data.mesa) {
                        html += '<div class="info-item"><span class="info-label">Mesa Asignada</span><span class="info-value">Mesa #' + data.mesa + ' - ' + (data.zona || '') + '</span></div>';
                    }
                    html += '</div></div>';
                    
                    html += '<div class="documentos-section">';
                    html += '<h5><i class="fas fa-id-card"></i> Documentos Expedidos (' + (data.documentos ? data.documentos.length : 0) + ')</h5>';
                    
                    if (data.documentos && data.documentos.length > 0) {
                        data.documentos.forEach(doc => {
                            let badgeClass = 'badge-vigente';
                            let badgeIcon = 'fa-check-circle';
                            if (doc.estado === 'vencido') { badgeClass = 'badge-vencido'; badgeIcon = 'fa-times-circle'; }
                            else if (doc.estado === 'reemplazado') { badgeClass = 'badge-reemplazado'; badgeIcon = 'fa-exchange-alt'; }
                            
                            html += '<div class="documento-item">';
                            html += '<div class="documento-header">';
                            html += '<strong>' + (doc.tipo || '—') + '</strong>';
                            html += '<span class="badge ' + badgeClass + '"><i class="fas ' + badgeIcon + '"></i> ' + (doc.estado || '—') + '</span>';
                            html += '</div>';
                            html += '<div class="documento-detalle">';
                            html += '<span><i class="fas fa-barcode"></i> Serie: ' + (doc.serie || '—') + '</span>';
                            html += '<span><i class="fas fa-calendar"></i> Expedición: ' + (doc.expedicion || '—') + '</span>';
                            html += '<span><i class="fas fa-calendar-alt"></i> Vencimiento: ' + (doc.vencimiento || '—') + '</span>';
                            html += '</div>';
                            
                            // ══════════════════════════════════════════════════════════════
                            // VISUALIZACIÓN DE IMAGEN/ARCHIVO ADJUNTO
                            // ══════════════════════════════════════════════════════════════
                            if (doc.imagenUrl && doc.imagenUrl.trim() !== '') {
                                html += '<div class="doc-preview-container">';
                                
                                if (doc.tipoArchivo === 'pdf') {
                                    // Preview para PDF
                                    html += '<div class="doc-preview-pdf">';
                                    html += '<div class="pdf-icon"><i class="fas fa-file-pdf"></i></div>';
                                    html += '<div class="doc-preview-info">';
                                    html += '<div class="title">Documento PDF</div>';
                                    html += '<div class="subtitle">Haz clic para abrir en nueva pestaña</div>';
                                    html += '</div>';
                                    html += '<div class="doc-preview-actions">';
                                    html += '<a href="' + doc.imagenUrl + '" target="_blank" class="btn-preview-action view">';
                                    html += '<i class="fas fa-external-link-alt"></i> Abrir';
                                    html += '</a>';
                                    html += '</div>';
                                    html += '</div>';
                                } else {
                                    // Preview para imagen
                                    html += '<div class="doc-preview-image">';
                                    html += '<img src="' + doc.imagenUrl + '" alt="Documento" ';
                                    html += 'style="width: 80px; height: 60px; object-fit: cover; border-radius: 10px; border: 1px solid var(--border); cursor: pointer;" ';
                                    html += 'onerror="this.parentElement.innerHTML=\'<span style=\\\'font-size:12px;color:var(--txt-muted)\\\'><i class=\\\'fas fa-image\\\'></i> Imagen no disponible</span>\'" ';
                                    html += 'onclick="window.open(\'' + doc.imagenUrl + '\', \'_blank\')">';
                                    html += '<div class="doc-preview-info">';
                                    html += '<div class="title">Imagen del documento</div>';
                                    html += '<div class="subtitle">Haz clic para ampliar</div>';
                                    html += '</div>';
                                    html += '<div class="doc-preview-actions">';
                                    html += '<a href="' + doc.imagenUrl + '" target="_blank" class="btn-preview-action view">';
                                    html += '<i class="fas fa-expand"></i> Ampliar';
                                    html += '</a>';
                                    html += '</div>';
                                    html += '</div>';
                                }
                                html += '</div>';
                            } else {
                                // Sin archivo adjunto
                                html += '<div class="no-image-notice">';
                                html += '<i class="fas fa-image" style="margin-right: 4px;"></i> Sin imagen adjunta';
                                html += '</div>';
                            }
                            
                            html += '</div>'; // Cierre documento-item
                        });
                    } else {
                        html += '<p style="color: var(--txt-muted); text-align: center; padding: 20px;">No hay documentos registrados para este ciudadano</p>';
                    }
                    html += '</div>';
                    
                    document.getElementById('modalBody').innerHTML = html;
                })
                .catch(err => {
                    document.getElementById('modalBody').innerHTML = `
                        <div style="text-align: center; padding: 40px; color: var(--error);">
                            <i class="fas fa-exclamation-triangle" style="font-size: 48px; margin-bottom: 16px; display: block;"></i>
                            Error al cargar los datos. Intente nuevamente.
                        </div>
                    `;
                    console.error(err);
                });
        }

        // ═══════════════════════════════════════════════════════════
        // TOAST NOTIFICATIONS
        // ═══════════════════════════════════════════════════════════
        function showToast(message, type = 'success') {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            
            const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle' };
            toast.innerHTML = `<i class="fas ${icons[type]}"></i><span>${message}</span>`;
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateX(100px)';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        // ═══════════════════════════════════════════════════════════
        // KEYBOARD SHORTCUTS
        // ═══════════════════════════════════════════════════════════
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
                e.preventDefault();
                window.location.href = ctx + '/documentos?action=nuevo';
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                searchInput.focus();
            }
            if (e.key === 'Escape') {
                cerrarModal();
            }
        });

        // Theme toggle
        (function() {
            const saved = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', saved);
        })();
    </script>
    <script src="<%= request.getContextPath() %>/js/registraduria.js"></script>
</body>
</html>