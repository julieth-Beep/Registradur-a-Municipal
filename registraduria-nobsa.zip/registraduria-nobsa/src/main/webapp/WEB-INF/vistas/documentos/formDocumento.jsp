<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudadano" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.DocumentoExpedido" %>
<%@ page import="java.util.*" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%
    Usuario usuarioSesion = (Usuario) session.getAttribute("usuario");
    if (usuarioSesion == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    DocumentoExpedido documento        = (DocumentoExpedido) request.getAttribute("documento");
    Ciudadano ciudadanoCargado         = (Ciudadano) request.getAttribute("ciudadanoCargado");
    List<DocumentoExpedido> historial  = (List<DocumentoExpedido>) request.getAttribute("historial");
    String errorBusqueda               = (String) request.getAttribute("errorBusqueda");
    if (historial == null) historial   = new ArrayList<DocumentoExpedido>();
    boolean esEdicion = (documento != null && documento.getId() > 0);

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String fechaExpStr = "";
    String fechaVenStr = "";
    if (documento != null) {
        if (documento.getFechaExpedicion() != null) fechaExpStr = sdf.format(documento.getFechaExpedicion());
        if (documento.getFechaVencimiento() != null) fechaVenStr = sdf.format(documento.getFechaVencimiento());
    }
    java.time.LocalDate hoy = java.time.LocalDate.now();
%>
<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><%= esEdicion ? "Editar" : "Nuevo" %> Documento | Registraduria Nobsa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root{
            --bg:#f0eef8; --surface:#fff; --surface2:#f7f5fc;
            --border2:rgba(0,0,0,.055); --txt:#18122b; --txt2:#7a6e93;
            --purple:#7c5cf8; --purple2:#a78bfa; --teal:#14b8a6;
            --green:#10b981; --red:#ef4444; --amber:#f59e0b;
            --sh:0 2px 12px rgba(124,92,248,.07); --r:16px;
            --font:'Inter',-apple-system,sans-serif;
        }
        [data-bs-theme="dark"]{
            --bg:#0d0d14; --surface:#161622; --surface2:#1e1e2e;
            --border2:rgba(255,255,255,.06); --txt:#f0eef8; --txt2:#8b7fb0;
        }
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:var(--font);background:var(--bg);color:var(--txt);min-height:100vh;-webkit-font-smoothing:antialiased;}
        .main-content{margin-left:260px;padding:32px 28px 48px;}

        .page-eyebrow{font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--purple);background:rgba(124,92,248,.1);border:1px solid rgba(124,92,248,.2);padding:5px 12px;border-radius:20px;display:inline-block;margin-bottom:8px;}
        .page-title{font-size:24px;font-weight:800;color:var(--txt);letter-spacing:-.02em;margin-bottom:24px;}
        .btn-back{display:inline-flex;align-items:center;gap:7px;padding:0 14px;height:38px;border-radius:10px;background:var(--surface);border:1px solid var(--border2);color:var(--txt2);font-size:13px;font-weight:600;text-decoration:none;transition:all .2s;}
        .btn-back:hover{background:var(--purple);color:#fff;border-color:var(--purple);}

        .form-card{background:var(--surface);border-radius:var(--r);border:1px solid var(--border2);box-shadow:var(--sh);padding:28px;margin-bottom:24px;}
        .card-title{font-size:15px;font-weight:700;color:var(--txt);display:flex;align-items:center;gap:8px;margin-bottom:20px;padding-bottom:14px;border-bottom:1px solid var(--border2);}
        .card-title i{color:var(--purple);}

        .search-box{display:flex;gap:10px;align-items:stretch;}
        .search-input-field{flex:1;padding:12px 16px;border-radius:12px;border:1px solid var(--border2);background:var(--surface);color:var(--txt);font-size:14px;font-family:var(--font);outline:none;transition:border-color .2s;}
        .search-input-field:focus{border-color:var(--purple);box-shadow:0 0 0 3px rgba(124,92,248,.1);}
        .btn-buscar{padding:0 20px;border-radius:12px;background:linear-gradient(135deg,var(--purple),var(--purple2));color:#fff;font-weight:700;font-size:13px;border:none;cursor:pointer;white-space:nowrap;display:flex;align-items:center;gap:7px;transition:all .2s;}
        .btn-buscar:hover{transform:translateY(-1px);box-shadow:0 6px 16px rgba(124,92,248,.35);}
        .btn-buscar:disabled{opacity:.6;cursor:not-allowed;transform:none;}

        .ciudadano-card{background:linear-gradient(135deg,#7c5cf8,#14b8a6);border-radius:14px;padding:20px;color:#fff;display:flex;align-items:center;gap:16px;margin-top:14px;}
        .ciudadano-av{width:52px;height:52px;border-radius:14px;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;flex-shrink:0;}
        .ciudadano-info{flex:1;}
        .ciudadano-nombre{font-size:17px;font-weight:800;margin-bottom:4px;}
        .ciudadano-meta{font-size:12px;opacity:.85;display:flex;gap:16px;flex-wrap:wrap;}
        .ciudadano-err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:12px;padding:14px 18px;color:var(--red);font-size:13px;font-weight:600;margin-top:12px;display:flex;align-items:center;gap:8px;}

        .historial-timeline{display:flex;flex-direction:column;gap:0;}
        .hist-item{display:flex;gap:14px;position:relative;padding-bottom:16px;}
        .hist-item:last-child{padding-bottom:0;}
        .hist-item::before{content:'';position:absolute;left:19px;top:38px;bottom:0;width:2px;background:var(--border2);}
        .hist-item:last-child::before{display:none;}
        .hist-dot{width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;z-index:1;}
        .hist-content{flex:1;background:var(--surface2);border-radius:12px;border:1px solid var(--border2);padding:12px 14px;}
        .hist-tipo{font-size:13px;font-weight:700;color:var(--txt);margin-bottom:4px;}
        .hist-meta{font-size:11px;color:var(--txt2);display:flex;gap:12px;flex-wrap:wrap;}
        .hist-chip{font-size:10px;font-weight:700;padding:2px 8px;border-radius:12px;}

        /* Preview de imagen en historial */
        .hist-preview {
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px dashed var(--border2);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .hist-preview img {
            width: 60px;
            height: 40px;
            object-fit: cover;
            border-radius: 6px;
            border: 1px solid var(--border2);
            cursor: pointer;
            transition: transform 0.2s;
        }
        .hist-preview img:hover {
            transform: scale(1.05);
        }
        .hist-preview .pdf-icon {
            width: 50px;
            height: 40px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--red);
            font-size: 20px;
        }
        .hist-preview a {
            font-size: 12px;
            color: var(--purple);
            text-decoration: none;
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .hist-preview a:hover {
            text-decoration: underline;
        }

        .form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;}
        .form-group{display:flex;flex-direction:column;gap:6px;}
        .form-label{font-size:12px;font-weight:700;color:var(--txt2);text-transform:uppercase;letter-spacing:.06em;}
        .form-control{padding:11px 14px;border-radius:10px;border:1px solid var(--border2);background:var(--surface);color:var(--txt);font-size:14px;font-family:var(--font);outline:none;transition:border-color .2s;width:100%;}
        .form-control:focus{border-color:var(--purple);box-shadow:0 0 0 3px rgba(124,92,248,.1);}
        select.form-control{cursor:pointer;}
        textarea.form-control{resize:vertical;min-height:80px;}

        .upload-area{
            border:2px dashed var(--border2);
            border-radius:14px;
            padding:28px;
            text-align:center;
            cursor:pointer;
            transition:all .2s;
            background:var(--surface2);
            position: relative;
        }
        .upload-area:hover, .upload-area.drag-over{
            border-color:var(--purple);
            background:rgba(124,92,248,.05);
        }
        .upload-area i{
            font-size:2.5rem;
            color:var(--purple);
            opacity:.5;
            margin-bottom:10px;
        }
        .upload-area p{
            font-size:13px;
            color:var(--txt2);
            margin:0;
        }
        .upload-area strong{color:var(--purple);}
        
        .file-info {
            margin-top: 16px;
            padding: 12px;
            background: var(--surface);
            border-radius: 10px;
            border: 1px solid var(--border2);
            display: none;
        }
        .file-info.show { display: block; }
        .file-info-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 8px;
        }
        .file-info-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            background: var(--purple);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }
        .file-info-name {
            font-size: 13px;
            font-weight: 600;
            color: var(--txt);
            flex: 1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .file-info-size {
            font-size: 11px;
            color: var(--txt2);
        }
        .file-info-remove {
            color: var(--red);
            cursor: pointer;
            font-size: 14px;
            padding: 4px;
        }
        .file-info-remove:hover { color: #dc2626; }
        
        .upload-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            border-radius: 10px;
            padding: 10px 14px;
            color: var(--red);
            font-size: 12px;
            margin-top: 10px;
            display: none;
        }
        .upload-error.show { display: block; }
        
        #uploadPreview {
            margin-top: 16px;
            text-align: center;
        }
        #uploadPreview img {
            max-width: 100%;
            max-height: 200px;
            border-radius: 10px;
            border: 1px solid var(--border2);
            object-fit: contain;
        }
        #uploadPreview .pdf-preview {
            padding: 20px;
            background: var(--surface2);
            border-radius: 10px;
            border: 1px solid var(--border2);
        }
        #uploadPreview .pdf-preview i {
            font-size: 48px;
            color: var(--red);
            margin-bottom: 10px;
        }
        #uploadPreview a {
            display: inline-block;
            margin-top: 8px;
            font-size: 12px;
            color: var(--purple);
            text-decoration: none;
        }
        #uploadPreview a:hover { text-decoration: underline; }

        .form-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:24px;padding-top:20px;border-top:1px solid var(--border2);}
        .btn-cancel{padding:0 18px;height:42px;border-radius:12px;background:var(--surface2);border:1px solid var(--border2);color:var(--txt2);font-weight:600;font-size:13px;text-decoration:none;display:flex;align-items:center;gap:6px;transition:all .2s;}
        .btn-cancel:hover{background:var(--red);color:#fff;border-color:var(--red);}
        .btn-save{padding:0 24px;height:42px;border-radius:12px;background:linear-gradient(135deg,var(--purple),var(--purple2));color:#fff;font-weight:700;font-size:13px;border:none;cursor:pointer;display:flex;align-items:center;gap:7px;box-shadow:0 4px 14px rgba(124,92,248,.3);transition:all .25s;}
        .btn-save:hover{transform:translateY(-2px);box-shadow:0 8px 22px rgba(124,92,248,.45);}
        .btn-save:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

        @media(max-width:992px){.main-content{margin-left:0;padding:24px 16px 40px;}}
        @media(max-width:600px){.form-row{grid-template-columns:1fr;}}
    </style>
</head>
<body>
<%@ include file="/includes/navbar.jsp" %>

<main class="main-content">
    <div style="margin-bottom:20px;">
        <a href="<%= request.getContextPath() %>/documentos" class="btn-back">
            <i class="fas fa-arrow-left"></i> Volver
        </a>
    </div>
    <div class="page-eyebrow"><i class="fas fa-id-card"></i> <%= esEdicion ? "Editar" : "Expedir nuevo" %> documento</div>
    <h1 class="page-title"><%= esEdicion ? "Editar Documento" : "Expedir Documento" %></h1>

    <form action="<%= request.getContextPath() %>/documentos" method="POST" enctype="multipart/form-data" id="formDocumento">
        <input type="hidden" name="id" value="<%= esEdicion ? documento.getId() : "" %>">

        <!-- PASO 1: BUSCAR CIUDADANO -->
        <div class="form-card">
            <div class="card-title"><i class="fas fa-search"></i> Paso 1 — Buscar ciudadano por numero de documento</div>

            <div class="search-box">
                <input type="text" id="inputBuscarDoc" class="search-input-field"
                       placeholder="Ej: 1234567890"
                       value="<%= ciudadanoCargado != null ? ciudadanoCargado.getNumeroDocumento() : (documento != null && documento.getNumeroDocumento() != null ? documento.getNumeroDocumento() : "") %>">
                <button type="button" class="btn-buscar" id="btnBuscar" onclick="buscarCiudadano()">
                    <i class="fas fa-search"></i> Buscar
                </button>
            </div>

            <% if (errorBusqueda != null) { %>
            <div class="ciudadano-err"><i class="fas fa-exclamation-circle"></i> <%= errorBusqueda %></div>
            <% } %>

            <div id="ciudadanoEncontrado" style="<%= ciudadanoCargado != null ? "" : "display:none;" %>">
                <%
                    String nomC = ciudadanoCargado != null ? ciudadanoCargado.getNombres() : "";
                    String apeC = ciudadanoCargado != null ? ciudadanoCargado.getApellidos() : "";
                    String iniC = (nomC.length()>0 ? String.valueOf(nomC.charAt(0)).toUpperCase() : "?")
                                + (apeC.length()>0 ? String.valueOf(apeC.charAt(0)).toUpperCase() : "");
                %>
                <div class="ciudadano-card">
                    <div class="ciudadano-av" id="ciudadanoAv"><%= iniC %></div>
                    <div class="ciudadano-info">
                        <div class="ciudadano-nombre" id="ciudadanoNombre"><%= nomC %> <%= apeC %></div>
                        <div class="ciudadano-meta">
                            <span><i class="fas fa-id-card"></i> <span id="ciudadanoDoc"><%= ciudadanoCargado != null ? ciudadanoCargado.getNumeroDocumento() : "" %></span></span>
                            <span><i class="fas fa-map-marker-alt"></i> <span id="ciudadanoVereda"><%= ciudadanoCargado != null && ciudadanoCargado.getVeredaBarrio() != null ? ciudadanoCargado.getVeredaBarrio() : "—" %></span></span>
                        </div>
                    </div>
                </div>
            </div>

            <input type="hidden" name="idCiudadano" id="idCiudadanoHidden"
                   value="<%= ciudadanoCargado != null ? ciudadanoCargado.getId() : (documento != null ? documento.getIdCiudadano() : "") %>">
        </div>

        <!-- HISTORIAL DEL CIUDADANO -->
        <div class="form-card" id="panelHistorial" style="<%= !historial.isEmpty() ? "" : "display:none;" %>">
            <div class="card-title"><i class="fas fa-history"></i> Historial de documentos</div>
            <div class="historial-timeline" id="historialContainer">
                <%
                    String[] histColors = {"#7c5cf8","#14b8a6","#ec4899","#f59e0b","#3b82f6"};
                    String[] histIcons  = {"fa-id-card","fa-id-badge","fa-baby","fa-passport","fa-file-alt"};
                    int hIdx = 0;
                    for (DocumentoExpedido h : historial) {
                        String hEst = h.getEstado() != null ? h.getEstado() : "vigente";
                        String hChipStyle;
                        if ("vigente".equals(hEst))          hChipStyle = "background:#ecfdf5;color:#059669;";
                        else if ("vencido".equals(hEst))     hChipStyle = "background:#fef2f2;color:#dc2626;";
                        else                                 hChipStyle = "background:rgba(124,92,248,.1);color:#7c5cf8;";
                        
                        // Preparar preview de imagen
                        String imgPreview = "";
                        if (h.getImagenDocumento() != null && !h.getImagenDocumento().isEmpty()) {
                            String imgPath = request.getContextPath() + "/uploads/documentos/" + h.getImagenDocumento();
                            String fileExt = h.getImagenDocumento().substring(h.getImagenDocumento().lastIndexOf('.')).toLowerCase();
                            if (".pdf".equals(fileExt)) {
                                imgPreview = "<div class='hist-preview'><div class='pdf-icon'><i class='fas fa-file-pdf'></i></div><span style='font-size:12px;color:var(--txt-muted)'>PDF adjunto</span><a href='" + imgPath + "' target='_blank'><i class='fas fa-external-link-alt'></i> Ver</a></div>";
                            } else {
                                imgPreview = "<div class='hist-preview'><img src='" + imgPath + "' alt='Documento' onerror='this.parentElement.innerHTML=\"<span style=\\'font-size:11px;color:var(--txt-muted)\\'><i class=\\'fas fa-image\\'></i> Imagen no disponible</span>\"'><a href='" + imgPath + "' target='_blank'><i class='fas fa-expand'></i> Ver</a></div>";
                            }
                        }
                %>
                <div class="hist-item">
                    <div class="hist-dot" style="background:<%= histColors[hIdx % histColors.length] %>20;color:<%= histColors[hIdx % histColors.length] %>;">
                        <i class="fas <%= histIcons[hIdx % histIcons.length] %>"></i>
                    </div>
                    <div class="hist-content">
                        <div class="hist-tipo"><%= h.getTipoDocumento() %></div>
                        <div class="hist-meta">
                            <span>Serie: <%= h.getNumeroSerie() != null ? h.getNumeroSerie() : "—" %></span>
                            <span>Expedicion: <%= h.getFechaExpedicion() %></span>
                            <% if (h.getFechaVencimiento() != null) { %><span>Vence: <%= h.getFechaVencimiento() %></span><% } %>
                            <span class="hist-chip" style="<%= hChipStyle %>"><%= hEst %></span>
                        </div>
                        <% if (!imgPreview.isEmpty()) { %>
                        <%= imgPreview %>
                        <% } %>
                    </div>
                </div>
                <% hIdx++; } %>
            </div>
        </div>

        <!-- PASO 2: DATOS DEL DOCUMENTO -->
        <div class="form-card">
            <div class="card-title"><i class="fas fa-file-alt"></i> Paso 2 — Datos del documento</div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Tipo de documento *</label>
                    <select name="tipoDocumento" class="form-control" required id="selectTipo">
                        <option value="">Seleccione</option>
                        <%
                            String[] tipos = {"Registro Civil de Nacimiento","Tarjeta de Identidad","Cedula de Ciudadania","Cedula de Extranjeria","Contrasena"};
                            String tipoActualDoc = documento != null ? documento.getTipoDocumento() : "";
                            for (String t : tipos) {
                        %>
                        <option value="<%= t %>" <%= t.equals(tipoActualDoc) ? "selected" : "" %>><%= t %></option>
                        <% } %>
                    </select>
                    <small style="font-size:11px;color:var(--txt2);margin-top:2px;" id="infoTipo"></small>
                </div>
                <div class="form-group">
                    <label class="form-label">Numero de serie *</label>
                    <input type="text" name="numeroSerie" class="form-control" required
                           placeholder="Ej: CC-2024-001234"
                           value="<%= documento != null && documento.getNumeroSerie() != null ? documento.getNumeroSerie() : "" %>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Fecha de expedicion *</label>
                    <input type="date" name="fechaExpedicion" class="form-control" required
                           value="<%= fechaExpStr.isEmpty() ? java.time.LocalDate.now().toString() : fechaExpStr %>"
                           max="<%= java.time.LocalDate.now() %>">
                </div>
                <div class="form-group">
                    <label class="form-label">Fecha de vencimiento</label>
                    <input type="date" name="fechaVencimiento" class="form-control" id="inputVencimiento"
                           value="<%= fechaVenStr %>">
                    <small style="font-size:11px;color:var(--txt2);margin-top:2px;">Dejar vacio si no aplica</small>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Estado *</label>
                    <select name="estado" class="form-control" required>
                        <%
                            String[] estados = {"vigente","vencido","reemplazado"};
                            String estActual = documento != null && documento.getEstado() != null ? documento.getEstado() : "vigente";
                            for (String e : estados) {
                        %>
                        <option value="<%= e %>" <%= e.equals(estActual) ? "selected" : "" %>><%= e.substring(0,1).toUpperCase() + e.substring(1) %></option>
                        <% } %>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Observaciones</label>
                    <textarea name="observaciones" class="form-control" rows="2"
                              placeholder="Anotaciones adicionales..."><%= documento != null && documento.getObservaciones() != null ? documento.getObservaciones() : "" %></textarea>
                </div>
            </div>
        </div>

        <!-- PASO 3: IMAGEN DEL DOCUMENTO -->
        <div class="form-card">
            <div class="card-title"><i class="fas fa-camera"></i> Paso 3 — Imagen del documento fisico (opcional)</div>

            <div class="upload-area" id="uploadArea">
                <i class="fas fa-cloud-upload-alt"></i>
                <p><strong>Clic para seleccionar</strong> o arrastra la imagen aqui</p>
                <p style="margin-top:6px;font-size:11px;">JPG, PNG, PDF — maximo 5 MB</p>
                <input type="file" name="imagenDocumento" id="inputImagen" accept="image/*,.pdf" style="display:none;">
            </div>
            
            <div class="file-info" id="fileInfo">
                <div class="file-info-header">
                    <div class="file-info-icon" id="fileIcon">
                        <i class="fas fa-file"></i>
                    </div>
                    <div class="file-info-name" id="fileName">nombre_archivo.jpg</div>
                    <span class="file-info-remove" id="fileRemove" title="Quitar archivo">
                        <i class="fas fa-times"></i>
                    </span>
                </div>
                <div class="file-info-size" id="fileSize">0 KB</div>
            </div>
            
            <div class="upload-error" id="uploadError">
                <i class="fas fa-exclamation-circle"></i> <span id="uploadErrorMsg"></span>
            </div>

            <div id="uploadPreview">
                <% if (esEdicion && documento.getImagenDocumento() != null && !documento.getImagenDocumento().isEmpty()) { 
                    String imgPath = request.getContextPath() + "/uploads/documentos/" + documento.getImagenDocumento();
                    String fileName = documento.getImagenDocumento();
                    String fileExt = fileName.substring(fileName.lastIndexOf('.')).toLowerCase();
                %>
                <p style="font-size:12px;color:var(--txt2);margin-bottom:8px;">Imagen actual:</p>
                <% if (".pdf".equals(fileExt)) { %>
                    <div class="pdf-preview">
                        <i class="fas fa-file-pdf"></i>
                        <p style="font-size:13px;color:var(--txt);"><%= fileName %></p>
                    </div>
                <% } else { %>
                    <img src="<%= imgPath %>" alt="Documento actual" onerror="this.parentElement.style.display='none'">
                <% } %>
                <a href="<%= imgPath %>" target="_blank">Ver archivo completo <i class="fas fa-external-link-alt"></i></a>
                <% } %>
            </div>
        </div>

        <!-- Acciones -->
        <div class="form-actions">
            <a href="<%= request.getContextPath() %>/documentos" class="btn-cancel">
                <i class="fas fa-times"></i> Cancelar
            </a>
            <button type="submit" class="btn-save" id="btnGuardar" disabled>
                <i class="fas fa-save"></i> <%= esEdicion ? "Guardar cambios" : "Expedir documento" %>
            </button>
        </div>
    </form>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const ctx = '<%= request.getContextPath() %>';
    const MAX_FILE_SIZE = 5 * 1024 * 1024;
    const ALLOWED_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'];
    const ALLOWED_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.pdf'];
    
    <% if (ciudadanoCargado != null || esEdicion) { %>
    document.getElementById('btnGuardar').disabled = false;
    <% } %>

    function validarArchivo(file) {
        const errors = [];
        if (file.size > MAX_FILE_SIZE) {
            errors.push('El archivo supera el tamaño máximo de 5 MB');
        }
        if (ALLOWED_TYPES.indexOf(file.type) === -1) {
            errors.push('Tipo de archivo no permitido. Solo JPG, PNG, GIF, WebP o PDF');
        }
        const ext = '.' + file.name.split('.').pop().toLowerCase();
        if (ALLOWED_EXTENSIONS.indexOf(ext) === -1) {
            errors.push('Extensión de archivo no permitida');
        }
        return errors;
    }

    function mostrarFileInfo(file) {
        const fileInfo = document.getElementById('fileInfo');
        const fileName = document.getElementById('fileName');
        const fileSize = document.getElementById('fileSize');
        const fileIcon = document.getElementById('fileIcon');
        
        const sizeKB = (file.size / 1024).toFixed(1);
        const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
        fileSize.textContent = file.size >= 1024 * 1024 ? sizeMB + ' MB' : sizeKB + ' KB';
        
        fileName.textContent = file.name.length > 30 ? file.name.substring(0, 27) + '...' : file.name;
        
        if (file.type === 'application/pdf') {
            fileIcon.innerHTML = '<i class="fas fa-file-pdf"></i>';
            fileIcon.style.background = '#ef4444';
        } else if (file.type.startsWith('image/')) {
            fileIcon.innerHTML = '<i class="fas fa-image"></i>';
            fileIcon.style.background = '#14b8a6';
        } else {
            fileIcon.innerHTML = '<i class="fas fa-file"></i>';
            fileIcon.style.background = '#7c5cf8';
        }
        
        fileInfo.classList.add('show');
    }

    function mostrarPreview(file) {
        const preview = document.getElementById('uploadPreview');
        
        if (file.type === 'application/pdf') {
            preview.innerHTML = `
                <div class="pdf-preview">
                    <i class="fas fa-file-pdf"></i>
                    <p style="font-size:13px;color:var(--txt);margin-bottom:8px;">${file.name}</p>
                    <p style="font-size:11px;color:var(--txt2);">PDF - ${(file.size/1024).toFixed(1)} KB</p>
                </div>
                <p style="font-size:11px;color:var(--txt2);margin-top:8px;">El PDF se visualizará después de guardar</p>
            `;
        } else if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = e => {
                preview.innerHTML = `
                    <img src="${e.target.result}" alt="Preview" style="max-width:100%;max-height:200px;border-radius:10px;border:1px solid var(--border2);object-fit:contain;">
                    <p style="font-size:11px;color:var(--txt2);margin-top:8px;">${file.name} - ${(file.size/1024).toFixed(1)} KB</p>
                `;
            };
            reader.readAsDataURL(file);
        }
        
        preview.style.display = 'block';
    }

    function mostrarUploadError(msg) {
        const errorDiv = document.getElementById('uploadError');
        const errorMsg = document.getElementById('uploadErrorMsg');
        errorMsg.textContent = msg;
        errorDiv.classList.add('show');
        setTimeout(() => {
            errorDiv.classList.remove('show');
        }, 5000);
    }

    function quitarArchivo() {
        document.getElementById('inputImagen').value = '';
        document.getElementById('fileInfo').classList.remove('show');
        document.getElementById('uploadPreview').style.display = 'none';
        document.getElementById('uploadPreview').innerHTML = '';
    }

    const uploadArea = document.getElementById('uploadArea');
    const inputImg = document.getElementById('inputImagen');
    const fileRemove = document.getElementById('fileRemove');

    uploadArea.addEventListener('click', function(e) {
        if (e.target !== fileRemove && !fileRemove.contains(e.target)) {
            inputImg.click();
        }
    });

    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadArea.classList.add('drag-over');
    });
    
    uploadArea.addEventListener('dragleave', function() {
        uploadArea.classList.remove('drag-over');
    });
    
    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('drag-over');
        
        const file = e.dataTransfer.files[0];
        if (file) {
            const errors = validarArchivo(file);
            if (errors.length > 0) {
                mostrarUploadError(errors.join('. '));
                return;
            }
            inputImg.files = e.dataTransfer.files;
            mostrarFileInfo(file);
            mostrarPreview(file);
        }
    });

    inputImg.addEventListener('change', function() {
        const file = this.files[0];
        if (!file) return;
        
        const errors = validarArchivo(file);
        if (errors.length > 0) {
            mostrarUploadError(errors.join('. '));
            this.value = '';
            return;
        }
        
        document.getElementById('uploadError').classList.remove('show');
        
        mostrarFileInfo(file);
        mostrarPreview(file);
    });

    fileRemove.addEventListener('click', function(e) {
        e.stopPropagation();
        quitarArchivo();
    });

    function buscarCiudadano() {
        const numDoc = document.getElementById('inputBuscarDoc').value.trim();
        if (!numDoc) { alert('Ingrese un numero de documento'); return; }
        const btn = document.getElementById('btnBuscar');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Buscando...';

        fetch(ctx + '/documentos?action=buscarCiudadano&numero=' + encodeURIComponent(numDoc))
            .then(r => r.json())
            .then(data => {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-search"></i> Buscar';
                if (data.error) {
                    document.getElementById('ciudadanoEncontrado').style.display = 'none';
                    document.getElementById('idCiudadanoHidden').value = '';
                    document.getElementById('btnGuardar').disabled = true;
                    mostrarError(data.error);
                    return;
                }
                quitarError();
                const ini = (data.nombres[0]||'?').toUpperCase() + (data.apellidos[0]||'').toUpperCase();
                document.getElementById('ciudadanoAv').textContent      = ini;
                document.getElementById('ciudadanoNombre').textContent  = data.nombres + ' ' + data.apellidos;
                document.getElementById('ciudadanoDoc').textContent     = data.numeroDocumento;
                document.getElementById('ciudadanoVereda').textContent  = data.veredaBarrio || '—';
                document.getElementById('idCiudadanoHidden').value      = data.id;
                document.getElementById('ciudadanoEncontrado').style.display = '';
                document.getElementById('btnGuardar').disabled          = false;
                renderHistorial(data.historial);
            })
            .catch(() => {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-search"></i> Buscar';
                mostrarError('Error de conexion. Intente de nuevo.');
            });
    }

    function renderHistorial(historial) {
        const panel = document.getElementById('panelHistorial');
        const cont  = document.getElementById('historialContainer');
        if (!historial || historial.length === 0) { panel.style.display = 'none'; return; }

        const colors = ['#7c5cf8','#14b8a6','#ec4899','#f59e0b','#3b82f6'];
        const icons  = ['fa-id-card','fa-id-badge','fa-baby','fa-passport','fa-file-alt'];
        const chipStyles = {
            'vigente'    : 'background:#ecfdf5;color:#059669;',
            'vencido'    : 'background:#fef2f2;color:#dc2626;',
            'reemplazado': 'background:rgba(124,92,248,.1);color:#7c5cf8;'
        };
        let html = '';
        historial.forEach((h, i) => {
            const c = colors[i % colors.length];
            const ic = icons[i % icons.length];
            const cs = chipStyles[h.estado] || chipStyles['vigente'];
            
            // Preview de imagen
            let imgPreview = '';
            if (h.imagen && h.imagen.trim() !== '') {
                const imgPath = ctx + '/uploads/documentos/' + h.imagen;
                const ext = h.imagen.substring(h.imagen.lastIndexOf('.')).toLowerCase();
                if (ext === '.pdf') {
                    imgPreview = `<div class="hist-preview"><div class="pdf-icon"><i class="fas fa-file-pdf"></i></div><span style="font-size:12px;color:var(--txt-muted)">PDF adjunto</span><a href="${imgPath}" target="_blank"><i class="fas fa-external-link-alt"></i> Ver</a></div>`;
                } else {
                    imgPreview = `<div class="hist-preview"><img src="${imgPath}" alt="Documento" onerror="this.parentElement.innerHTML='<span style=\\'font-size:11px;color:var(--txt-muted)\\'><i class=\\'fas fa-image\\'></i> Imagen no disponible</span>'"><a href="${imgPath}" target="_blank"><i class="fas fa-expand"></i> Ver</a></div>`;
                }
            }
            
            html += '<div class="hist-item">' +
                '<div class="hist-dot" style="background:' + c + '20;color:' + c + ';">' +
                    '<i class="fas ' + ic + '"></i>' +
                '</div>' +
                '<div class="hist-content">' +
                    '<div class="hist-tipo">' + h.tipo + '</div>' +
                    '<div class="hist-meta">' +
                        '<span>Serie: ' + (h.serie || '—') + '</span>' +
                        '<span>Expedicion: ' + h.expedicion + '</span>' +
                        (h.vencimiento ? '<span>Vence: ' + h.vencimiento + '</span>' : '') +
                        '<span class="hist-chip" style="' + cs + '">' + h.estado + '</span>' +
                    '</div>' +
                    (imgPreview ? imgPreview : '') +
                '</div>' +
            '</div>';
        });
        cont.innerHTML = html;
        panel.style.display = '';
    }

    function mostrarError(msg) {
        let err = document.getElementById('errBusqueda');
        if (!err) {
            err = document.createElement('div');
            err.id = 'errBusqueda';
            err.className = 'ciudadano-err';
            document.querySelector('.search-box').after(err);
        }
        err.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + msg;
        err.style.display = '';
    }
    function quitarError() {
        const err = document.getElementById('errBusqueda');
        if (err) err.style.display = 'none';
    }

    document.getElementById('selectTipo').addEventListener('change', function() {
        const tipo = this.value;
        const info = document.getElementById('infoTipo');
        const fv   = document.getElementById('inputVencimiento');
        const hoy  = new Date();
        if (tipo === 'Registro Civil de Nacimiento') {
            info.textContent = 'No tiene vencimiento';
            fv.value = ''; fv.disabled = true;
        } else if (tipo === 'Tarjeta de Identidad') {
            info.textContent = 'Vigente hasta los 18 anos del titular';
            const v = new Date(hoy); v.setFullYear(v.getFullYear() + 10);
            fv.value = v.toISOString().split('T')[0]; fv.disabled = false;
        } else if (tipo === 'Cedula de Ciudadania') {
            info.textContent = 'Vigencia de 10 anos';
            const v = new Date(hoy); v.setFullYear(v.getFullYear() + 10);
            fv.value = v.toISOString().split('T')[0]; fv.disabled = false;
        } else if (tipo === 'Cedula de Extranjeria') {
            info.textContent = 'Vigencia segun resolucion (default 5 anos)';
            const v = new Date(hoy); v.setFullYear(v.getFullYear() + 5);
            fv.value = v.toISOString().split('T')[0]; fv.disabled = false;
        } else {
            info.textContent = '';
            fv.disabled = false;
        }
    });

    document.getElementById('inputBuscarDoc').addEventListener('keydown', function(e) {
        if (e.key === 'Enter') { e.preventDefault(); buscarCiudadano(); }
    });

    document.getElementById('formDocumento').addEventListener('submit', function(e) {
        const idC = document.getElementById('idCiudadanoHidden').value;
        if (!idC || idC === '0') {
            e.preventDefault();
            alert('Debe buscar y seleccionar un ciudadano antes de guardar.');
            return;
        }
        
        const file = document.getElementById('inputImagen').files[0];
        if (file) {
            const errors = validarArchivo(file);
            if (errors.length > 0) {
                e.preventDefault();
                mostrarUploadError(errors.join('. '));
                return;
            }
        }
    });
</script>
</body>
</html>