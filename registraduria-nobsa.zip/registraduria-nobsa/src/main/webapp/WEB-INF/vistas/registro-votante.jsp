<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro – Registraduría Municipal de Nobsa</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }

        :root {
            --azul:       #003087;
            --azul-med:   #1565C0;
            --rojo:       #B71C1C;
            --oro:        #C8921A;
            --oro-light:  #F5C842;
            --gris-borde: #E4E7ED;
            --texto:      #1A1F36;
            --texto-soft: #6B7590;
            --blanco:     #FFFFFF;
        }

        html, body { height:100%; font-family:'DM Sans',sans-serif; background:#EEF1F7; }

        /* 🔥 CAMBIO: PANTALLA COMPLETA */
        .wrapper { 
            width:100vw; 
            height:100vh; 
            display:flex; 
            align-items:stretch; 
            justify-content:stretch;
            padding:0;
        }

        .card-outer {
            width:100%; 
            height:100%;
            border-radius:0;
            overflow:hidden; 
            display:flex;
            box-shadow: none;
            animation: none;
        }

        /* ══ PANEL IZQUIERDO ══ */
        .panel-left {
            flex:0 0 44%; 
            position:relative; 
            overflow:hidden;
            display:flex; 
            flex-direction:column; 
            justify-content:space-between; 
            padding:60px 70px;
            background:
                radial-gradient(ellipse at 20% 20%, rgba(180,210,255,0.55) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 75%, rgba(212,175,80,0.22) 0%, transparent 55%),
                radial-gradient(ellipse at 60% 10%, rgba(180,220,255,0.3) 0%, transparent 50%),
                radial-gradient(ellipse at 10% 85%, rgba(0,48,135,0.08) 0%, transparent 50%),
                linear-gradient(155deg, #dde8f8 0%, #eef3fb 40%, #f5f0e8 100%);
        }
        .panel-left::before {
            content:''; position:absolute; inset:0;
            background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.03'/%3E%3C/svg%3E");
            pointer-events:none; opacity:0.5;
        }

        .pl-brand { position:relative; z-index:5; display:flex; align-items:center; gap:11px; }
        .pl-brand-dot {
            width:34px; height:34px;
            background:linear-gradient(135deg, var(--azul), var(--azul-med));
            border-radius:10px; display:flex; align-items:center; justify-content:center;
            color:white; font-size:15px; box-shadow:0 4px 14px rgba(0,48,135,0.3);
        }
        .pl-brand-text { font-size:0.72rem; font-weight:600; color:var(--azul); letter-spacing:0.02em; line-height:1.3; }
        .pl-brand-text span { display:block; font-weight:400; color:var(--texto-soft); font-size:0.65rem; }

        /* Esfera */
        .sphere-stage { position:absolute; inset:0; display:flex; align-items:center; justify-content:center; z-index:2; }
        .sphere-shadow {
            position:absolute; width:260px; height:40px;
            background:radial-gradient(ellipse, rgba(0,48,135,0.18) 0%, transparent 70%);
            bottom:28%; border-radius:50%; filter:blur(8px);
            animation:shadowPulse 5s ease-in-out infinite;
        }
        @keyframes shadowPulse { 0%,100%{transform:scaleX(1);opacity:0.18} 50%{transform:scaleX(0.85);opacity:0.1} }

        .sphere-main {
            width:280px; height:280px; border-radius:50%; position:relative;
            animation:sphereFloat 6s ease-in-out infinite;
            background:
                radial-gradient(circle at 32% 28%,
                    rgba(255,255,255,0.92) 0%,
                    rgba(180,210,255,0.7) 18%,
                    rgba(140,180,255,0.55) 35%,
                    rgba(180,210,240,0.45) 55%,
                    rgba(200,175,120,0.3) 75%,
                    rgba(180,200,230,0.5) 90%,
                    rgba(100,140,200,0.6) 100%);
            box-shadow:
                0 30px 80px rgba(0,48,135,0.18), 0 10px 30px rgba(0,48,135,0.1),
                inset 0 0 0 1px rgba(255,255,255,0.5),
                inset -60px -60px 120px rgba(0,48,135,0.12),
                inset 40px 40px 80px rgba(255,255,255,0.55);
        }
        .sphere-main::before {
            content:''; position:absolute; top:14%; left:20%; width:38%; height:22%;
            background:radial-gradient(ellipse, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.4) 50%, transparent 100%);
            border-radius:50%; filter:blur(4px); transform:rotate(-20deg);
        }
        .sphere-main::after {
            content:''; position:absolute; bottom:18%; right:16%; width:20%; height:12%;
            background:radial-gradient(ellipse, rgba(255,255,255,0.55) 0%, transparent 100%);
            border-radius:50%; filter:blur(3px);
        }
        @keyframes sphereFloat {
            0%,100%{transform:translateY(0px) rotate(0deg)} 33%{transform:translateY(-14px) rotate(1.5deg)} 66%{transform:translateY(8px) rotate(-1deg)}
        }
        .sphere-small {
            position:absolute; width:55px; height:55px; border-radius:50%; top:30%; right:30%;
            background:radial-gradient(circle at 35% 30%, rgba(255,255,255,0.9), rgba(180,200,255,0.6) 40%, rgba(140,170,230,0.5) 100%);
            box-shadow: 0 8px 20px rgba(0,48,135,0.15), inset 0 0 0 1px rgba(255,255,255,0.4), inset -8px -8px 20px rgba(0,48,135,0.08), inset 6px 6px 12px rgba(255,255,255,0.5);
            animation:satFloat 8s 1.5s ease-in-out infinite;
        }
        .sphere-tiny {
            position:absolute; width:28px; height:28px; border-radius:50%; bottom:35%; left:30%;
            background:radial-gradient(circle at 35% 30%, rgba(255,220,100,0.9), rgba(200,150,30,0.6) 50%, rgba(140,100,0,0.3) 100%);
            box-shadow:0 4px 12px rgba(180,130,0,0.2), inset 3px 3px 8px rgba(255,240,180,0.5);
            animation:satFloat 10s 3s ease-in-out infinite;
        }
        @keyframes satFloat { 0%,100%{transform:translateY(0) translateX(0)} 50%{transform:translateY(-12px) translateX(6px)} }

        .pl-footer { position:relative; z-index:5; }
        .pl-quote { font-family:'Cormorant Garamond',serif; font-size:2.2rem; font-weight:600; color:var(--azul); line-height:1.35; margin-bottom:14px; }
        .pl-quote em { font-style:normal; color:var(--oro); }
        .pl-sub { font-size:1.05rem; color:var(--texto-soft); line-height:1.6; }
        .pl-dots { display:flex; gap:8px; margin-top:24px; }
        .pl-dot { width:8px; height:8px; border-radius:50%; background:rgba(0,48,135,0.15); }
        .pl-dot.active { background:var(--azul); width:28px; border-radius:4px; }

        /* ══ PANEL DERECHO ══ */
        .panel-right {
            flex:1; background:var(--blanco);
            display:flex; flex-direction:column; justify-content:center;
            padding:60px 80px; position:relative; overflow:hidden;
        }
        .panel-right::before {
            content:''; position:absolute; top:-80px; right:-80px; width:280px; height:280px;
            background:radial-gradient(circle, rgba(0,48,135,0.03) 0%, transparent 70%); pointer-events:none;
        }

        .pr-nav { position:absolute; top:40px; left:50px; right:50px; display:flex; align-items:center; justify-content:space-between; z-index:2; }
        .pr-nav-logo { font-size:0.75rem; font-weight:600; color:var(--texto-soft); letter-spacing:0.06em; text-transform:uppercase; display:flex; align-items:center; gap:6px; }
        .pr-nav-logo::before { content:''; width:8px; height:8px; border-radius:50%; background:var(--azul); }
        .tricolor-mini { display:flex; gap:3px; }
        .tricolor-mini span { width:18px; height:4px; border-radius:2px; }
        .tc-1{background:var(--azul)} .tc-2{background:var(--rojo)} .tc-3{background:var(--oro-light)}

        .form-area { position:relative; z-index:2; width:100%; max-width:480px; margin:0 auto; }
        .form-title { font-family:'Cormorant Garamond',serif; font-size:3.5rem; font-weight:700; color:var(--texto); line-height:1.1; margin-bottom:10px; }
        .form-subtitle { font-size:1.05rem; color:var(--texto-soft); margin-bottom:28px; line-height:1.5; }

        .info-box {
            display:flex; align-items:flex-start; gap:11px;
            background:#FFFBEB; border:1.5px solid #FDE68A; border-left:4px solid var(--oro);
            border-radius:12px; padding:14px 16px; margin-bottom:24px;
        }
        .info-box i { color:var(--oro); font-size:14px; margin-top:2px; flex-shrink:0; }
        .info-box small { font-size:0.85rem; color:#92400E; line-height:1.55; }

        .alert { display:flex; align-items:center; gap:11px; padding:12px 16px; border-radius:12px; font-size:0.88rem; font-weight:500; margin-bottom:20px; border:1.5px solid; animation:fadeIn 0.3s ease; }
        @keyframes fadeIn { from{opacity:0;transform:translateY(-6px)} to{opacity:1;transform:translateY(0)} }
        .alert-danger { background:#FEF2F2; border-color:#FECACA; color:#DC2626; }
        .alert-success { background:#F0FDF4; border-color:#BBF7D0; color:#16A34A; }

        /* Grid dos columnas */
        .form-row { display:grid; grid-template-columns:1fr 1fr; gap:16px; }

        .form-group { margin-bottom:18px; }
        .form-label { display:block; font-size:0.82rem; font-weight:600; color:var(--texto); margin-bottom:8px; }
        .input-wrap { position:relative; }
        .form-control {
            width:100%; padding:14px 16px 14px 48px;
            background:var(--blanco); border:1.8px solid var(--gris-borde); border-radius:12px;
            font-size:0.92rem; font-family:'DM Sans',sans-serif; color:var(--texto); outline:none; transition:all 0.25s;
        }
        .form-control::placeholder { color:#BCC3D0; }
        .form-control:focus { border-color:var(--azul); box-shadow:0 0 0 4px rgba(0,48,135,0.08); }
        .input-ico { position:absolute; left:16px; top:50%; transform:translateY(-50%); color:#BCC3D0; font-size:14px; pointer-events:none; transition:color 0.25s; }
        .form-control:focus ~ .input-ico { color:var(--azul); }

        .btn-main {
            width:100%; padding:16px; background:var(--azul); border:none; border-radius:12px;
            color:white; font-size:0.95rem; font-weight:700; font-family:'DM Sans',sans-serif; cursor:pointer;
            position:relative; overflow:hidden; transition:all 0.3s;
            box-shadow:0 6px 24px rgba(0,48,135,0.28);
            display:flex; align-items:center; justify-content:center; gap:10px; margin-top:6px;
        }
        .btn-main::after { content:''; position:absolute; top:0; left:-100%; width:100%; height:100%; background:linear-gradient(90deg,transparent,rgba(255,255,255,0.14),transparent); transition:left 0.5s; }
        .btn-main:hover::after { left:100%; }
        .btn-main:hover { background:#00267a; box-shadow:0 10px 32px rgba(0,48,135,0.38); transform:translateY(-2px); }
        .btn-main:active { transform:translateY(0); }

        .sep { display:flex; align-items:center; gap:16px; margin:20px 0 16px; }
        .sep-line { flex:1; height:1.5px; background:var(--gris-borde); }
        .sep-text { font-size:0.8rem; color:#BCC3D0; white-space:nowrap; }

        /* LIQUID GLASS */
        .liquid-row { display:flex; gap:12px; }
        .liq-btn {
            flex:1; display:inline-flex; align-items:center; justify-content:center; gap:8px; padding:12px 14px;
            text-decoration:none; font-family:'DM Sans',sans-serif; font-size:0.85rem; font-weight:600; color:var(--texto-soft);
            border-radius:50px; position:relative; overflow:hidden;
            transition:all 0.35s cubic-bezier(0.34,1.4,0.64,1); cursor:pointer; border:none;
            background:linear-gradient(145deg, rgba(255,255,255,0.95) 0%, rgba(240,244,252,0.9) 100%);
            box-shadow: 0 3px 12px rgba(0,30,80,0.09), 0 1px 4px rgba(0,30,80,0.06), inset 0 1px 0 rgba(255,255,255,1), inset 0 -1px 0 rgba(0,30,80,0.05), inset 1px 0 0 rgba(255,255,255,0.9), inset -1px 0 0 rgba(0,30,80,0.03);
            border:1px solid rgba(0,30,80,0.1);
        }
        .liq-btn::before { content:''; position:absolute; top:0; left:0; right:0; height:48%; background:linear-gradient(180deg,rgba(255,255,255,0.8) 0%,rgba(255,255,255,0.1) 100%); border-radius:50px 50px 0 0; pointer-events:none; }
        .liq-btn:hover { color:var(--azul); transform:translateY(-3px) scale(1.02); box-shadow:0 8px 24px rgba(0,30,80,0.14), 0 3px 10px rgba(0,30,80,0.08), inset 0 1px 0 rgba(255,255,255,1), inset 0 -1px 0 rgba(0,30,80,0.06), inset 1px 0 0 rgba(255,255,255,0.95), inset -1px 0 0 rgba(0,30,80,0.04); border-color:rgba(0,48,135,0.18); }
        .liq-btn:active { transform:translateY(0) scale(0.99); }
        .liq-btn i { font-size:13px; }

        .form-foot { font-size:0.88rem; color:var(--texto-soft); text-align:center; margin-top:18px; }
        .form-foot a { color:var(--azul); font-weight:600; text-decoration:none; }
        .form-foot a:hover { text-decoration:underline; }

        .pr-footer { position:absolute; bottom:40px; left:50px; z-index:2; }
        .pr-footer-copy { font-size:0.75rem; color:#C8CDD8; }

        .loading { display:inline-block; width:18px; height:18px; border:2.5px solid rgba(255,255,255,0.3); border-radius:50%; border-top-color:white; animation:spin 0.8s linear infinite; }
        @keyframes spin { to{transform:rotate(360deg)} }

        @media (max-width:1024px) {
            .panel-left { display:none; }
            .panel-right { padding:40px 50px; }
            .form-title { font-size:2.8rem; }
        }
        
        @media (max-width:768px) {
            .panel-right { padding:40px 30px; }
            .form-title { font-size:2.4rem; }
            .form-row { grid-template-columns:1fr; }
            .liquid-row { flex-direction:column; }
            .pr-nav { top:30px; left:30px; right:30px; }
            .pr-footer { bottom:30px; left:30px; }
        }
    </style>
</head>
<body>
<div class="wrapper">
    <div class="card-outer">

        <!-- PANEL IZQUIERDO -->
        <div class="panel-left">
            <div class="pl-brand">
                <div class="pl-brand-dot"><i class="fas fa-landmark"></i></div>
                <div class="pl-brand-text">
                    Registraduría Municipal
                    <span>Nobsa · Boyacá, Colombia</span>
                </div>
            </div>

            <div class="sphere-stage">
                <div class="sphere-shadow"></div>
                <div class="sphere-main"></div>
                <div class="sphere-small"></div>
                <div class="sphere-tiny"></div>
            </div>

            <div class="pl-footer">
                <p class="pl-quote">Tu identidad civil,<br><em>protegida y digital.</em></p>
                <p class="pl-sub">Crea tu cuenta para acceder a los<br>servicios en línea de la Registraduría.</p>
                <div class="pl-dots">
                    <div class="pl-dot"></div>
                    <div class="pl-dot active"></div>
                    <div class="pl-dot"></div>
                </div>
            </div>
        </div>

        <!-- PANEL DERECHO -->
        <div class="panel-right">
            <div class="pr-nav">
                <span class="pr-nav-logo">Sistema Civil Electoral</span>
                <div class="tricolor-mini">
                    <span class="tc-1"></span><span class="tc-2"></span><span class="tc-3"></span>
                </div>
            </div>

            <div class="form-area">
                <h1 class="form-title">Crear<br>cuenta.</h1>
                <p class="form-subtitle">Regístrate para consultar tu lugar de votación y documentos.</p>

                <div class="info-box">
                    <i class="fas fa-circle-info"></i>
                    <small>Tu cédula debe estar registrada previamente en el sistema por un administrador de la Registraduría.</small>
                </div>

                <% if (request.getAttribute("error") != null) { %>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><%= request.getAttribute("error") %></span>
                    </div>
                <% } %>
                <% if (request.getAttribute("success") != null) { %>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <span><%= request.getAttribute("success") %></span>
                    </div>
                <% } %>

                <form action="<%= request.getContextPath() %>/registro-votante" method="POST">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Número de Cédula</label>
                            <div class="input-wrap">
                                <input type="text" name="documento" class="form-control" placeholder="Ej: 1052345678" required maxlength="10">
                                <i class="fas fa-id-card input-ico"></i>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Usuario</label>
                            <div class="input-wrap">
                                <input type="text" name="username" class="form-control" placeholder="Tu usuario" required minlength="4">
                                <i class="fas fa-user input-ico"></i>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Contraseña</label>
                        <div class="input-wrap">
                            <input type="password" name="password" class="form-control" placeholder="Mínimo 6 caracteres" required minlength="6">
                            <i class="fas fa-lock input-ico"></i>
                        </div>
                    </div>

                    <button type="submit" class="btn-main" id="btnReg">
                        <i class="fas fa-user-plus"></i>
                        <span>Crear cuenta</span>
                    </button>
                </form>

                <div class="sep">
                    <div class="sep-line"></div>
                    <span class="sep-text">o continúa con</span>
                    <div class="sep-line"></div>
                </div>

                <div class="liquid-row">
                    <a href="<%= request.getContextPath() %>/login" class="liq-btn">
                        <i class="fas fa-sign-in-alt"></i><span>Iniciar sesión</span>
                    </a>
                    <a href="<%= request.getContextPath() %>/" class="liq-btn">
                        <i class="fas fa-house"></i><span>Inicio</span>
                    </a>
                    <a href="<%= request.getContextPath() %>/consulta-mesa" class="liq-btn">
                        <i class="fas fa-map-pin"></i><span>Consultar mesa</span>
                    </a>
                </div>

                <p class="form-foot">
                    ¿Ya tienes cuenta? <a href="<%= request.getContextPath() %>/login">Iniciar sesión aquí</a>
                </p>
            </div>

            <div class="pr-footer">
                <span class="pr-footer-copy">© 2026 Registraduría Municipal de Nobsa</span>
            </div>
        </div>

    </div>
</div>

<script>
    document.querySelectorAll('.form-control').forEach(inp => {
        inp.addEventListener('focus', () => { if(inp.nextElementSibling) inp.nextElementSibling.style.color='#003087'; });
        inp.addEventListener('blur',  () => { if(!inp.value && inp.nextElementSibling) inp.nextElementSibling.style.color=''; });
    });
    document.querySelector('form').addEventListener('submit', function() {
        const btn = document.getElementById('btnReg');
        btn.innerHTML = '<span class="loading"></span> Registrando...';
        btn.disabled = true;
    });
</script>
</body>
</html>