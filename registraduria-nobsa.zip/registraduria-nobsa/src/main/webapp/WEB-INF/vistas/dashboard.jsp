<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%@ page import="co.sena.cimm.adso.registraduria.dao.*" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.*" %>
<%@ page import="java.util.*" %>
<%@ page import="java.time.*" %>
<%@ page import="java.time.format.*" %>
<%
    // ═══════════════════════════════════════════════════════════
    // 1. AUTENTICACIÓN
    // ═══════════════════════════════════════════════════════════
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }
    
    boolean esAdmin = usuario.isAdmin();
    boolean esVotante = usuario.isVotante();
    
    // ═══════════════════════════════════════════════════════════
    // 2. INICIALIZACIÓN DE DAOs
    // ═══════════════════════════════════════════════════════════
    CiudadanoDAO ciudadanoDAO = new CiudadanoDAOImpl();
    DocumentoDAO documentoDAO = new DocumentoDAOImpl();
    ZonaVotacionDAO zonaDAO = new ZonaVotacionDAOImpl();
    MesaVotacionDAO mesaDAO = new MesaVotacionDAOImpl();
    
    // ═══════════════════════════════════════════════════════════
    // 3. VARIABLES PARA LA VISTA (SIN DIAMOND <>)
    // ═══════════════════════════════════════════════════════════
    int totalCiudadanos = 0, totalZonas = 0, totalMesas = 0, totalDocumentos = 0;
    int ciudadanosSinMesa = 0, docsPorVencer30 = 0;
    int mesasOcupadas = 0, mesasVacias = 0, porcentajeOcupacion = 0;
    
    List<Ciudadano> ultimosCiudadanos = new ArrayList<Ciudadano>();
    List<DocumentoExpedido> docsProximosVencer = new ArrayList<DocumentoExpedido>();
    Ciudadano ciudadanoVotante = null;
    List<DocumentoExpedido> docsVotante = new ArrayList<DocumentoExpedido>();
    
    LocalDate hoy = LocalDate.now();
    int mesActual = hoy.getMonthValue();
    int anioActual = hoy.getYear();
    String[] nombresMes = {"","Enero","Febrero","Marzo","Abril","Mayo","Junio",
                           "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
    
    DateTimeFormatter fmtFecha = DateTimeFormatter.ofPattern("EEEE d 'de' MMMM yyyy", new Locale("es","CO"));
    String fechaHoy = hoy.format(fmtFecha);
    fechaHoy = fechaHoy.substring(0,1).toUpperCase() + fechaHoy.substring(1);
    
    try {
        if (esAdmin) {
            totalCiudadanos = ciudadanoDAO.contarTotal();
            totalZonas = zonaDAO.listarTodos().size();
            totalMesas = mesaDAO.listarTodos().size();
            totalDocumentos = documentoDAO.contarTotal();
            
            List<Ciudadano> todos = ciudadanoDAO.listarTodos();
            for (Ciudadano c : todos) {
                if (c.getIdMesa() == null || c.getIdMesa() == 0) ciudadanosSinMesa++;
            }
            
            int maxUltimos = Math.min(10, todos.size());
            for (int i = 0; i < maxUltimos; i++) {
                ultimosCiudadanos.add(todos.get(i));
            }
            
            LocalDate limite = hoy.plusDays(30);
            List<DocumentoExpedido> todosDocs = documentoDAO.listarTodos();
            for (DocumentoExpedido d : todosDocs) {
                if (d.getFechaVencimiento() != null) {
                    LocalDate fv = new java.sql.Date(d.getFechaVencimiento().getTime()).toLocalDate();
                    if (!fv.isBefore(hoy) && fv.isBefore(limite)) {
                        docsPorVencer30++;
                        if (docsProximosVencer.size() < 10) {
                            docsProximosVencer.add(d);
                        }
                    }
                }
            }
            
            Set<Integer> mesasConVotantesSet = new HashSet<Integer>();
            for (Ciudadano c : todos) {
                if (c.getIdMesa() != null && c.getIdMesa() > 0) {
                    mesasConVotantesSet.add(c.getIdMesa());
                }
            }
            mesasOcupadas = mesasConVotantesSet.size();
            mesasVacias = totalMesas - mesasOcupadas;
            porcentajeOcupacion = totalMesas > 0 ? (mesasOcupadas * 100 / totalMesas) : 0;
            
        } else if (esVotante) {
            ciudadanoVotante = ciudadanoDAO.buscarPorDocumento(usuario.getDocumento());
            if (ciudadanoVotante != null) {
                docsVotante = documentoDAO.listarPorCiudadano(ciudadanoVotante.getId());
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
%>
<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Registraduría Nobsa</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* ══════════════════════════════════════════
           TOKENS — Registraduría (MISMO ESTILO QUE BIBLIOTECA)
        ══════════════════════════════════════════ */
        :root {
            --bg:        #f0eef8;
            --surface:   #ffffff;
            --surface2:  #f7f5fc;
            --border:    rgba(0,51,102,0.10);
            --border2:   rgba(0,0,0,0.055);
            --txt:       #18122b;
            --txt2:      #5a6a7a;
            --primary:   #003366;
            --primary2:  #1a5276;
            --teal:      #14b8a6;
            --amber:     #f59e0b;
            --orange:    #f97316;
            --green:     #10b981;
            --red:       #dc2626;
            --blue:      #3b82f6;
            --yellow:    #eab308;
            --sh-card:   0 2px 12px rgba(0,51,102,0.06), 0 1px 3px rgba(0,0,0,0.04);
            --sh-hover:  0 10px 30px rgba(0,51,102,0.14), 0 2px 8px rgba(0,0,0,0.05);
            --r:         16px;
            --r-lg:      20px;
            --font: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        [data-bs-theme="dark"] {
            --bg:       #0d0d14;
            --surface:  #161622;
            --surface2: #1e1e2e;
            --border:   rgba(0,51,102,0.25);
            --border2:  rgba(255,255,255,0.06);
            --txt:      #f0eef8;
            --txt2:     #8b9ab5;
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: var(--font);
            background: var(--bg);
            color: var(--txt);
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
        }

        body::before, body::after {
            content: '';
            position: fixed;
            border-radius: 50%;
            pointer-events: none;
            z-index: 0;
            filter: blur(80px);
            opacity: 0.4;
        }
        body::before {
            width: 400px; height: 400px;
            background: rgba(0,51,102,0.08);
            top: -120px; right: -100px;
        }
        body::after {
            width: 300px; height: 300px;
            background: rgba(26,82,118,0.05);
            bottom: -80px; left: -60px;
        }

        /* Layout - IGUAL QUE BIBLIOTECA */
        .main-content {
            margin-left: 280px;
            padding: 32px 28px 48px;
            min-height: 100vh;
            position: relative;
            z-index: 1;
        }

        @media (max-width: 900px) {
            .main-content { margin-left: 0; padding: 24px 20px 40px; }
        }

        /* Header - IGUAL QUE BIBLIOTECA */
        .dash-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 28px;
            gap: 16px;
            flex-wrap: wrap;
        }
        .dash-eyebrow {
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: var(--primary);
            background: rgba(0,51,102,0.10);
            border: 1px solid rgba(0,51,102,0.20);
            padding: 5px 12px;
            border-radius: 20px;
            display: inline-block;
            margin-bottom: 8px;
        }
        .dash-title {
            font-size: 28px;
            font-weight: 800;
            color: var(--txt);
            line-height: 1.2;
            letter-spacing: -0.02em;
        }
        .dash-title span {
            background: linear-gradient(135deg, var(--primary), var(--primary2));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .dash-sub { font-size: 13px; color: var(--txt2); margin-top: 4px; font-weight: 500; }
        .header-right { display: flex; gap: 10px; align-items: center; }
        .btn-icon {
            width: 42px; height: 42px;
            border-radius: 12px;
            background: var(--surface);
            border: 1px solid var(--border2);
            color: var(--txt2);
            display: flex; align-items: center; justify-content: center;
            cursor: pointer;
            font-size: 15px;
            transition: all 0.25s ease;
            box-shadow: var(--sh-card);
            text-decoration: none;
        }
        .btn-icon:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
            box-shadow: 0 6px 18px rgba(0,51,102,0.35);
            transform: scale(1.05);
        }
        .btn-icon.spin:hover { transform: scale(1.05) rotate(180deg); }

        /* Stats Cards - IGUAL QUE BIBLIOTECA */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }

        .kcard {
            background: var(--surface);
            border-radius: var(--r);
            padding: 20px;
            border: 1px solid var(--border2);
            box-shadow: var(--sh-card);
            position: relative;
            overflow: hidden;
            transition: all 0.25s ease;
        }
        .kcard:hover {
            box-shadow: var(--sh-hover);
            border-color: rgba(0,51,102,0.2);
            transform: translateY(-3px);
        }
        .kcard-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 14px;
        }
        .kcard-icon {
            width: 42px; height: 42px;
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 17px;
            background: rgba(0,51,102,0.10);
            color: var(--primary);
        }
        .kcard-num {
            font-size: 32px;
            font-weight: 800;
            color: var(--txt);
            line-height: 1;
            letter-spacing: -0.03em;
            margin-bottom: 4px;
        }
        .kcard-lbl { font-size: 13px; color: var(--txt2); font-weight: 500; }

        /* Alertas Row */
        .alertas-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-bottom: 24px;
        }
        .alerta-card {
            background: var(--surface);
            border-radius: var(--r);
            padding: 18px 20px;
            border: 1px solid var(--border2);
            box-shadow: var(--sh-card);
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
            transition: all 0.25s;
        }
        .alerta-card:hover { box-shadow: var(--sh-hover); transform: translateY(-2px); }
        .alerta-icon {
            width: 48px; height: 48px;
            border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px;
        }
        .alerta-content h4 { font-size: 14px; font-weight: 700; color: var(--txt); margin: 0 0 4px; }
        .alerta-content p { font-size: 13px; color: var(--txt2); margin: 0; }
        .alerta-num { font-size: 28px; font-weight: 800; margin-left: auto; }

        /* Bottom Grid - IGUAL QUE BIBLIOTECA (3 columnas) */
        .bottom-grid {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 16px;
            margin-bottom: 24px;
        }
        .panel {
            background: var(--surface);
            border-radius: var(--r-lg);
            padding: 22px;
            border: 1px solid var(--border2);
            box-shadow: var(--sh-card);
        }
        .panel-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .panel-title { font-size: 15px; font-weight: 700; color: var(--txt); }
        .panel-chip {
            font-size: 10px; font-weight: 700;
            color: var(--primary);
            background: rgba(0,51,102,0.10);
            padding: 4px 10px; border-radius: 20px;
        }

        /* Actividad - IGUAL QUE BIBLIOTECA */
        .act-item {
            display: flex; align-items: center; gap: 12px;
            padding: 12px;
            border-radius: 12px;
            background: var(--surface2);
            margin-bottom: 8px;
        }
        .act-av {
            width: 36px; height: 36px;
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            background: rgba(0,51,102,0.12);
            color: var(--primary);
        }
        .act-info { flex: 1; }
        .act-nm { font-size: 13px; font-weight: 600; color: var(--txt); }
        .act-sub { font-size: 11px; color: var(--txt2); margin-top: 2px; }

        /* Tabla - IGUAL QUE BIBLIOTECA */
        .table-mini { width: 100%; font-size: 12px; }
        .table-mini td { padding: 8px 0; border-bottom: 1px solid var(--border2); }

        /* Calendario - IGUAL QUE BIBLIOTECA (Panel 3) */
        .cal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
        }
        .cal-month { font-size: 15px; font-weight: 700; color: var(--txt); }
        .cal-nav { display: flex; gap: 6px; }
        .cal-btn {
            width: 30px; height: 30px;
            border-radius: 8px;
            background: var(--surface2);
            border: 1px solid var(--border2);
            color: var(--txt2);
            cursor: pointer;
            transition: all 0.2s;
        }
        .cal-btn:hover { background: var(--primary); color: white; }
        .cal-weekdays {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 4px;
            margin-bottom: 4px;
        }
        .cal-dow {
            text-align: center;
            font-size: 11px;
            font-weight: 700;
            color: var(--txt2);
            padding: 6px 0;
        }
        .calendar-days {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .calendar-week {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 4px;
        }
        .calendar-day {
            aspect-ratio: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size: 13px;
            font-weight: 500;
            border-radius: 10px;
            cursor: pointer;
            background: var(--surface);
            border: 1px solid var(--border2);
            color: var(--txt2);
        }
        .calendar-day:hover { background: rgba(0,51,102,0.1); }
        .calendar-day.today { background: var(--primary); color: white; font-weight: 700; }
        .calendar-day.empty { background: transparent; border: 1px dashed var(--border2); cursor: default; }
        .event-dots { display: flex; gap: 2px; justify-content: center; margin-top: 4px; }
        .event-dot { width: 6px; height: 6px; border-radius: 50%; }
        .event-dot.red { background: #dc2626; }
        .event-dot.orange { background: #f97316; }
        .event-dot.blue { background: #3b82f6; }
        .event-dot.green { background: #10b981; }
        .event-dot.yellow { background: #eab308; }

        /* Identidad Votante */
        .identidad-card {
            background: linear-gradient(135deg, var(--primary), var(--primary2));
            border-radius: var(--r);
            padding: 24px;
            color: white;
            margin-bottom: 20px;
        }
        .identidad-row { display: flex; margin-bottom: 8px; }
        .identidad-label { width: 100px; font-size: 12px; opacity: 0.7; }
        .identidad-value { font-size: 14px; font-weight: 600; }
        .alerta-mesa {
            background: rgba(245,158,11,0.2);
            padding: 12px;
            border-radius: 10px;
            margin-top: 12px;
            color: #fbbf24;
        }

        /* Alertas personales */
        .alerta-item {
            display: flex; gap: 12px; padding: 12px;
            background: var(--surface2);
            border-radius: 12px;
            margin-bottom: 10px;
        }

        /* Accesos directos - IGUAL QUE BIBLIOTECA */
        .accesos-directos {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-top: 24px;
        }
        .btn-acceso {
            display: flex; align-items: center; justify-content: center; gap: 10px;
            padding: 18px 20px;
            background: var(--surface);
            border-radius: var(--r);
            font-weight: 700;
            color: var(--txt);
            text-decoration: none;
            transition: all 0.25s;
            box-shadow: var(--sh-card);
        }
        .btn-acceso:hover { background: var(--primary); color: white; transform: translateY(-3px); }

        @media (max-width: 1200px) {
            .stats-row { grid-template-columns: repeat(2, 1fr); }
            .bottom-grid { grid-template-columns: 1fr 1fr; }
            .bottom-grid .panel:last-child { grid-column: 1 / -1; }
            .alertas-row { grid-template-columns: 1fr; }
            .accesos-directos { grid-template-columns: 1fr; }
        }
        @media (max-width: 768px) {
            .bottom-grid { grid-template-columns: 1fr; }
            .stats-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<%@ include file="/includes/navbar.jsp" %>

<main class="main-content">

    <!-- HEADER -->
    <div class="dash-header">
        <div>
            <div class="dash-eyebrow">
                <i class="fas fa-landmark"></i> 
                <%= esAdmin ? "Panel de Control · Administrador" : "Mi Panel · Votante" %>
            </div>
            <h1 class="dash-title">Hola, <span><%= usuario.getNombres() %></span> 👋</h1>
            <p class="dash-sub"><%= fechaHoy %></p>
        </div>
        <div class="header-right">
            <button class="btn-icon spin" onclick="toggleTheme()" title="Cambiar tema">
                <i class="fas fa-moon" id="themeIcon"></i>
            </button>
            <% if (esVotante) { %>
            <button class="btn-icon" onclick="window.print()" title="Imprimir"><i class="fas fa-print"></i></button>
            <% } %>
        </div>
    </div>

    <%-- ═══════════════════════════════════════════════════════════════════════ --%>
    <%-- VISTA ADMINISTRADOR --%>
    <%-- ═══════════════════════════════════════════════════════════════════════ --%>
    <% if (esAdmin) { %>

    <!-- 4 Contadores -->
    <div class="stats-row">
        <div class="kcard">
            <div class="kcard-top"><div class="kcard-icon"><i class="fas fa-users"></i></div></div>
            <div class="kcard-num"><%= totalCiudadanos %></div>
            <div class="kcard-lbl">Ciudadanos registrados</div>
        </div>
        <div class="kcard">
            <div class="kcard-top"><div class="kcard-icon" style="background:rgba(20,184,166,0.12);color:var(--teal);"><i class="fas fa-map-marker-alt"></i></div></div>
            <div class="kcard-num"><%= totalZonas %></div>
            <div class="kcard-lbl">Zonas activas</div>
        </div>
        <div class="kcard">
            <div class="kcard-top"><div class="kcard-icon" style="background:rgba(245,158,11,0.12);color:var(--amber);"><i class="fas fa-table"></i></div></div>
            <div class="kcard-num"><%= totalMesas %></div>
            <div class="kcard-lbl">Mesas habilitadas</div>
        </div>
        <div class="kcard">
            <div class="kcard-top"><div class="kcard-icon" style="background:rgba(16,185,129,0.12);color:var(--green);"><i class="fas fa-id-card"></i></div></div>
            <div class="kcard-num"><%= totalDocumentos %></div>
            <div class="kcard-lbl">Documentos expedidos</div>
        </div>
    </div>

    <!-- Alertas activas -->
    <div class="alertas-row">
        <a href="<%= request.getContextPath() %>/ciudadanos?sinMesa=true" class="alerta-card">
            <div class="alerta-icon" style="background:rgba(245,158,11,0.12);color:var(--amber);"><i class="fas fa-user-slash"></i></div>
            <div class="alerta-content"><h4>Ciudadanos sin mesa</h4><p>Requieren asignación urgente</p></div>
            <div class="alerta-num" style="color:var(--amber);"><%= ciudadanosSinMesa %></div>
        </a>
        <a href="<%= request.getContextPath() %>/documentos?porVencer=true" class="alerta-card">
            <div class="alerta-icon" style="background:rgba(220,38,38,0.12);color:var(--red);"><i class="fas fa-clock"></i></div>
            <div class="alerta-content"><h4>Documentos por vencer (30d)</h4><p>Requieren renovación</p></div>
            <div class="alerta-num" style="color:var(--red);"><%= docsPorVencer30 %></div>
        </a>
    </div>

    <!-- Bottom Grid: Actividad + Docs por vencer + CALENDARIO -->
    <div class="bottom-grid">
        <!-- Panel 1: Actividad reciente -->
        <div class="panel">
            <div class="panel-head"><div class="panel-title">Actividad reciente</div><div class="panel-chip">Últimos 10</div></div>
            <div style="max-height:280px;overflow-y:auto;">
                <% for (Ciudadano c : ultimosCiudadanos) { %>
                <div class="act-item">
                    <div class="act-av"><i class="fas fa-user-plus"></i></div>
                    <div class="act-info">
                        <div class="act-nm"><%= c.getNombreCompleto() %></div>
                        <div class="act-sub">CC: <%= c.getNumeroDocumento() %> · <%= c.getVeredaBarrio() != null ? c.getVeredaBarrio() : "—" %></div>
                    </div>
                </div>
                <% } %>
                <% if (ultimosCiudadanos.isEmpty()) { %>
                <p style="color:var(--txt2);text-align:center;padding:20px;">Sin actividad reciente</p>
                <% } %>
            </div>
        </div>

        <!-- Panel 2: Documentos próximos a vencer -->
        <div class="panel">
            <div class="panel-head"><div class="panel-title">📋 Próximos a vencer (30 días)</div><div class="panel-chip"><%= docsProximosVencer.size() %> docs</div></div>
            <div style="max-height:280px;overflow-y:auto;">
                <table class="table-mini">
                    <% for (DocumentoExpedido d : docsProximosVencer) { 
                        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
                        String fechaVenc = d.getFechaVencimiento() != null ? sdf.format(d.getFechaVencimiento()) : "N/A";
                    %>
                    <tr>
                        <td><strong><%= d.getNombresCiudadano() %> <%= d.getApellidosCiudadano() %></strong><br><small><%= d.getTipoDocumento() %></small></td>
                        <td style="color:var(--orange);"><i class="fas fa-calendar"></i> <%= fechaVenc %></td>
                        <td><a href="<%= request.getContextPath() %>/documentos?action=editar&id=<%= d.getId() %>" style="color:var(--primary);"><i class="fas fa-edit"></i></a></td>
                    </tr>
                    <% } %>
                </table>
                <% if (docsProximosVencer.isEmpty()) { %>
                <p style="color:var(--txt2);text-align:center;padding:20px;">No hay documentos próximos a vencer</p>
                <% } %>
            </div>
        </div>

        <!-- Panel 3: CALENDARIO (IGUAL QUE BIBLIOTECA) -->
        <div class="panel">
            <div class="cal-header">
                <div class="cal-month" id="calMonthTitle"><%= nombresMes[mesActual] %> <%= anioActual %></div>
                <div class="cal-nav">
                    <button class="cal-btn" onclick="cambiarMes(-1)"><i class="fas fa-chevron-left"></i></button>
                    <button class="cal-btn" onclick="cambiarMes(1)"><i class="fas fa-chevron-right"></i></button>
                    <button class="cal-btn" onclick="irAHoy()"><i class="fas fa-calendar-day"></i></button>
                </div>
            </div>
            <div id="calendarContainer"></div>
            <div style="display:flex;gap:12px;margin-top:16px;font-size:11px;color:var(--txt2);flex-wrap:wrap;">
                <span><span class="event-dot red"></span> Vence hoy</span>
                <span><span class="event-dot orange"></span> Vence en 7d</span>
                <span><span class="event-dot blue"></span> Jornada electoral</span>
                <span><span class="event-dot green"></span> Nuevo registro</span>
            </div>
        </div>
    </div>

    <!-- Estadística rápida de mesas -->
    <div class="panel" style="margin-bottom:24px;">
        <div class="panel-head"><div class="panel-title">📊 Ocupación de Mesas</div><div class="panel-chip"><%= porcentajeOcupacion %>% ocupadas</div></div>
        <div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
                <span>Mesas con votantes</span>
                <span><strong><%= mesasOcupadas %> / <%= totalMesas %></strong></span>
            </div>
            <div style="height:8px;background:var(--surface2);border-radius:4px;overflow:hidden;margin-bottom:20px;">
                <div style="width:<%= porcentajeOcupacion %>%;height:100%;background:linear-gradient(90deg,var(--primary),var(--primary2));border-radius:4px;"></div>
            </div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
                <span>Mesas vacías</span>
                <span><strong><%= mesasVacias %> / <%= totalMesas %></strong></span>
            </div>
            <div style="height:8px;background:var(--surface2);border-radius:4px;overflow:hidden;">
                <div style="width:<%= 100 - porcentajeOcupacion %>%;height:100%;background:var(--txt2);border-radius:4px;"></div>
            </div>
        </div>
    </div>

    <!-- Accesos directos -->
    <div class="accesos-directos">
        <a href="<%= request.getContextPath() %>/ciudadanos?action=nuevo" class="btn-acceso"><i class="fas fa-user-plus"></i> Registrar ciudadano</a>
        <a href="<%= request.getContextPath() %>/documentos?action=nuevo" class="btn-acceso"><i class="fas fa-id-card"></i> Expedir documento</a>
        <a href="<%= request.getContextPath() %>/admin/mesas?action=nuevo" class="btn-acceso"><i class="fas fa-table"></i> Crear mesa</a>
    </div>

    <%-- ═══════════════════════════════════════════════════════════════════════ --%>
    <%-- VISTA VOTANTE --%>
    <%-- ═══════════════════════════════════════════════════════════════════════ --%>
    <% } else if (esVotante) { %>

    <!-- Tarjeta de identidad -->
    <div class="identidad-card">
        <h4 style="margin-bottom:16px;"><i class="fas fa-id-card"></i> Mi Información</h4>
        <div class="identidad-row"><span class="identidad-label">Nombre:</span><span class="identidad-value"><%= ciudadanoVotante.getNombreCompleto() %></span></div>
        <div class="identidad-row"><span class="identidad-label">Cédula:</span><span class="identidad-value"><%= ciudadanoVotante.getNumeroDocumento() %></span></div>
        <div class="identidad-row"><span class="identidad-label">Vereda/Barrio:</span><span class="identidad-value"><%= ciudadanoVotante.getVeredaBarrio() != null ? ciudadanoVotante.getVeredaBarrio() : "No registrado" %></span></div>
        <div class="identidad-row">
            <span class="identidad-label">Mesa:</span>
            <span class="identidad-value">
                <% if (ciudadanoVotante.getIdMesa() != null && ciudadanoVotante.getIdMesa() > 0) { %>
                    Mesa #<%= ciudadanoVotante.getNumeroMesa() %> - <%= ciudadanoVotante.getNombreZona() %>
                <% } else { %>
                    No asignada
                <% } %>
            </span>
        </div>
        <% if (ciudadanoVotante.getIdMesa() == null || ciudadanoVotante.getIdMesa() == 0) { %>
        <div class="alerta-mesa"><i class="fas fa-exclamation-triangle"></i> No tienes mesa asignada. Contacta a la Registraduría.</div>
        <% } %>
    </div>

    <!-- Alertas personales -->
    <div class="panel" style="margin-bottom:20px;">
        <div class="panel-head"><div class="panel-title"><i class="fas fa-bell"></i> Mis Alertas</div><div class="panel-chip">Importante</div></div>
        <% 
            int alertasMostradas = 0;
            for (DocumentoExpedido d : docsVotante) {
                if (alertasMostradas >= 3) break;
                if (d.getFechaVencimiento() != null) {
                    LocalDate fv = new java.sql.Date(d.getFechaVencimiento().getTime()).toLocalDate();
                    if (!fv.isBefore(hoy) && fv.isBefore(hoy.plusDays(60))) {
                        alertasMostradas++;
        %>
        <div class="alerta-item"><i class="fas fa-id-card"></i><div><strong><%= d.getTipoDocumento() %></strong> vence el <%= fv %><br><small>Estado: <%= d.getEstado() %></small></div></div>
        <%      }
                }
            }
            if (alertasMostradas < 3 && (ciudadanoVotante.getIdMesa() == null || ciudadanoVotante.getIdMesa() == 0)) {
                alertasMostradas++;
        %>
        <div class="alerta-item"><i class="fas fa-map-marker-alt"></i><div><strong>Sin mesa asignada</strong><br><small>Acércate a la Registraduría</small></div></div>
        <% } %>
        <% if (alertasMostradas < 3) { %>
        <div class="alerta-item"><i class="fas fa-calendar-check"></i><div><strong>Próximas elecciones</strong><br><small>29 mayo 2026 - Presidenciales</small></div></div>
        <% } %>
    </div>

    <!-- CALENDARIO VOTANTE (Panel completo) -->
    <div class="panel" style="margin-bottom:20px;">
        <div class="cal-header">
            <div class="cal-month" id="calMonthTitleVotante"><%= nombresMes[mesActual] %> <%= anioActual %></div>
            <div class="cal-nav">
                <button class="cal-btn" onclick="cambiarMesVotante(-1)"><i class="fas fa-chevron-left"></i></button>
                <button class="cal-btn" onclick="cambiarMesVotante(1)"><i class="fas fa-chevron-right"></i></button>
                <button class="cal-btn" onclick="irHoyVotante()"><i class="fas fa-calendar-day"></i></button>
            </div>
        </div>
        <div id="calendarContainerVotante"></div>
        <div style="display:flex;gap:12px;margin-top:16px;font-size:11px;color:var(--txt2);flex-wrap:wrap;">
            <span><span class="event-dot red"></span> Vencimiento documento</span>
            <span><span class="event-dot blue"></span> Elecciones</span>
            <span><span class="event-dot yellow"></span> Día cívico Nobsa</span>
        </div>
    </div>

    <!-- Botón imprimir -->
    <div style="text-align:center;margin-top:24px;">
        <button onclick="window.print()" style="padding:14px 32px;background:var(--primary);color:white;border:none;border-radius:12px;font-weight:700;cursor:pointer;">
            <i class="fas fa-print"></i> Imprimir mi información
        </button>
    </div>

    <% } %>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    (function () {
        const saved = localStorage.getItem('bsTheme') || 'light';
        document.documentElement.setAttribute('data-bs-theme', saved);
        document.getElementById('themeIcon').className = saved === 'light' ? 'fas fa-moon' : 'fas fa-sun';
    })();
    function toggleTheme() {
        const html = document.documentElement;
        const next = html.getAttribute('data-bs-theme') === 'light' ? 'dark' : 'light';
        html.setAttribute('data-bs-theme', next);
        document.getElementById('themeIcon').className = next === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        localStorage.setItem('bsTheme', next);
    }

    // CALENDARIO 
    
    let currentYear = <%out.print(anioActual);%>;
    let currentMonth = <%out.print(mesActual);%>;
    const nombresMesesCal = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    const nombresDiasCal = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];
    
    const eventosSimulados = {
        '2026-04-18': [{color:'red'},{color:'green'}],
        '2026-04-20': [{color:'orange'}],
        '2026-04-25': [{color:'blue'}],
        '2026-05-01': [{color:'green'},{color:'orange'}],
        '2026-05-29': [{color:'blue'}],
        '2026-04-22': [{color:'red'}],
        '2026-07-20': [{color:'yellow'}],
        '2026-08-07': [{color:'yellow'}]
    };
    
    function renderizarCalendario(containerId, esAdmin) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        const primerDia = new Date(currentYear, currentMonth - 1, 1);
        const diasEnMes = new Date(currentYear, currentMonth, 0).getDate();
        const inicioSem = primerDia.getDay();
        
        const hoy = new Date();
        const hoyStr = hoy.getFullYear() + '-' + String(hoy.getMonth() + 1).padStart(2,'0') + '-' + String(hoy.getDate()).padStart(2,'0');
        
        let html = '<div class="cal-weekdays">';
        for (let i = 0; i < 7; i++) html += '<div class="cal-dow">' + nombresDiasCal[i] + '</div>';
        html += '</div><div class="calendar-days">';
        
        let dia = 1, semana = 0;
        while (dia <= diasEnMes) {
            html += '<div class="calendar-week">';
            for (let i = 0; i < 7; i++) {
                if (semana === 0 && i < inicioSem) {
                    html += '<div class="calendar-day empty"></div>';
                } else if (dia <= diasEnMes) {
                    const fechaStr = currentYear + '-' + String(currentMonth).padStart(2,'0') + '-' + String(dia).padStart(2,'0');
                    const esHoy = (fechaStr === hoyStr);
                    const eventos = eventosSimulados[fechaStr] || [];
                    
                    let puntosHtml = '';
                    const coloresUnicos = [];
                    for (let j = 0; j < eventos.length; j++) {
                        const color = eventos[j].color;
                        if (coloresUnicos.indexOf(color) === -1) {
                            coloresUnicos.push(color);
                            puntosHtml += '<span class="event-dot ' + color + '"></span>';
                        }
                    }
                    
                    html += '<div class="calendar-day' + (esHoy ? ' today' : '') + '" onclick="alert(\'📅 ' + fechaStr + '\\nEventos: ' + eventos.length + '\')">';
                    html += '<span>' + dia + '</span>';
                    if (puntosHtml) html += '<div class="event-dots">' + puntosHtml + '</div>';
                    html += '</div>';
                    dia++;
                } else {
                    html += '<div class="calendar-day empty"></div>';
                }
            }
            html += '</div>';
            semana++;
        }
        html += '</div>';
        container.innerHTML = html;
    }
    
    function actualizarTitulo(esAdmin) {
        const titleId = esAdmin ? 'calMonthTitle' : 'calMonthTitleVotante';
        const titleEl = document.getElementById(titleId);
        if (titleEl) titleEl.textContent = nombresMesesCal[currentMonth - 1] + ' ' + currentYear;
    }
    
    function cambiarMes(delta) {
        let nm = currentMonth + delta, ny = currentYear;
        if (nm < 1) { nm = 12; ny--; }
        else if (nm > 12) { nm = 1; ny++; }
        currentMonth = nm; currentYear = ny;
        
        renderizarCalendario('calendarContainer', true);
        actualizarTitulo(true);
    }
    
    function irAHoy() {
        const hoy = new Date();
        currentYear = hoy.getFullYear();
        currentMonth = hoy.getMonth() + 1;
        renderizarCalendario('calendarContainer', true);
        actualizarTitulo(true);
    }
    
    function cambiarMesVotante(delta) {
        let nm = currentMonth + delta, ny = currentYear;
        if (nm < 1) { nm = 12; ny--; }
        else if (nm > 12) { nm = 1; ny++; }
        currentMonth = nm; currentYear = ny;
        
        renderizarCalendario('calendarContainerVotante', false);
        actualizarTitulo(false);
    }
    
    function irHoyVotante() {
        const hoy = new Date();
        currentYear = hoy.getFullYear();
        currentMonth = hoy.getMonth() + 1;
        renderizarCalendario('calendarContainerVotante', false);
        actualizarTitulo(false);
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        const isAdmin = <%out.print(esAdmin);%>;
        if (isAdmin) {
            renderizarCalendario('calendarContainer', true);
        } else {
            renderizarCalendario('calendarContainerVotante', false);
        }
    });
    
    window.cambiarMes = cambiarMes;
    window.irAHoy = irAHoy;
    window.cambiarMesVotante = cambiarMesVotante;
    window.irHoyVotante = irHoyVotante;
</script>
<script src="<%= request.getContextPath() %>/js/registraduria.js"></script>
</body>
</html>