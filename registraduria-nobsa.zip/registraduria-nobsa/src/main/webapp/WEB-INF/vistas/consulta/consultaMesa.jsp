<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="co.sena.cimm.adso.registraduria.model.Ciudadano" %>
<%
    Ciudadano resultado = (Ciudadano) request.getAttribute("resultado");
    Boolean tieneMesa = (Boolean) request.getAttribute("tieneMesa");
    Boolean busquedaRealizada = (Boolean) request.getAttribute("busquedaRealizada");
    String contextPath = request.getContextPath();
%>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultar Lugar de Votación | Registraduría Municipal de Nobsa</title>

    <!-- Google Fonts + Tailwind CDN + Font Awesome -->
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap"
        rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Inter', sans-serif;
            scroll-behavior: smooth;
        }

        .hero-gradient {
            background: linear-gradient(135deg, #0a2540 0%, #1a5a9c 50%, #0d2b45 100%);
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .animate-fadeInUp {
            animation: fadeInUp 0.6s ease-out forwards;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .result-card {
            animation: slideIn 0.5s ease-out forwards;
        }

        .info-item {
            transition: all 0.3s ease;
        }

        .info-item:hover {
            transform: translateX(4px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        @media print {
            header, footer, .hero-gradient, form, .btn-back-home, .no-print {
                display: none !important;
            }
            
            body {
                background: white;
                padding: 0;
            }
        }
    </style>
</head>

<body class="bg-gray-50 antialiased">

    <!-- =========================== NAVBAR =========================== -->
    <header class="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm no-print">
        <div class="bg-gradient-to-r from-blue-900 to-blue-700 text-white text-sm py-2">
            <div class="container mx-auto px-4 flex justify-between items-center">
                <div class="flex items-center gap-6">
                    <a href="tel:195" class="flex items-center gap-2 hover:text-blue-200 transition">
                        <i class="fas fa-phone-alt w-4 h-4"></i> <span>Línea 195</span>
                    </a>
                    <a href="mailto:info@registraduria.gov.co"
                        class="hidden md:flex items-center gap-2 hover:text-blue-200 transition">
                        <i class="fas fa-envelope w-4 h-4"></i> <span>info@registraduria.gov.co</span>
                    </a>
                </div>
                <div class="text-xs">Horario: Lunes a Viernes 8:00 AM - 5:00 PM</div>
            </div>
        </div>

        <nav class="container mx-auto px-4 py-3 flex items-center justify-between">
            <a href="<%= contextPath %>/" class="flex items-center gap-3 group">
                <div class="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center shadow-md group-hover:shadow-lg transition">
                    <span class="text-white font-bold text-sm">RN</span>
                </div>
                <div class="hidden md:block">
                    <h1 class="font-bold text-gray-900 text-sm leading-tight group-hover:text-blue-700 transition">
                        Registraduría Nacional</h1>
                    <p class="text-xs text-gray-500">Del Estado Civil</p>
                </div>
            </a>

            <div class="hidden lg:flex items-center gap-8">
                <a href="<%= contextPath %>/" class="text-gray-700 hover:text-blue-600 transition font-medium">Inicio</a>
                <a href="<%= contextPath %>/#servicios" class="text-gray-700 hover:text-blue-600 transition font-medium">Servicios</a>
                <a href="<%= contextPath %>/#consultas" class="text-blue-600 font-semibold">Consultas</a>
                <a href="<%= contextPath %>/#contacto" class="text-gray-700 hover:text-blue-600 transition font-medium">Contacto</a>
            </div>

            <div class="flex items-center gap-3">
                <a href="<%= contextPath %>/login" class="hidden md:flex items-center gap-2 px-5 py-2.5 bg-white border-2 border-blue-200 text-blue-700 font-semibold rounded-xl hover:border-blue-400 hover:bg-blue-50 transition">
                    <i class="fas fa-sign-in-alt w-4 h-4"></i><span>Iniciar Sesión</span>
                </a>
                <a href="<%= contextPath %>/registro-votante" class="hidden md:flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-blue-800 transition">
                    <i class="fas fa-user-plus w-4 h-4"></i><span>Registrarse</span>
                </a>
                <button id="mobileMenuButton" class="lg:hidden p-2.5 rounded-xl hover:bg-gray-100 transition">
                    <i class="fas fa-bars w-6 h-6 text-gray-700"></i>
                </button>
            </div>
        </nav>

        <div id="mobileMenu" class="lg:hidden hidden border-t border-gray-100 bg-white py-4 px-4 shadow-lg">
            <div class="flex flex-col gap-2">
                <a href="<%= contextPath %>/" class="block py-3 px-4 text-gray-700 hover:text-blue-600 rounded-lg">Inicio</a>
                <a href="<%= contextPath %>/#servicios" class="block py-3 px-4 text-gray-700 hover:text-blue-600 rounded-lg">Servicios</a>
                <a href="<%= contextPath %>/#consultas" class="block py-3 px-4 text-blue-600 font-semibold bg-blue-50 rounded-lg">Consultas</a>
                <a href="<%= contextPath %>/#contacto" class="block py-3 px-4 text-gray-700 hover:text-blue-600 rounded-lg">Contacto</a>
                <hr class="my-3 border-gray-200">
                <a href="<%= contextPath %>/login" class="flex items-center justify-center gap-2 py-3 px-4 bg-white border-2 border-blue-200 text-blue-700 font-semibold rounded-xl">Iniciar Sesión</a>
                <a href="<%= contextPath %>/registro-votante" class="flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl">Registrarse</a>
            </div>
        </div>
    </header>


    <!-- =========================== HERO =========================== -->
    <section class="relative pt-32 pb-16 overflow-hidden hero-gradient no-print">
        <div class="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1597700331582-aab3614b3c0c?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center mix-blend-overlay opacity-20"></div>
        <div class="container mx-auto px-4 relative z-10">
            <div class="max-w-3xl mx-auto text-center animate-fadeInUp">
                <div class="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6 text-white text-sm">
                    <i class="fas fa-map-marker-alt w-4 h-4"></i> Consulta destacada
                </div>
                <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
                    Consulta tu<br><span class="bg-gradient-to-r from-blue-200 to-purple-200 bg-clip-text text-transparent">Puesto de Votación</span>
                </h1>
                <p class="text-xl text-blue-100 mb-8 leading-relaxed">
                    Encuentra de forma rápida y segura dónde debes ejercer tu derecho al voto
                </p>
            </div>
        </div>
        <div class="absolute bottom-0 left-0 right-0">
            <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-full">
                <path d="M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z" fill="#f9fafb" />
            </svg>
        </div>
    </section>

    <!-- =========================== FORMULARIO =========================== -->
    <section class="py-16 bg-gray-50 no-print">
        <div class="container mx-auto px-4">
            <div class="max-w-2xl mx-auto">
                <div class="glass-card rounded-2xl shadow-2xl overflow-hidden animate-fadeInUp">
                    <div class="bg-gradient-to-r from-blue-600 to-blue-700 p-8 text-white">
                        <div class="flex items-center justify-center w-16 h-16 bg-white/20 rounded-xl mb-4 mx-auto">
                            <i class="fas fa-search text-3xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold mb-2 text-center">Ingresa tu número de documento</h3>
                        <p class="text-blue-100 text-center">Consulta tu lugar de votación para las próximas elecciones</p>
                    </div>
                    <div class="p-8">
                        <form method="GET" action="<%= contextPath %>/consulta-mesa" class="mb-6">
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Número de cédula</label>
                                <input type="text" name="documento" placeholder="Ej: 1234567890"
                                    class="w-full px-4 py-4 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition text-lg"
                                    maxlength="10" required>
                            </div>
                            <div class="mb-4 flex justify-center">
                                <div class="g-recaptcha" data-sitekey="6LdK8cAsAAAAA GNFNXQ7MLVY7cVLQ05fGHYPSCko"></div>
                            </div>
                            <button type="submit"
                                class="w-full px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl font-semibold hover:from-blue-700 hover:to-blue-800 shadow-lg hover:shadow-xl transition flex items-center justify-center gap-2 group">
                                <i class="fas fa-search group-hover:scale-110 transition-transform"></i>
                                Consultar Ahora
                            </button>
                        </form>
                        <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 flex gap-3">
                            <i class="fas fa-info-circle text-blue-600 text-xl mt-0.5"></i>
                            <div class="text-sm text-blue-900">
                                <strong>Importante:</strong> Asegúrate de que tu documento esté vigente y actualizado en nuestro sistema.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- =========================== RESULTADO =========================== -->
    <% if (busquedaRealizada != null && busquedaRealizada) { %>
        <section class="py-16 bg-white">
            <div class="container mx-auto px-4">

                <% if (request.getAttribute("error") != null) { %>
                    <div class="max-w-2xl mx-auto result-card no-print">
                        <div class="bg-red-50 border-l-4 border-red-500 rounded-xl p-6 flex items-start gap-4">
                            <div class="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center flex-shrink-0">
                                <i class="fas fa-exclamation-circle text-red-600 text-xl"></i>
                            </div>
                            <div>
                                <h3 class="font-bold text-red-900 text-lg mb-1">Error en la consulta</h3>
                                <p class="text-red-700"><%= request.getAttribute("error") %></p>
                            </div>
                        </div>
                    </div>
                <% } else if (tieneMesa != null && !tieneMesa && resultado == null) { %>
                    <div class="max-w-2xl mx-auto result-card no-print">
                        <div class="bg-yellow-50 border-l-4 border-yellow-500 rounded-xl p-6 flex items-start gap-4">
                            <div class="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center flex-shrink-0">
                                <i class="fas fa-info-circle text-yellow-600 text-xl"></i>
                            </div>
                            <div>
                                <h3 class="font-bold text-yellow-900 text-lg mb-1">Información Importante</h3>
                                <p class="text-yellow-700"><%= request.getAttribute("mensaje") %></p>
                            </div>
                        </div>
                    </div>
                <% } else if (resultado != null && tieneMesa) { %>
                    <div class="max-w-4xl mx-auto result-card">
                        <div class="glass-card rounded-2xl shadow-2xl overflow-hidden" id="resultadoContainer">
                            <div class="bg-gradient-to-r from-green-600 to-green-700 p-8 text-white">
                                <div class="flex items-center justify-center w-20 h-20 bg-white/20 rounded-2xl mb-4 mx-auto">
                                    <i class="fas fa-check-circle text-4xl"></i>
                                </div>
                                <h3 class="text-2xl font-bold mb-2 text-center">¡Ciudadano Habilitado!</h3>
                                <p class="text-green-100 text-center">Tienes mesa de votación asignada para las próximas elecciones</p>
                            </div>

                            <div class="p-8">
                                <div class="mb-8 pb-6 border-b border-gray-200">
                                    <div class="flex items-center gap-4 mb-4">
                                        <div class="w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl flex items-center justify-center text-white text-2xl font-bold">
                                            <%= resultado.getNombres() != null && resultado.getNombres().length() > 0 ? resultado.getNombres().charAt(0) : 'C' %>
                                        </div>
                                        <div>
                                            <h4 class="text-2xl font-bold text-gray-900"><%= resultado.getNombreCompleto() %></h4>
                                            <p class="text-gray-600"><i class="fas fa-id-card mr-2"></i>C.C. <%= resultado.getNumeroDocumento() %></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="grid md:grid-cols-2 gap-6">
                                    <div class="info-item bg-gray-50 rounded-xl p-6 border-l-4 border-blue-600">
                                        <div class="text-sm text-gray-500 uppercase tracking-wide mb-2 font-semibold">
                                            <i class="fas fa-city mr-2"></i>Municipio / Departamento
                                        </div>
                                        <div class="text-2xl font-bold text-blue-900">
                                            <%= resultado.getNombreCiudad() != null ? resultado.getNombreCiudad() : "No disponible" %>
                                        </div>
                                        <% if (resultado.getDepartamento() != null) { %>
                                            <div class="text-lg text-blue-700 mt-1"><%= resultado.getDepartamento() %></div>
                                        <% } %>
                                    </div>

                                    <div class="info-item bg-gray-50 rounded-xl p-6 border-l-4 border-blue-600">
                                        <div class="text-sm text-gray-500 uppercase tracking-wide mb-2 font-semibold">
                                            <i class="fas fa-map-marked-alt mr-2"></i>Zona de Votación
                                        </div>
                                        <div class="text-2xl font-bold text-blue-900">
                                            <%= resultado.getNombreZona() != null ? resultado.getNombreZona() : "No asignada" %>
                                        </div>
                                    </div>

                                    <div class="info-item bg-gray-50 rounded-xl p-6 border-l-4 border-blue-600">
                                        <div class="text-sm text-gray-500 uppercase tracking-wide mb-2 font-semibold">
                                            <i class="fas fa-building mr-2"></i>Puesto de Votación
                                        </div>
                                        <div class="text-2xl font-bold text-blue-900">
                                            <%= resultado.getPuestoVotacion() != null ? resultado.getPuestoVotacion() : "No asignado" %>
                                        </div>
                                    </div>

                                    <div class="info-item bg-gray-50 rounded-xl p-6 border-l-4 border-blue-600">
                                        <div class="text-sm text-gray-500 uppercase tracking-wide mb-2 font-semibold">
                                            <i class="fas fa-road mr-2"></i>Dirección
                                        </div>
                                        <div class="text-xl font-bold text-blue-900">
                                            <%= resultado.getDireccionZona() != null ? resultado.getDireccionZona() : "No disponible" %>
                                        </div>
                                    </div>

                                    <div class="info-item bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-6 border-l-4 border-blue-600 md:col-span-2">
                                        <div class="text-sm text-blue-700 uppercase tracking-wide mb-2 font-semibold">
                                            <i class="fas fa-table mr-2"></i>Mesa de Votación Asignada
                                        </div>
                                        <div class="text-4xl font-bold text-blue-900">
                                            Mesa N° <%= resultado.getNumeroMesa() > 0 ? resultado.getNumeroMesa() : "No asignada" %>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-8 flex flex-wrap gap-4 justify-center no-print">
                                    <button onclick="imprimirResultadoOficial()"
                                        class="px-8 py-4 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition flex items-center gap-2">
                                        <i class="fas fa-print"></i> Imprimir Certificado
                                    </button>
                                    <a href="<%= contextPath %>/"
                                        class="px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl font-semibold transition flex items-center gap-2 shadow-lg hover:shadow-xl">
                                        <i class="fas fa-home"></i> Volver a Inicio
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <% } %>
            </div>
        </section>
    <% } %>

    <!-- =========================== FOOTER =========================== -->
    <footer class="bg-gradient-to-br from-gray-900 to-gray-800 text-white pt-16 pb-8 no-print">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
                <div class="lg:col-span-2">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center shadow-lg">
                            <span class="text-white font-bold text-xl">RN</span>
                        </div>
                        <div>
                            <h3 class="font-bold text-xl">Registraduría Nacional</h3>
                            <p class="text-sm text-gray-400">Del Estado Civil</p>
                        </div>
                    </div>
                    <p class="text-gray-400 mb-6 leading-relaxed max-w-md">
                        Garantizamos la identidad de los colombianos y facilitamos el ejercicio de sus derechos políticos y civiles.
                    </p>
                    <div class="space-y-3">
                        <a href="tel:195" class="flex items-center gap-3 text-gray-300 hover:text-blue-400 transition">
                            <i class="fas fa-phone-alt"></i><span>Línea gratuita: 195</span>
                        </a>
                        <a href="mailto:info@registraduria.gov.co" class="flex items-center gap-3 text-gray-300 hover:text-blue-400 transition">
                            <i class="fas fa-envelope"></i><span>info@registraduria.gov.co</span>
                        </a>
                    </div>
                </div>
                <div>
                    <h4 class="font-bold text-lg mb-4">Enlaces Rápidos</h4>
                    <ul class="space-y-3">
                        <li><a href="<%= contextPath %>/" class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Inicio</a></li>
                        <li><a href="<%= contextPath %>/#servicios" class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Servicios</a></li>
                        <li><a href="<%= contextPath %>/#consultas" class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Consultas</a></li>
                        <li><a href="<%= contextPath %>/#contacto" class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Contacto</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold text-lg mb-4">Legal</h4>
                    <ul class="space-y-3">
                        <li><a href="#" class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Política de privacidad</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Términos y condiciones</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Tratamiento de datos</a></li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-700 pt-8 text-center text-sm text-gray-400">
                <p>&copy; 2026 Registraduría Municipal de Nobsa - Boyacá. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script>
        // Mobile menu
        const mobileMenuButton = document.getElementById('mobileMenuButton');
        const mobileMenu = document.getElementById('mobileMenu');
        if (mobileMenuButton && mobileMenu) {
            mobileMenuButton.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));
        }

        // Smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) target.scrollIntoView({ behavior: 'smooth' });
            });
        });

        // ═══════════════════════════════════════════════════════════
        // IMPRESIÓN OFICIAL - REGISTRADURÍA NACIONAL
        // ═══════════════════════════════════════════════════════════
        function imprimirResultadoOficial() {
            const container = document.getElementById('resultadoContainer');
            if (!container) return;
            
            // Obtener datos del ciudadano
            const nombreCompleto = '<%= resultado != null ? resultado.getNombreCompleto().replace("'", "\\'") : "" %>';
            const numeroDocumento = '<%= resultado != null ? resultado.getNumeroDocumento() : "" %>';
            const nombreCiudad = '<%= resultado != null && resultado.getNombreCiudad() != null ? resultado.getNombreCiudad() : "No disponible" %>';
            const departamento = '<%= resultado != null && resultado.getDepartamento() != null ? resultado.getDepartamento() : "" %>';
            const nombreZona = '<%= resultado != null && resultado.getNombreZona() != null ? resultado.getNombreZona() : "No asignada" %>';
            const puestoVotacion = '<%= resultado != null && resultado.getPuestoVotacion() != null ? resultado.getPuestoVotacion() : "No asignado" %>';
            const direccion = '<%= resultado != null && resultado.getDireccionZona() != null ? resultado.getDireccionZona() : "No disponible" %>';
            const numeroMesa = '<%= resultado != null && resultado.getNumeroMesa() > 0 ? resultado.getNumeroMesa() : "No asignada" %>';
            const fechaActual = new Date().toLocaleDateString('es-CO', { year: 'numeric', month: 'long', day: 'numeric' });
            
            const printWindow = window.open('', '_blank', 'width=900,height=700');
            
            printWindow.document.write(`
                <!DOCTYPE html>
                <html lang="es">
                <head>
                    <meta charset="UTF-8">
                    <title>Certificado de Puesto de Votación - Registraduría Nacional</title>
                    <style>
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        
                        body {
                            font-family: 'Times New Roman', Times, serif;
                            background: white;
                            padding: 50px 60px;
                            color: #1a1a1a;
                        }
                        
                        /* Escudo de Colombia */
                        .escudo-colombia {
                            text-align: center;
                            margin-bottom: 20px;
                        }
                        
                        .escudo-colombia svg {
                            width: 80px;
                            height: auto;
                        }
                        
                        /* Encabezado oficial */
                        .official-header {
                            text-align: center;
                            margin-bottom: 30px;
                            border-bottom: 2px solid #003366;
                            padding-bottom: 25px;
                        }
                        
                        .official-header .republica {
                            font-size: 14px;
                            font-weight: 400;
                            letter-spacing: 3px;
                            text-transform: uppercase;
                            color: #003366;
                            margin-bottom: 8px;
                        }
                        
                        .official-header h1 {
                            font-size: 28px;
                            font-weight: 700;
                            color: #003366;
                            text-transform: uppercase;
                            letter-spacing: 2px;
                            margin-bottom: 5px;
                            font-family: 'Times New Roman', Times, serif;
                        }
                        
                        .official-header h2 {
                            font-size: 16px;
                            font-weight: 400;
                            color: #1a5276;
                            margin-bottom: 5px;
                        }
                        
                        .official-header .nit {
                            font-size: 12px;
                            color: #666;
                            margin-top: 8px;
                        }
                        
                        /* Título del certificado */
                        .certificate-title {
                            text-align: center;
                            margin: 30px 0;
                        }
                        
                        .certificate-title h3 {
                            font-size: 22px;
                            font-weight: 700;
                            color: #003366;
                            text-transform: uppercase;
                            letter-spacing: 2px;
                            border: 2px solid #003366;
                            display: inline-block;
                            padding: 12px 40px;
                            background: #f8fafc;
                        }
                        
                        /* Datos del ciudadano */
                        .citizen-section {
                            margin: 30px 0;
                            padding: 25px;
                            background: #f8fafc;
                            border: 1px solid #cbd5e1;
                        }
                        
                        .citizen-name {
                            font-size: 22px;
                            font-weight: 700;
                            color: #003366;
                            margin-bottom: 8px;
                        }
                        
                        .citizen-doc {
                            font-size: 16px;
                            color: #475569;
                        }
                        
                        /* Tabla de información */
                        .info-table {
                            width: 100%;
                            border-collapse: collapse;
                            margin: 25px 0;
                        }
                        
                        .info-table tr {
                            border-bottom: 1px solid #e2e8f0;
                        }
                        
                        .info-table td {
                            padding: 15px 10px;
                            vertical-align: top;
                        }
                        
                        .info-table .label {
                            font-weight: 700;
                            color: #003366;
                            width: 200px;
                            font-size: 14px;
                            text-transform: uppercase;
                            letter-spacing: 0.5px;
                        }
                        
                        .info-table .value {
                            font-size: 16px;
                            color: #1e293b;
                            font-weight: 600;
                        }
                        
                        /* Mesa de votación destacada */
                        .mesa-destacada {
                            margin: 30px 0;
                            padding: 30px;
                            background: linear-gradient(135deg, #003366 0%, #1a5276 100%);
                            border-radius: 0;
                            text-align: center;
                            color: white;
                        }
                        
                        .mesa-destacada .label {
                            font-size: 14px;
                            font-weight: 400;
                            text-transform: uppercase;
                            letter-spacing: 3px;
                            margin-bottom: 15px;
                            opacity: 0.9;
                        }
                        
                        .mesa-destacada .numero-mesa {
                            font-size: 72px;
                            font-weight: 700;
                            line-height: 1;
                            margin-bottom: 10px;
                            font-family: 'Times New Roman', Times, serif;
                        }
                        
                        .mesa-destacada .suffix {
                            font-size: 18px;
                            opacity: 0.9;
                        }
                        
                        /* Firma y sello */
                        .firma-section {
                            margin-top: 40px;
                            display: flex;
                            justify-content: space-between;
                            align-items: flex-end;
                        }
                        
                        .firma-box {
                            text-align: center;
                            width: 250px;
                        }
                        
                        .firma-linea {
                            border-bottom: 1px solid #003366;
                            margin-bottom: 8px;
                            padding-bottom: 40px;
                        }
                        
                        .firma-nombre {
                            font-weight: 700;
                            color: #003366;
                            font-size: 14px;
                        }
                        
                        .firma-cargo {
                            font-size: 12px;
                            color: #64748b;
                        }
                        
                        .sello-box {
                            text-align: center;
                        }
                        
                        .sello-circulo {
                            width: 100px;
                            height: 100px;
                            border: 3px solid #003366;
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin-bottom: 10px;
                            color: #003366;
                            font-size: 12px;
                            text-transform: uppercase;
                            font-weight: 700;
                        }
                        
                        /* Footer oficial */
                        .official-footer {
                            margin-top: 40px;
                            padding-top: 20px;
                            border-top: 1px solid #cbd5e1;
                            text-align: center;
                            font-size: 11px;
                            color: #64748b;
                        }
                        
                        .codigo-verificacion {
                            margin-top: 15px;
                            font-family: monospace;
                            font-size: 12px;
                            background: #f1f5f9;
                            padding: 8px 15px;
                            display: inline-block;
                            border-radius: 4px;
                        }
                        
                        @media print {
                            body { padding: 40px; }
                            .no-print { display: none; }
                        }
                    </style>
                </head>
                <body>
                    <!-- Escudo de Colombia (SVG simplificado) -->
                    <div class="escudo-colombia">
                        <svg width="80" height="80" viewBox="0 0 100 100">
                            <rect x="10" y="10" width="80" height="80" rx="5" fill="none" stroke="#003366" stroke-width="2"/>
                            <rect x="20" y="20" width="60" height="20" fill="#FCD116"/>
                            <rect x="20" y="40" width="60" height="20" fill="#003366"/>
                            <rect x="20" y="60" width="60" height="20" fill="#CE1126"/>
                        </svg>
                    </div>
                    
                    <!-- Encabezado oficial -->
                    <div class="official-header">
                        <div class="republica">República de Colombia</div>
                        <h1>Registraduría Nacional del Estado Civil</h1>
                        <h2>Registraduría Municipal de Nobsa - Boyacá</h2>
                        <div class="nit">NIT: 899.999.001-1</div>
                    </div>
                    
                    <!-- Título del certificado -->
                    <div class="certificate-title">
                        <h3>Certificado de Inscripción Electoral</h3>
                    </div>
                    
                    <!-- Datos del ciudadano -->
                    <div class="citizen-section">
                        <div class="citizen-name">${nombreCompleto}</div>
                        <div class="citizen-doc">Cédula de Ciudadanía N° ${numeroDocumento}</div>
                    </div>
                    
                    <!-- Información de votación -->
                    <table class="info-table">
                        <tr>
                            <td class="label">Municipio</td>
                            <td class="value">${nombreCiudad}</td>
                        </tr>
                        <tr>
                            <td class="label">Departamento</td>
                            <td class="value">${departamento}</td>
                        </tr>
                        <tr>
                            <td class="label">Zona de Votación</td>
                            <td class="value">${nombreZona}</td>
                        </tr>
                        <tr>
                            <td class="label">Puesto de Votación</td>
                            <td class="value">${puestoVotacion}</td>
                        </tr>
                        <tr>
                            <td class="label">Dirección</td>
                            <td class="value">${direccion}</td>
                        </tr>
                    </table>
                    
                    <!-- Mesa de votación destacada -->
                    <div class="mesa-destacada">
                        <div class="label">Mesa de Votación Asignada</div>
                        <div class="numero-mesa">${numeroMesa}</div>
                        <div class="suffix">MESA DE VOTACIÓN</div>
                    </div>
                    
                    <!-- Firma y sello -->
                    <div class="firma-section">
                        <div class="firma-box">
                            <div class="firma-linea"></div>
                            <div class="firma-nombre">CARLOS ERNESTO PEDRAZA RONDÓN</div>
                            <div class="firma-cargo">Registrador Municipal de Nobsa</div>
                        </div>
                        <div class="sello-box">
                            <div class="sello-circulo">
                                SELLO<br>REGISTRADURÍA<br>NOBSA
                            </div>
                            <div class="firma-cargo">República de Colombia</div>
                        </div>
                    </div>
                    
                    <!-- Footer oficial -->
                    <div class="official-footer">
                        <p><strong>LA REGISTRADURÍA NACIONAL DEL ESTADO CIVIL</strong></p>
                        <p>CERTIFICA: Que el(la) señor(a) <strong>${nombreCompleto}</strong> identificado(a) con <strong>C.C. N° ${numeroDocumento}</strong></p>
                        <p>se encuentra inscrito(a) en el Censo Electoral y tiene asignado el puesto de votación arriba indicado.</p>
                        <p style="margin-top: 15px;">Fecha de expedición: ${fechaActual}</p>
                        <div class="codigo-verificacion">
                            Código de verificación: RN-${numeroDocumento.substring(0,4)}-${new Date().getFullYear()}-${Math.random().toString(36).substring(2,8).toUpperCase()}
                        </div>
                        <p style="margin-top: 20px; font-style: italic;">Este documento es válido para presentar el día de las elecciones junto con su documento de identidad vigente.</p>
                    </div>
                    
                    <script>
                        window.onload = function() {
                            window.print();
                            setTimeout(function() { window.close(); }, 500);
                        };
                    <\/script>
                </body>
                </html>
            `);
            
            printWindow.document.close();
        }
    </script>
    <script src="<%= request.getContextPath() %>/js/registraduria.js"></script>
</body>

</html>