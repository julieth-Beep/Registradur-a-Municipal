<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="co.sena.cimm.adso.registraduria.model.Usuario" %>
<%
    Usuario usuarioNav = (Usuario) session.getAttribute("usuario");
    boolean isAuthenticatedNav = (usuarioNav != null);
    boolean isAdminNav = isAuthenticatedNav && usuarioNav.isAdmin();
    boolean isVotanteNav = isAuthenticatedNav && usuarioNav.isVotante();
    String contextPath = request.getContextPath();
    String currentPage = request.getRequestURI();
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ═══════════════════════════════════════════════════════════
           NAVBAR UNIVERSAL - REGISTRADURÍA
           ═══════════════════════════════════════════════════════ */
        :root {
            --nav-bg: rgba(255, 255, 255, 0.95);
            --nav-border: rgba(0, 51, 102, 0.12);
            --nav-text: #18122b;
            --nav-text-secondary: #5a6a7a;
            --nav-hover: rgba(0, 51, 102, 0.08);
            --nav-active: #003366;
            --nav-shadow: 0 4px 20px rgba(0, 51, 102, 0.08);
        }

        [data-bs-theme="dark"] {
            --nav-bg: rgba(22, 22, 34, 0.95);
            --nav-border: rgba(0, 51, 102, 0.25);
            --nav-text: #f0eef8;
            --nav-text-secondary: #8b9ab5;
            --nav-hover: rgba(0, 51, 102, 0.15);
            --nav-active: #4d8fcc;
        }

        .sidebar-nav {
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            width: 260px;
            background: var(--nav-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-right: 1px solid var(--nav-border);
            box-shadow: var(--nav-shadow);
            z-index: 1000;
            transition: all 0.3s ease;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }

        .sidebar-nav::-webkit-scrollbar { width: 4px; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: rgba(0, 51, 102, 0.2); border-radius: 4px; }

        .nav-header {
            padding: 24px 20px 16px;
            border-bottom: 1px solid var(--nav-border);
            margin-bottom: 16px;
        }

        .nav-logo { display: flex; align-items: center; gap: 12px; }

        .nav-logo-icon {
            width: 48px; height: 48px;
            background: linear-gradient(135deg, #003366, #1a5276);
            border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            color: white; font-size: 1.3rem;
            box-shadow: 0 6px 16px rgba(0, 51, 102, 0.3);
        }

        .nav-logo-text { font-size: 1rem; font-weight: 800; color: var(--nav-text); line-height: 1.3; }
        .nav-logo-text span { display: block; font-size: 0.7rem; font-weight: 500; color: var(--nav-text-secondary); }

        .nav-user-profile {
            padding: 16px; margin: 8px 12px 16px;
            background: rgba(0, 51, 102, 0.06);
            border-radius: 16px; border: 1px solid var(--nav-border);
        }

        .nav-user-avatar {
            width: 52px; height: 52px;
            background: linear-gradient(135deg, #003366, #1a5276);
            border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 800; font-size: 1.1rem; margin-bottom: 12px;
        }

        .nav-user-name { font-size: 0.9rem; font-weight: 700; color: var(--nav-text); margin-bottom: 4px; }

        .nav-user-role {
            display: inline-flex; align-items: center; gap: 4px;
            padding: 3px 10px; background: rgba(0, 51, 102, 0.12);
            border-radius: 20px; font-size: 0.65rem; font-weight: 700;
            text-transform: uppercase; color: var(--nav-active);
        }

        .nav-section { padding: 8px 12px; }

        .nav-section-title {
            font-size: 0.65rem; font-weight: 800; text-transform: uppercase;
            letter-spacing: 0.1em; color: var(--nav-text-secondary);
            padding: 12px 8px 6px;
        }

        .nav-menu { list-style: none; padding: 0; margin: 0; }
        .nav-item { margin: 2px 0; }

        .nav-link {
            display: flex; align-items: center; gap: 12px;
            padding: 12px 16px; border-radius: 12px;
            color: var(--nav-text); text-decoration: none;
            font-size: 0.85rem; font-weight: 500;
            transition: all 0.25s ease;
        }

        .nav-link i { width: 22px; font-size: 1rem; color: var(--nav-text-secondary); }
        .nav-link:hover { background: var(--nav-hover); transform: translateX(4px); }
        .nav-link:hover i { color: var(--nav-active); }

        .nav-link.active {
            background: linear-gradient(90deg, rgba(0, 51, 102, 0.15), rgba(0, 51, 102, 0.05));
            color: var(--nav-active);
            border-left: 3px solid var(--nav-active);
        }
        .nav-link.active i { color: var(--nav-active); }

        .nav-footer {
            margin-top: auto; padding: 20px 12px 24px;
            border-top: 1px solid var(--nav-border);
        }

        .nav-link.logout:hover { background: rgba(220, 38, 38, 0.1); color: #dc2626; }
        .nav-link.logout:hover i { color: #dc2626; }

        .nav-toggle-btn {
            display: none; position: fixed; top: 16px; left: 16px; z-index: 1001;
            width: 48px; height: 48px; border-radius: 14px;
            background: var(--nav-bg); backdrop-filter: blur(20px);
            border: 1px solid var(--nav-border); box-shadow: var(--nav-shadow);
            color: var(--nav-text); font-size: 1.2rem; cursor: pointer;
        }

        .nav-overlay {
            display: none; position: fixed; inset: 0;
            background: rgba(0, 0, 0, 0.4); backdrop-filter: blur(4px);
            z-index: 999;
        }

        @media (max-width: 992px) {
            .sidebar-nav { transform: translateX(-100%); }
            .sidebar-nav.open { transform: translateX(0); }
            .nav-toggle-btn { display: flex; align-items: center; justify-content: center; }
            .nav-overlay { display: block; pointer-events: none; opacity: 0; transition: opacity 0.3s; }
            .nav-overlay.active { opacity: 1; pointer-events: auto; }
        }
    </style>
</head>
<body>
    <!-- Overlay para móvil -->
    <div class="nav-overlay" id="navOverlay"></div>
    
    <!-- Botón toggle móvil -->
    <button class="nav-toggle-btn" id="navToggleBtn">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar Navigation -->
    <nav class="sidebar-nav" id="sidebarNav">
        <!-- Header -->
        <div class="nav-header">
            <div class="nav-logo">
                <div class="nav-logo-icon">
                    <i class="fas fa-landmark"></i>
                </div>
                <div class="nav-logo-text">
                    Registraduría
                    <span>Municipal de Nobsa</span>
                </div>
            </div>
        </div>

        <% if (isAuthenticatedNav) { %>
        <!-- Perfil de usuario -->
        <div class="nav-user-profile">
            <div class="nav-user-avatar">
                <%= usuarioNav.getNombres() != null && usuarioNav.getNombres().length() > 0 ? usuarioNav.getNombres().charAt(0) : 'U' %>
                <%= usuarioNav.getApellidos() != null && usuarioNav.getApellidos().length() > 0 ? usuarioNav.getApellidos().charAt(0) : 'S' %>
            </div>
            <div class="nav-user-name">
                <%= usuarioNav.getNombres() %> <%= usuarioNav.getApellidos() %>
            </div>
            <span class="nav-user-role">
                <i class="fas fa-<%= isAdminNav ? "shield-alt" : "user" %>"></i>
                <%= usuarioNav.getTipoUsuario() %>
            </span>
        </div>
        <% } %>

        <!-- ============================================ -->
        <!-- MENÚ PARA ADMINISTRADOR -->
        <!-- ============================================ -->
        <% if (isAdminNav) { %>
        <div class="nav-section">
            <div class="nav-section-title">Principal</div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="<%= contextPath %>/dashboard" class="nav-link <%= currentPage.contains("/dashboard") ? "active" : "" %>">
                        <i class="fas fa-tachometer-alt"></i><span>Dashboard</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="nav-section">
            <div class="nav-section-title">Gestión de Datos</div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="<%= contextPath %>/ciudadanos" class="nav-link <%= currentPage.contains("/ciudadanos") ? "active" : "" %>">
                        <i class="fas fa-users"></i><span>Ciudadanos</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<%= contextPath %>/documentos" class="nav-link <%= currentPage.contains("/documentos") ? "active" : "" %>">
                        <i class="fas fa-id-card"></i><span>Documentos Expedidos</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="nav-section">
            <div class="nav-section-title">Infraestructura Electoral</div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="<%= contextPath %>/admin/ciudades" class="nav-link <%= currentPage.contains("/admin/ciudades") ? "active" : "" %>">
                        <i class="fas fa-city"></i><span>Ciudades</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<%= contextPath %>/admin/zonas" class="nav-link <%= currentPage.contains("/admin/zonas") ? "active" : "" %>">
                        <i class="fas fa-map-marker-alt"></i><span>Zonas de Votación</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<%= contextPath %>/admin/mesas" class="nav-link <%= currentPage.contains("/admin/mesas") ? "active" : "" %>">
                        <i class="fas fa-table"></i><span>Mesas de Votación</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="nav-section">
            <div class="nav-section-title">Seguridad</div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="<%= contextPath %>/admin/usuarios" class="nav-link <%= currentPage.contains("/admin/usuarios") ? "active" : "" %>">
                        <i class="fas fa-user-shield"></i><span>Usuarios del Sistema</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ============================================ -->
        <!-- MENÚ PARA VOTANTE -->
        <!-- ============================================ -->
        <% } else if (isVotanteNav) { %>
        <div class="nav-section">
            <div class="nav-section-title">Mi Cuenta</div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="<%= contextPath %>/dashboard" class="nav-link <%= currentPage.contains("/dashboard") ? "active" : "" %>">
                        <i class="fas fa-tachometer-alt"></i><span>Mi Panel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<%= contextPath %>/votante/documentos" class="nav-link <%= currentPage.contains("/votante/documentos") ? "active" : "" %>">
                        <i class="fas fa-id-card"></i><span>Mis Documentos</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<%= contextPath %>/consulta-mesa-interna" class="nav-link <%= currentPage.contains("/consulta-mesa") ? "active" : "" %>">
                        <i class="fas fa-search"></i><span>Consultar Mesa</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<%= contextPath %>/votante/perfil" class="nav-link <%= currentPage.contains("/votante/perfil") ? "active" : "" %>">
                        <i class="fas fa-user-circle"></i><span>Editar Perfil</span>
                    </a>
                </li>
            </ul>
        </div>
        <% } %>

        <!-- ============================================ -->
        <!-- MENÚ PARA VISITANTE (NO AUTENTICADO) -->
        <!-- ============================================ -->
        <% if (!isAuthenticatedNav) { %>
        <div class="nav-section">
            <div class="nav-section-title">Navegación</div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="<%= contextPath %>/" class="nav-link <%= currentPage.endsWith("/index.jsp") || currentPage.endsWith("/") ? "active" : "" %>">
                        <i class="fas fa-home"></i><span>Inicio</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<%= contextPath %>/consulta-mesa" class="nav-link">
                        <i class="fas fa-search"></i><span>Consultar Mesa</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<%= contextPath %>/login" class="nav-link">
                        <i class="fas fa-sign-in-alt"></i><span>Iniciar Sesión</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<%= contextPath %>/registro-votante" class="nav-link">
                        <i class="fas fa-user-plus"></i><span>Registrarse</span>
                    </a>
                </li>
            </ul>
        </div>
        <% } %>

        <!-- Footer - Cerrar Sesión -->
        <% if (isAuthenticatedNav) { %>
        <div class="nav-footer">
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="<%= contextPath %>/logout" class="nav-link logout">
                        <i class="fas fa-sign-out-alt"></i><span>Cerrar Sesión</span>
                    </a>
                </li>
            </ul>
            <div style="text-align: center; margin-top: 16px; font-size: 0.65rem; color: var(--nav-text-secondary); opacity: 0.6;">
                <i class="far fa-copyright"></i> 2026 Registraduría Nobsa
            </div>
        </div>
        <% } %>
    </nav>

    <script>
        const sidebar = document.getElementById('sidebarNav');
        const toggleBtn = document.getElementById('navToggleBtn');
        const overlay = document.getElementById('navOverlay');
        
        function openSidebar() {
            sidebar.classList.add('open');
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
        
        function closeSidebar() {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
        }
        
        if (toggleBtn) toggleBtn.addEventListener('click', openSidebar);
        if (overlay) overlay.addEventListener('click', closeSidebar);
        
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 992) closeSidebar();
            });
        });
        
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && sidebar.classList.contains('open')) closeSidebar();
        });
        
        window.addEventListener('resize', function() {
            if (window.innerWidth > 992) closeSidebar();
        });
    </script>
    
</body>
</html>