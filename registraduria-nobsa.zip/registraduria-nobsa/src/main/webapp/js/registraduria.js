(function () {
    'use strict';

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    function boot() {
        injectCSS();
        injectHTML();
        wire();
        setTimeout(function () {
            obtenerRol().then(function (rd) {
                actualizarBadgeRol(rd.rol);
                botMsg(msgBienvenida(rd.rol, rd.nombre), chipsIniciales(rd.rol));
            });
        }, 600);
    }

    /* ══════════════════════════════════════════════════════════════
       CSS — Glassmorphism azul institucional
    ══════════════════════════════════════════════════════════════ */
    function injectCSS() {
        if (document.getElementById('_rc_css')) return;
        var el = document.createElement('style');
        el.id = '_rc_css';
        el.textContent = [
            ':root{',
            '  --_rc-glass:rgba(255,255,255,.52);',
            '  --_rc-glass-strong:rgba(255,255,255,.78);',
            '  --_rc-glass-border:rgba(255,255,255,.35);',
            '  --_rc-accent:#1d4ed8;',
            '  --_rc-accent-end:#1e40af;',
            '  --_rc-ink:#0f172a;',
            '  --_rc-ink-soft:#64748b;',
            '  --_rc-radius:20px;',
            '  --_rc-blur:blur(28px);',
            '}',

            /* FAB */
            '#_rc_fab{',
            '  position:fixed;bottom:30px;right:30px;width:58px;height:58px;',
            '  border-radius:18px;border:none;cursor:pointer;z-index:8800;',
            '  background:linear-gradient(135deg,rgba(29,78,216,.88),rgba(30,64,175,.88));',
            '  backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);',
            '  box-shadow:0 8px 32px rgba(29,78,216,.35),0 0 0 1px rgba(255,255,255,.18) inset;',
            '  display:flex;align-items:center;justify-content:center;',
            '  transition:all .35s cubic-bezier(.22,1,.36,1);',
            '  animation:_rc_float 3s ease-in-out infinite;',
            '}',
            '@keyframes _rc_float{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}',
            '#_rc_fab:hover{transform:translateY(-2px) scale(1.06);box-shadow:0 14px 40px rgba(29,78,216,.45)}',
            '#_rc_fab.gone{transform:scale(0) rotate(45deg);opacity:0;pointer-events:none}',

            /* Badge */
            '#_rc_badge{',
            '  position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;padding:0 4px;',
            '  background:linear-gradient(135deg,#ef4444,#f43f5e);color:#fff;',
            '  border-radius:999px;font-size:10px;font-weight:700;border:2.5px solid #fff;',
            '  display:flex;align-items:center;justify-content:center;',
            '  font-family:"Inter",system-ui,sans-serif;box-shadow:0 2px 8px rgba(239,68,68,.45);',
            '  animation:_rc_badge_pulse 2.5s ease-in-out infinite;',
            '}',
            '@keyframes _rc_badge_pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.15)}}',

            /* Window */
            '#_rc_win{',
            '  position:fixed;bottom:100px;right:30px;width:400px;',
            '  max-width:calc(100vw - 32px);height:600px;max-height:calc(100vh - 130px);',
            '  border-radius:var(--_rc-radius);',
            '  background:var(--_rc-glass);',
            '  backdrop-filter:var(--_rc-blur);-webkit-backdrop-filter:var(--_rc-blur);',
            '  border:1px solid var(--_rc-glass-border);',
            '  box-shadow:0 32px 80px rgba(0,0,0,.14),0 0 0 1px rgba(255,255,255,.45) inset,0 1px 0 rgba(255,255,255,.6) inset;',
            '  z-index:8801;display:flex;flex-direction:column;overflow:hidden;',
            '  font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:13.5px;',
            '  opacity:0;transform:translateY(18px) scale(.96);pointer-events:none;',
            '  transition:opacity .38s cubic-bezier(.22,1,.36,1),transform .38s cubic-bezier(.22,1,.36,1);',
            '}',
            '#_rc_win.open{opacity:1;transform:translateY(0) scale(1);pointer-events:all}',

            /* Header */
            '#_rc_head{',
            '  background:linear-gradient(135deg,rgba(29,78,216,.94),rgba(30,64,175,.9));',
            '  backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);',
            '  padding:16px 18px;display:flex;align-items:center;gap:12px;flex-shrink:0;',
            '  position:relative;overflow:hidden;',
            '}',
            '#_rc_head::before{content:"";position:absolute;top:-40%;right:-20%;width:180px;height:180px;background:radial-gradient(circle,rgba(255,255,255,.1) 0%,transparent 70%);border-radius:50%;pointer-events:none;}',
            '#_rc_head_logo{width:40px;height:40px;background:rgba(255,255,255,.18);backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.22);border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:transform .25s;}',
            '#_rc_head_logo:hover{transform:rotate(-8deg) scale(1.06)}',
            '#_rc_head_text{flex:1;position:relative;z-index:1}',
            '#_rc_head_name{color:#fff;font-weight:700;font-size:15px;letter-spacing:-.2px;text-shadow:0 1px 2px rgba(0,0,0,.15);}',
            '#_rc_head_sub{color:rgba(255,255,255,.7);font-size:11.5px;display:flex;align-items:center;gap:6px;margin-top:1px;}',
            '#_rc_head_sub::before{content:"";width:7px;height:7px;background:#4ade80;border-radius:50%;box-shadow:0 0 8px rgba(74,222,128,.6);animation:_rc_dot_pulse 2s ease-in-out infinite;}',
            '@keyframes _rc_dot_pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.6;transform:scale(1.3)}}',

            /* Role badge */
            '#_rc_rol_badge{font-size:10.5px;font-weight:700;padding:4px 11px;border-radius:999px;margin-left:auto;white-space:nowrap;letter-spacing:.3px;position:relative;z-index:1;backdrop-filter:blur(6px);border:1px solid rgba(255,255,255,.2);}',
            '#_rc_rol_badge.admin{background:rgba(253,230,138,.88);color:#92400e}',
            '#_rc_rol_badge.votante{background:rgba(219,234,254,.88);color:#1e3a8a}',
            '#_rc_rol_badge.invitado{background:rgba(220,252,231,.88);color:#166534}',

            /* Header buttons */
            '#_rc_head_btns{display:flex;gap:6px;margin-left:6px;position:relative;z-index:1}',
            '._rc_hbtn{width:30px;height:30px;background:rgba(255,255,255,.12);backdrop-filter:blur(6px);border:1px solid rgba(255,255,255,.15);border-radius:9px;color:rgba(255,255,255,.78);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s;}',
            '._rc_hbtn:hover{background:rgba(255,255,255,.24);color:#fff;transform:scale(1.08)}',

            /* Feed */
            '#_rc_feed{flex:1;overflow-y:auto;padding:18px 16px;display:flex;flex-direction:column;gap:14px;background:linear-gradient(180deg,rgba(239,246,255,.45) 0%,rgba(248,250,255,.6) 100%);}',
            '#_rc_feed::-webkit-scrollbar{width:5px}',
            '#_rc_feed::-webkit-scrollbar-thumb{background:rgba(29,78,216,.18);border-radius:10px}',
            '#_rc_feed::-webkit-scrollbar-thumb:hover{background:rgba(29,78,216,.32)}',

            /* Rows */
            '._rc_row{display:flex;gap:9px;max-width:88%;animation:_rc_slideIn .35s cubic-bezier(.22,1,.36,1)}',
            '@keyframes _rc_slideIn{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}',
            '._rc_row.bot{align-self:flex-start}',
            '._rc_row.user{align-self:flex-end;flex-direction:row-reverse}',

            /* Avatars */
            '._rc_av{width:30px;height:30px;border-radius:10px;display:flex;align-items:center;justify-content:center;margin-top:4px;flex-shrink:0;box-shadow:0 2px 8px rgba(0,0,0,.08);}',
            '._rc_row.bot ._rc_av{background:linear-gradient(135deg,rgba(29,78,216,.15),rgba(30,64,175,.12))}',
            '._rc_row.user ._rc_av{background:linear-gradient(135deg,rgba(29,78,216,.1),rgba(30,64,175,.07))}',

            '._rc_col{display:flex;flex-direction:column;gap:4px;min-width:0}',

            /* Bubbles */
            '._rc_bub{padding:12px 16px;border-radius:18px;line-height:1.72;color:var(--_rc-ink);background:var(--_rc-glass-strong);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.55);box-shadow:0 4px 20px rgba(0,0,0,.04),0 1px 0 rgba(255,255,255,.7) inset;word-break:break-word;font-size:13.2px;}',
            '._rc_row.bot ._rc_bub{border-top-left-radius:6px}',
            '._rc_row.user ._rc_bub{background:linear-gradient(135deg,rgba(29,78,216,.88),rgba(30,64,175,.88));backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.18);color:#fff;border-top-right-radius:6px;box-shadow:0 6px 24px rgba(29,78,216,.22);}',

            /* Cards */
            '._rc_card{margin-top:10px;background:rgba(255,255,255,.5);backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,.5);border-radius:14px;padding:12px 14px;font-size:12.5px;box-shadow:0 2px 12px rgba(0,0,0,.04);}',
            '._rc_card_title{font-weight:800;background:linear-gradient(135deg,#1d4ed8,#1e40af);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;font-size:10.5px;text-transform:uppercase;letter-spacing:.6px;margin-bottom:8px;}',
            '._rc_card_row{display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid rgba(29,78,216,.07);font-size:12px}',
            '._rc_card_row:last-child{border-bottom:none}',
            '._rc_card_label{color:var(--_rc-ink-soft);font-weight:600}',
            '._rc_card_val{font-weight:700;color:var(--_rc-ink)}',
            '._rc_card_val.ok{color:#16a34a}._rc_card_val.warn{color:#d97706}._rc_card_val.err{color:#dc2626}',

            /* Timestamp */
            '._rc_ts{font-size:10px;color:#94a3b8;padding:0 4px;letter-spacing:.3px}',
            '._rc_row.user ._rc_ts{text-align:right}',

            /* Typing */
            '._rc_typing ._rc_bub{display:flex;align-items:center;gap:5px;padding:14px 18px}',
            '._rc_dot{width:6px;height:6px;background:rgba(29,78,216,.4);border-radius:50%;animation:_rc_dot_anim 1.4s ease-in-out infinite}',
            '._rc_dot:nth-child(2){animation-delay:.18s}._rc_dot:nth-child(3){animation-delay:.36s}',
            '@keyframes _rc_dot_anim{0%,55%,100%{transform:translateY(0);opacity:.4}27%{transform:translateY(-6px);opacity:1}}',

            /* Chips */
            '#_rc_chips{padding:10px 16px;display:flex;flex-wrap:wrap;gap:7px;background:rgba(255,255,255,.3);backdrop-filter:blur(12px);border-top:1px solid rgba(255,255,255,.35);min-height:50px;}',
            '._rc_chip{padding:6px 14px;background:rgba(29,78,216,.06);border:1px solid rgba(29,78,216,.12);color:#1d4ed8;border-radius:999px;font-size:11.5px;font-weight:600;cursor:pointer;transition:all .22s cubic-bezier(.22,1,.36,1);letter-spacing:.2px;}',
            '._rc_chip:hover{background:linear-gradient(135deg,rgba(29,78,216,.9),rgba(30,64,175,.9));color:#fff;transform:translateY(-2px);box-shadow:0 4px 16px rgba(29,78,216,.28);border-color:transparent;}',
            '._rc_chip:active{transform:translateY(0) scale(.97)}',

            /* Input bar */
            '#_rc_bar{display:flex;gap:10px;padding:14px 16px;background:rgba(255,255,255,.38);backdrop-filter:blur(16px);border-top:1px solid rgba(255,255,255,.3);}',
            '#_rc_inp{flex:1;padding:11px 16px;border:1.5px solid rgba(29,78,216,.12);border-radius:13px;font-size:13.5px;font-family:inherit;color:var(--_rc-ink);background:rgba(255,255,255,.55);backdrop-filter:blur(8px);outline:none;transition:all .25s;}',
            '#_rc_inp::placeholder{color:#94a3b8}',
            '#_rc_inp:focus{border-color:rgba(29,78,216,.4);box-shadow:0 0 0 4px rgba(29,78,216,.08),0 2px 12px rgba(29,78,216,.06);background:rgba(255,255,255,.85);}',
            '#_rc_send{width:42px;height:42px;background:linear-gradient(135deg,#1d4ed8,#1e40af);border:none;border-radius:12px;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(29,78,216,.3);transition:all .22s;}',
            '#_rc_send:hover{transform:scale(1.06);box-shadow:0 6px 24px rgba(29,78,216,.4)}',
            '#_rc_send:active{transform:scale(.95)}',

            /* Responsive */
            '@media(max-width:480px){#_rc_win{width:calc(100vw - 24px);right:12px;bottom:90px;height:calc(100vh - 110px)}#_rc_fab{right:16px;bottom:16px;width:54px;height:54px;}._rc_row{max-width:94%}}'
        ].join('');
        document.head.appendChild(el);
    }

    /* ══════════════════════════════════════════════════════════════
       HTML
    ══════════════════════════════════════════════════════════════ */
    function injectHTML() {
        if (document.getElementById('_rc_win')) return;
        var d = document.createElement('div');
        d.innerHTML =
            '<button id="_rc_fab">' +
              '<svg width="26" height="26" viewBox="0 0 24 24" fill="none">' +
                '<path d="M20 2H4C2.9 2 2 2.9 2 4v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z" fill="rgba(255,255,255,.9)"/>' +
                '<path d="M7 9h10M7 13h7" stroke="rgba(29,78,216,.6)" stroke-width="1.5" stroke-linecap="round"/>' +
              '</svg>' +
              '<span id="_rc_badge">1</span>' +
            '</button>' +
            '<div id="_rc_win">' +
              '<div id="_rc_head">' +
                '<div id="_rc_head_logo">' +
                  '<svg width="22" height="22" viewBox="0 0 24 24">' +
                    '<rect x="3" y="3" width="18" height="18" rx="3" fill="rgba(255,255,255,.9)"/>' +
                    '<path d="M7 8h10M7 12h8M7 16h5" stroke="rgba(29,78,216,.7)" stroke-width="1.5" stroke-linecap="round"/>' +
                  '</svg>' +
                '</div>' +
                '<div id="_rc_head_text">' +
                  '<div id="_rc_head_name">RegistraBot</div>' +
                  '<div id="_rc_head_sub">Asistente · Registraduría Nobsa</div>' +
                '</div>' +
                '<span id="_rc_rol_badge" class="invitado">🌐 Visitante</span>' +
                '<div id="_rc_head_btns">' +
                  '<button class="_rc_hbtn" id="_rc_clear" title="Limpiar chat">' +
                    '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M19 4h-3.5l-1-1h-5l-1 1H5v2h14V4zm-1 16H6l-1-9h14l-1 9z"/></svg>' +
                  '</button>' +
                  '<button class="_rc_hbtn" id="_rc_close" title="Cerrar">' +
                    '<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>' +
                  '</button>' +
                '</div>' +
              '</div>' +
              '<div id="_rc_feed"></div>' +
              '<div id="_rc_chips"></div>' +
              '<div id="_rc_bar">' +
                '<input id="_rc_inp" type="text" placeholder="Escribe tu pregunta..." autocomplete="off" maxlength="300">' +
                '<button id="_rc_send">' +
                  '<svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>' +
                '</button>' +
              '</div>' +
            '</div>';
        document.body.appendChild(d);
    }

    /* ══════════════════════════════════════════════════════════════
       EVENTOS
    ══════════════════════════════════════════════════════════════ */
    function wire() {
        document.getElementById('_rc_fab').onclick    = openChat;
        document.getElementById('_rc_close').onclick  = closeChat;
        document.getElementById('_rc_clear').onclick  = clearChat;
        document.getElementById('_rc_send').onclick   = send;
        document.getElementById('_rc_inp').onkeydown  = function (e) {
            if (e.key === 'Enter') { e.preventDefault(); send(); }
        };
        document.getElementById('_rc_chips').onclick = function (e) {
            if (e.target.classList.contains('_rc_chip')) {
                document.getElementById('_rc_inp').value = e.target.textContent;
                send();
            }
        };
    }

    function openChat() {
        document.getElementById('_rc_win').classList.add('open');
        document.getElementById('_rc_fab').classList.add('gone');
        document.getElementById('_rc_badge').style.display = 'none';
        document.getElementById('_rc_inp').focus();
    }

    function closeChat() {
        document.getElementById('_rc_win').classList.remove('open');
        document.getElementById('_rc_fab').classList.remove('gone');
    }

    function clearChat() {
        document.getElementById('_rc_feed').innerHTML = '';
        obtenerRol().then(function (rd) {
            actualizarBadgeRol(rd.rol);
            botMsg(msgBienvenida(rd.rol, rd.nombre), chipsIniciales(rd.rol));
        });
    }

    function send() {
        var inp  = document.getElementById('_rc_inp');
        var text = inp.value.trim();
        if (!text) return;
        userMsg(text);
        inp.value = '';
        showTyping();
        setTimeout(function () {
            hideTyping();
            answer(text).then(function (r) {
                botMsg(r.html, r.chips);
            });
        }, 350 + Math.random() * 250);
    }

    /* ══════════════════════════════════════════════════════════════
       UI HELPERS
    ══════════════════════════════════════════════════════════════ */
    function botMsg(html, chips) {
        addRow('bot', iconBot(), '<div class="_rc_bub">' + html + '</div>');
        if (chips && chips.length) setChips(chips);
        scroll();
    }

    function userMsg(text) {
        addRow('user', iconUser(), '<div class="_rc_bub">' + esc(text) + '</div>');
        scroll();
    }

    function addRow(type, avatar, content) {
        var feed = document.getElementById('_rc_feed');
        var d = document.createElement('div');
        d.className = '_rc_row ' + type;
        d.innerHTML =
            '<div class="_rc_av">' + avatar + '</div>' +
            '<div class="_rc_col">' + content +
              '<span class="_rc_ts">' + hora() + '</span>' +
            '</div>';
        feed.appendChild(d);
    }

    function showTyping() {
        var feed = document.getElementById('_rc_feed');
        var d = document.createElement('div');
        d.className = '_rc_row bot _rc_typing';
        d.id = '_rc_typing';
        d.innerHTML = '<div class="_rc_av">' + iconBot() + '</div>' +
            '<div class="_rc_col"><div class="_rc_bub">' +
            '<span class="_rc_dot"></span><span class="_rc_dot"></span><span class="_rc_dot"></span>' +
            '</div></div>';
        feed.appendChild(d);
        scroll();
    }

    function hideTyping() {
        var t = document.getElementById('_rc_typing');
        if (t) t.remove();
    }

    function setChips(list) {
        var box = document.getElementById('_rc_chips');
        box.innerHTML = list.map(function (c) {
            return '<button class="_rc_chip">' + esc(c) + '</button>';
        }).join('');
    }

    function card(titulo, filas) {
        var html = '<div class="_rc_card"><div class="_rc_card_title">' + esc(titulo) + '</div>';
        filas.forEach(function (f) {
            html += '<div class="_rc_card_row">' +
                '<span class="_rc_card_label">' + f.label + '</span>' +
                '<span class="_rc_card_val' + (f.cls ? ' ' + f.cls : '') + '">' + f.val + '</span>' +
                '</div>';
        });
        return html + '</div>';
    }

    function actualizarBadgeRol(rol) {
        var badge = document.getElementById('_rc_rol_badge');
        if (!badge) return;
        badge.className = '_rc_rol_badge ' + rol;
        if (rol === 'admin')        badge.textContent = '🔑 Admin';
        else if (rol === 'votante') badge.textContent = '🗳️ Votante';
        else                        badge.textContent = '🌐 Visitante';
    }

    function scroll() {
        var f = document.getElementById('_rc_feed');
        if (f) setTimeout(function () { f.scrollTop = f.scrollHeight; }, 50);
    }

    function hora() {
        return new Date().toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });
    }

    function esc(s) {
        if (!s) return '';
        var d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
    }

    function fmt(n) {
        return (n || 0).toLocaleString('es-CO');
    }

    function iconBot() {
        return '<svg width="15" height="15" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="3" fill="rgba(29,78,216,.12)" stroke="#1d4ed8" stroke-width="1.5"/><path d="M7 8h10M7 12h8M7 16h5" stroke="#1d4ed8" stroke-width="1.5" stroke-linecap="round"/></svg>';
    }

    function iconUser() {
        return '<svg width="14" height="14" viewBox="0 0 24 24" fill="#1d4ed8"><path d="M12 12c2.7 0 5-2.3 5-5S14.7 2 12 2 7 4.3 7 7s2.3 5 5 5zm0 2c-3.3 0-10 1.7-10 5v2h20v-2c0-3.3-6.7-5-10-5z"/></svg>';
    }

    /* ══════════════════════════════════════════════════════════════
       CONTEXTO Y ROL
    ══════════════════════════════════════════════════════════════ */
    function getCtx() {
    // Devuelve el contextPath de la aplicación
    var path = window.location.pathname;
    var ctx = path.substring(0, path.indexOf('/', 1));
    return ctx || '';
    }

    function obtenerRol() {
        return fetch(getCtx() + '/chatbot?accion=obtener_rol', { credentials: 'include' })
            .then(function (r) { return r.json(); })
            .catch(function () { return { rol: 'invitado', nombre: '' }; });
    }

    function fetchData(url) {
        return fetch(url, { credentials: 'include' })
            .then(function (r) { return r.json(); })
            .catch(function () { return { success: false, error: 'No se pudo conectar.' }; });
    }

    function errMsg(msg, chips) {
        return { html: '⚠️ ' + esc(msg || 'Error al obtener datos.'), chips: chips || [] };
    }

    /* ══════════════════════════════════════════════════════════════
       MENSAJES Y CHIPS SEGÚN ROL
    ══════════════════════════════════════════════════════════════ */
    function msgBienvenida(rol, nombre) {
        if (rol === 'admin')
            return '¡Bienvenido, <b>' + esc(nombre) + '</b>! 👋 Soy <b>RegistraBot</b>, tu asistente de la Registraduría Municipal de Nobsa. Puedo ayudarte con estadísticas, ciudadanos, mesas de votación, zonas y más.';
        if (rol === 'votante')
            return '¡Hola, <b>' + esc(nombre) + '</b>! 🗳️ Soy <b>RegistraBot</b>. ¿Deseas saber dónde votar, cómo registrarte o tienes preguntas sobre el proceso electoral?';
        return '👋 Bienvenido a la <b>Registraduría Municipal de Nobsa</b>. Soy <b>RegistraBot</b>, tu asistente virtual. Puedo ayudarte a encontrar tu puesto de votación o resolver tus dudas electorales.';
    }

    function chipsIniciales(rol) {
        if (rol === 'admin')
            return ['Estadísticas generales', 'Ciudadanos sin mesa', 'Resumen de mesas', 'Cómo agregar ciudadano', 'Gestionar zonas'];
        if (rol === 'votante')
            return ['Consultar mi mesa', 'Dónde votar', 'Documentos necesarios', 'Horario de votación'];
        return ['Consultar puesto de votación', 'Cómo registrarse', 'Qué documentos necesito', 'Horarios de atención', 'Qué es la Registraduría'];
    }

    /* ══════════════════════════════════════════════════════════════
       NORMALIZACIÓN
    ══════════════════════════════════════════════════════════════ */
    function norm(s) {
        return (s || '').toLowerCase()
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
            .replace(/[¿?¡!.,;:()]/g, '');
    }

    function tiene(q, palabras) {
        return palabras.some(function (p) { return q.indexOf(p) !== -1; });
    }

    /* ══════════════════════════════════════════════════════════════
       MOTOR PRINCIPAL DE RESPUESTAS
    ══════════════════════════════════════════════════════════════ */
    function answer(text) {
        return obtenerRol().then(function (rd) {
            actualizarBadgeRol(rd.rol);
            var rol    = rd.rol;
            var nombre = rd.nombre;
            var q      = norm(text);
            var ctx    = getCtx();

            /* ── RESPUESTAS GLOBALES ──────────────────────────────── */

            if (tiene(q, ['hola', 'buenos dias', 'buenas tardes', 'buenas noches', 'hey', 'saludos', 'buenas'])) {
                return Promise.resolve({ html: msgBienvenida(rol, nombre), chips: chipsIniciales(rol) });
            }

            if (tiene(q, ['adios', 'chao', 'bye', 'hasta luego', 'hasta pronto', 'nos vemos'])) {
                return Promise.resolve({ html: '👋 ¡Hasta luego' + (nombre ? ', <b>' + esc(nombre) + '</b>' : '') + '! Recuerda que puedes consultar tu puesto de votación en cualquier momento.', chips: [] });
            }

            if (tiene(q, ['gracias', 'muchas gracias', 'perfecto', 'excelente', 'listo', 'ok gracias'])) {
                return Promise.resolve({ html: '😊 ¡Con gusto! Si tienes más preguntas sobre el proceso electoral, aquí estoy.', chips: chipsIniciales(rol) });
            }

            if (tiene(q, ['que es la registraduria', 'para que sirve', 'sobre la registraduria', 'registraduria nobsa', 'registraduria'])) {
                return Promise.resolve({
                    html: '🏛️ La <b>Registraduría Municipal de Nobsa</b> es la entidad encargada de:<br><br>'
                        + '🗳️ Organizar y apoyar los procesos electorales en el municipio<br>'
                        + '🪪 Registro civil e identificación de ciudadanos<br>'
                        + '📋 Inscripción y actualización del censo electoral<br>'
                        + '🗺️ Asignación de puestos y mesas de votación<br><br>'
                        + '📍 Ubicada en el municipio de <b>Nobsa, Boyacá</b>.',
                    chips: chipsIniciales(rol)
                });
            }

            if (tiene(q, ['quien eres', 'que eres', 'como te llamas', 'eres un bot', 'eres ia'])) {
                return Promise.resolve({
                    html: '🤖 Soy <b>RegistraBot</b>, el asistente virtual de la Registraduría Municipal de Nobsa. Puedo ayudarte a:<br><br>'
                        + '🔍 Consultar tu puesto de votación<br>'
                        + '📋 Información sobre el proceso electoral<br>'
                        + '🪪 Requisitos para votar y cédula de ciudadanía<br>'
                        + (rol === 'admin' ? '📊 Estadísticas del sistema' : ''),
                    chips: chipsIniciales(rol)
                });
            }

            /* ── CONSULTA DE MESA / PUESTO DE VOTACIÓN ───────────── */

            if (tiene(q, ['consultar mesa', 'consultar puesto', 'donde voto', 'donde votar', 'mi mesa', 'mi puesto', 'puesto de votacion', 'mesa de votacion', 'lugar de votacion'])) {
                return Promise.resolve({
                    html: '🗳️ <b>¿Cómo consultar tu puesto de votación?</b><br><br>'
                        + '1. Ve a la sección <b>"Consulta tu Puesto de Votación"</b> en la página principal<br>'
                        + '2. Ingresa tu <b>número de cédula</b> en el campo de búsqueda<br>'
                        + '3. Haz clic en <b>"Consultar Ahora"</b><br>'
                        + '4. El sistema te mostrará:<br>'
                        + '&nbsp;&nbsp;• 📍 <b>Municipio y departamento</b><br>'
                        + '&nbsp;&nbsp;• 🏫 <b>Puesto de votación</b> (nombre del lugar)<br>'
                        + '&nbsp;&nbsp;• 🗺️ <b>Zona</b> a la que perteneces<br>'
                        + '&nbsp;&nbsp;• 📋 <b>Número de mesa</b> asignada<br>'
                        + '&nbsp;&nbsp;• 🏠 <b>Dirección</b> del puesto<br><br>'
                        + '💡 También puedes hacer la consulta en <a href="/consulta-mesa" style="color:#1d4ed8;font-weight:700;">este enlace</a>.',
                    chips: ['Documentos necesarios', 'Horario de votación', 'No encuentro mi cédula']
                });
            }

            if (tiene(q, ['no encuentro mi cedula', 'cedula no aparece', 'no estoy registrado', 'documento no encontrado', 'no aparezco'])) {
                return Promise.resolve({
                    html: '⚠️ <b>Si tu cédula no aparece en el sistema:</b><br><br>'
                        + '1. Verifica que estés ingresando el número <b>correcto y completo</b><br>'
                        + '2. Asegúrate de que tu cédula esté <b>vigente</b><br>'
                        + '3. Si nunca has votado, puede que no estés <b>inscrito en el censo electoral</b><br><br>'
                        + '📞 Comunícate con nosotros:<br>'
                        + '&nbsp;&nbsp;• <b>Línea 195</b> (línea gratuita nacional)<br>'
                        + '&nbsp;&nbsp;• Visita la Registraduría en Nobsa<br>'
                        + '&nbsp;&nbsp;• Horario: Lunes a Viernes 8:00 AM – 5:00 PM',
                    chips: ['Horarios de atención', 'Qué es la Registraduría', 'Cómo registrarse']
                });
            }

            /* ── DOCUMENTOS Y REQUISITOS ─────────────────────────── */

            if (tiene(q, ['documentos necesarios', 'que necesito', 'requisitos', 'que documentos', 'que se necesita para votar'])) {
                return Promise.resolve({
                    html: '🪪 <b>Documentos para ejercer el derecho al voto:</b><br><br>'
                        + card('Documentos válidos para votar', [
                            { label: '🪪 Cédula de ciudadanía', val: 'Principal (vigente)' },
                            { label: '🎫 Tarjeta de identidad', val: 'Mayores de 14 años' },
                            { label: '📘 Pasaporte colombiano', val: 'Válido en el exterior' },
                            { label: '🪖 Cédula de extranjería', val: 'Para extranjeros habilitados' }
                        ])
                        + '<br>⚠️ <b>No se acepta</b> fotocopia del documento ni documento vencido.',
                    chips: ['Dónde votar', 'Horario de votación', 'Consultar mi mesa']
                });
            }

            /* ── HORARIOS ─────────────────────────────────────────── */

            if (tiene(q, ['horario', 'hora', 'cuando atienden', 'cuando es', 'hora votacion', 'horario votacion', 'horario atencion'])) {
                return Promise.resolve({
                    html: '🕐 <b>Horarios importantes:</b><br><br>'
                        + card('Horarios', [
                            { label: '🗳️ Jornada electoral',      val: '8:00 AM – 4:00 PM' },
                            { label: '🏢 Atención en oficina',    val: 'Lun–Vie · 8:00 AM – 5:00 PM' },
                            { label: '📞 Línea de atención',      val: '195 (gratuita)' }
                        ])
                        + '<br>💡 Los horarios electorales pueden variar según el tipo de elección. Consulta el calendario oficial en la <b>Registraduría Nacional</b>.',
                    chips: ['Consultar mi mesa', 'Documentos necesarios', 'Contacto']
                });
            }

            /* ── CÓMO REGISTRARSE / INSCRIPCIÓN ELECTORAL ─────────── */

            if (tiene(q, ['como registrarse', 'inscripcion', 'inscribirse', 'registro electoral', 'como me inscribo', 'cambiar puesto', 'trasladar puesto', 'cambio de puesto'])) {
                return Promise.resolve({
                    html: '📋 <b>Inscripción y traslado electoral:</b><br><br>'
                        + '<b>Primera vez votando:</b><br>'
                        + '1. Obtén tu <b>cédula de ciudadanía</b> en la Registraduría<br>'
                        + '2. Queda automáticamente inscrito en el censo electoral<br><br>'
                        + '<b>Cambio de puesto de votación:</b><br>'
                        + '1. Acércate a cualquier <b>Registraduría Municipal</b><br>'
                        + '2. Presenta tu cédula vigente<br>'
                        + '3. Solicita el traslado al municipio o puesto deseado<br><br>'
                        + '⚠️ Los traslados cierran varios meses antes de cada elección. Consulta las fechas oficiales.',
                    chips: ['Consultar mi mesa', 'Documentos necesarios', 'Horarios de atención']
                });
            }

            /* ── CEDULA DE CIUDADANÍA ─────────────────────────────── */

            if (tiene(q, ['cedula', 'cedula de ciudadania', 'tramite cedula', 'sacar cedula', 'renovar cedula', 'primera cedula'])) {
                return Promise.resolve({
                    html: '🪪 <b>Trámite de Cédula de Ciudadanía:</b><br><br>'
                        + '<b>Para primera cédula (18 años):</b><br>'
                        + '&nbsp;&nbsp;• Registro civil de nacimiento original<br>'
                        + '&nbsp;&nbsp;• Tarjeta de identidad anterior<br><br>'
                        + '<b>Para renovación:</b><br>'
                        + '&nbsp;&nbsp;• Cédula anterior o denuncia por pérdida<br><br>'
                        + '📍 Acércate a la <b>Registraduría Municipal de Nobsa</b><br>'
                        + '🕐 Horario: Lunes a Viernes 8:00 AM – 5:00 PM<br><br>'
                        + '💡 También puedes iniciar el trámite en <b>registraduria.gov.co</b>',
                    chips: ['Horarios de atención', 'Contacto', 'Consultar mi mesa']
                });
            }

            /* ── CONTACTO ─────────────────────────────────────────── */

            if (tiene(q, ['contacto', 'telefono', 'correo', 'email', 'comunicarme', 'hablar con', 'numero de contacto'])) {
                return Promise.resolve({
                    html: '📞 <b>Información de contacto:</b><br><br>'
                        + card('Canales de atención', [
                            { label: '📞 Línea gratuita',   val: '195' },
                            { label: '📧 Correo',           val: 'info@registraduria.gov.co' },
                            { label: '🕐 Horario oficina',  val: 'Lun–Vie · 8AM–5PM' },
                            { label: '📍 Municipio',        val: 'Nobsa, Boyacá' }
                        ]),
                    chips: ['Horarios de atención', 'Dónde votar', 'Qué es la Registraduría']
                });
            }

            /* ══════════════════════════════════════════════════════
               RESPUESTAS SOLO ADMIN
            ══════════════════════════════════════════════════════ */
            if (rol === 'admin') {

                if (tiene(q, ['estadisticas', 'estadisticas generales', 'resumen general', 'dashboard', 'cuantos', 'total'])) {
                    return fetchData(ctx + '/chatbot?accion=stats_generales').then(function (d) {
                        if (!d.success) return errMsg(d.error, ['Ciudadanos sin mesa', 'Resumen de mesas']);
                        var pct = d.totalCiudadanos > 0
                            ? Math.round((d.conMesa / d.totalCiudadanos) * 100) : 0;
                        return {
                            html: '📊 <b>Estadísticas generales del sistema:</b>'
                                + card('Estado actual', [
                                    { label: '👥 Total ciudadanos',        val: fmt(d.totalCiudadanos) },
                                    { label: '✅ Con mesa asignada',       val: fmt(d.conMesa) + ' (' + pct + '%)', cls: pct >= 80 ? 'ok' : 'warn' },
                                    { label: '⚠️ Sin mesa asignada',      val: fmt(d.sinMesa), cls: d.sinMesa > 0 ? 'err' : 'ok' },
                                    { label: '🗳️ Total mesas',           val: fmt(d.totalMesas) },
                                    { label: '🗺️ Total zonas',           val: fmt(d.totalZonas) },
                                    { label: '👤 Usuarios del sistema',   val: fmt(d.totalUsuarios) }
                                ]),
                            chips: ['Ciudadanos sin mesa', 'Resumen de mesas', 'Cómo agregar ciudadano']
                        };
                    });
                }

                if (tiene(q, ['ciudadanos sin mesa', 'sin asignar', 'sin mesa', 'pendientes de asignacion'])) {
                    return fetchData(ctx + '/chatbot?accion=ciudadanos_sin_mesa').then(function (d) {
                        if (!d.success) return errMsg(d.error, ['Estadísticas generales', 'Resumen de mesas']);
                        if (d.sinMesa === 0) {
                            return { html: '🎉 ¡Excelente! <b>Todos los ciudadanos</b> tienen mesa de votación asignada.', chips: ['Estadísticas generales', 'Resumen de mesas'] };
                        }
                        var filas = [{ label: 'Sin mesa asignada', val: fmt(d.sinMesa) + ' ciudadano(s)', cls: 'err' }];
                        if (d.detalle && d.detalle.length > 0) {
                            d.detalle.forEach(function (c) {
                                filas.push({ label: '👤 ' + esc(c.nombre), val: c.documento });
                            });
                        }
                        return {
                            html: '⚠️ Hay <b>' + fmt(d.sinMesa) + ' ciudadano(s)</b> sin mesa asignada.'
                                + card('Últimos registrados sin mesa', filas)
                                + '<br>Ve a <b>Gestión → Ciudadanos</b> para asignar mesas.',
                            chips: ['Estadísticas generales', 'Cómo asignar mesa', 'Gestionar ciudadanos']
                        };
                    });
                }

                if (tiene(q, ['resumen mesas', 'resumen de mesas', 'capacidad mesas', 'zonas y mesas', 'mesas por zona'])) {
                    return fetchData(ctx + '/chatbot?accion=resumen_mesas').then(function (d) {
                        if (!d.success) return errMsg(d.error, ['Estadísticas generales']);
                        var filas = [];
                        if (d.zonas && d.zonas.length > 0) {
                            d.zonas.forEach(function (z) {
                                filas.push({ label: '🗺️ ' + esc(z.zona), val: z.mesas + ' mesa(s) · Cap. ' + fmt(z.capacidad) });
                            });
                        }
                        return {
                            html: '🗳️ <b>Resumen de mesas por zona:</b>'
                                + card('Zonas de votación', filas),
                            chips: ['Estadísticas generales', 'Ciudadanos sin mesa', 'Gestionar zonas']
                        };
                    });
                }

                /* ── Gestión Ciudadanos (admin) ── */
                if (tiene(q, ['gestionar ciudadanos', 'gestionar ciudadano', 'modulo ciudadanos', 'lista ciudadanos', 'ver ciudadanos'])) {
                    return Promise.resolve({
                        html: '👥 <b>Módulo de Ciudadanos</b> — Lo que puedes hacer:<br><br>'
                            + card('Acciones disponibles', [
                                { label: '📋 Ver todos',          val: 'Menú → Ciudadanos' },
                                { label: '➕ Nuevo ciudadano',    val: 'Botón "+ Nuevo Ciudadano"' },
                                { label: '✏️ Editar ciudadano',   val: 'Ícono lápiz en la fila' },
                                { label: '🗑️ Eliminar ciudadano', val: 'Ícono basura en la fila' },
                                { label: '🗳️ Asignar mesa',      val: 'Campo mesa en el formulario' },
                                { label: '🔍 Buscar',             val: 'Barra de búsqueda superior' }
                            ]),
                        chips: ['Cómo agregar ciudadano', 'Ciudadanos sin mesa', 'Estadísticas generales']
                    });
                }

                if (tiene(q, ['agregar ciudadano', 'nuevo ciudadano', 'registrar ciudadano', 'crear ciudadano'])) {
                    return Promise.resolve({
                        html: '➕ <b>Agregar un nuevo ciudadano:</b><br><br>'
                            + '1. Ve a <b>Gestión → Ciudadanos</b> en el menú lateral<br>'
                            + '2. Clic en el botón <b>"+ Nuevo Ciudadano"</b><br>'
                            + '3. Completa el formulario:<br>'
                            + '&nbsp;&nbsp;• <b>Número de documento</b> (cédula)<br>'
                            + '&nbsp;&nbsp;• <b>Nombres y apellidos</b><br>'
                            + '&nbsp;&nbsp;• <b>Fecha de nacimiento</b><br>'
                            + '&nbsp;&nbsp;• <b>Mesa de votación</b> asignada<br>'
                            + '4. Clic en <b>Guardar</b>',
                        chips: ['Gestionar ciudadanos', 'Cómo asignar mesa', 'Ciudadanos sin mesa']
                    });
                }

                if (tiene(q, ['asignar mesa', 'como asignar mesa', 'asignacion de mesa'])) {
                    return Promise.resolve({
                        html: '🗳️ <b>Asignar una mesa a un ciudadano:</b><br><br>'
                            + '1. Ve a <b>Gestión → Ciudadanos</b><br>'
                            + '2. Busca el ciudadano por nombre o documento<br>'
                            + '3. Clic en el ícono de <b>lápiz ✏️</b><br>'
                            + '4. En el campo <b>"Mesa de Votación"</b>, selecciona la mesa correspondiente<br>'
                            + '5. Clic en <b>Guardar cambios</b><br><br>'
                            + '💡 La mesa debe existir previamente en el módulo de <b>Mesas de Votación</b>.',
                        chips: ['Gestionar mesas', 'Gestionar zonas', 'Ciudadanos sin mesa']
                    });
                }

                /* ── Gestión Mesas y Zonas (admin) ── */
                if (tiene(q, ['gestionar mesas', 'gestionar mesa', 'modulo mesas', 'mesas votacion'])) {
                    return Promise.resolve({
                        html: '🗳️ <b>Módulo de Mesas de Votación:</b><br><br>'
                            + card('Acciones disponibles', [
                                { label: '📋 Ver todas',     val: 'Menú → Mesas de Votación' },
                                { label: '➕ Nueva mesa',    val: 'Botón "+ Nueva Mesa"' },
                                { label: '✏️ Editar mesa',   val: 'Ícono lápiz en la fila' },
                                { label: '🗑️ Eliminar mesa', val: 'Ícono basura en la fila' }
                            ])
                            + '<br>💡 Cada mesa pertenece a una <b>zona de votación</b> y tiene una <b>capacidad</b> definida.',
                        chips: ['Gestionar zonas', 'Resumen de mesas', 'Cómo asignar mesa']
                    });
                }

                if (tiene(q, ['gestionar zonas', 'gestionar zona', 'modulo zonas', 'zonas votacion'])) {
                    return Promise.resolve({
                        html: '🗺️ <b>Módulo de Zonas de Votación:</b><br><br>'
                            + card('Acciones disponibles', [
                                { label: '📋 Ver todas',       val: 'Menú → Zonas de Votación' },
                                { label: '➕ Nueva zona',      val: 'Botón "+ Nueva Zona"' },
                                { label: '✏️ Editar zona',     val: 'Ícono lápiz en la fila' },
                                { label: '🗑️ Eliminar zona',   val: 'Ícono basura en la fila' }
                            ])
                            + '<br>💡 Las zonas están asociadas a una <b>ciudad</b> y contienen múltiples <b>mesas</b>. El <b>puesto de votación</b> y la <b>dirección</b> se definen en la zona.',
                        chips: ['Gestionar mesas', 'Resumen de mesas', 'Estadísticas generales']
                    });
                }

                /* ── Gestión Usuarios del sistema (admin) ── */
                if (tiene(q, ['gestionar usuarios', 'gestionar usuario', 'modulo usuarios', 'usuarios sistema', 'crear usuario admin'])) {
                    return Promise.resolve({
                        html: '👤 <b>Módulo de Usuarios del Sistema:</b><br><br>'
                            + card('Acciones disponibles', [
                                { label: '📋 Ver todos',         val: 'Menú → Usuarios' },
                                { label: '➕ Nuevo usuario',     val: 'Botón "+ Nuevo Usuario"' },
                                { label: '✏️ Editar usuario',    val: 'Ícono lápiz' },
                                { label: '🗑️ Eliminar usuario',  val: 'Ícono basura' }
                            ])
                            + '<br>💡 Los usuarios pueden tener rol <b>ADMIN</b> (acceso total) o <b>VOTANTE</b> (acceso limitado).',
                        chips: ['Estadísticas generales', 'Gestionar ciudadanos']
                    });
                }

                /* ── Documentos (admin) ── */
                if (tiene(q, ['documentos expedidos', 'modulo documentos', 'gestionar documentos', 'ver documentos'])) {
                    return Promise.resolve({
                        html: '📄 <b>Módulo de Documentos Expedidos:</b><br><br>'
                            + 'Gestiona los documentos emitidos a los ciudadanos (cédulas, tarjetas de identidad, etc.).<br><br>'
                            + card('Acciones disponibles', [
                                { label: '📋 Ver todos',          val: 'Menú → Documentos' },
                                { label: '➕ Nuevo documento',    val: 'Botón "+ Nuevo Documento"' },
                                { label: '✏️ Editar documento',   val: 'Ícono lápiz en la fila' },
                                { label: '🗑️ Eliminar documento', val: 'Ícono basura en la fila' }
                            ]),
                        chips: ['Gestionar ciudadanos', 'Estadísticas generales']
                    });
                }

                /* ── Ayuda admin ── */
                if (tiene(q, ['ayuda', 'opciones', 'que puedo hacer', 'menu', 'comandos'])) {
                    return Promise.resolve({
                        html: '🤝 <b>Todo lo que puedo ayudarte como Admin:</b><br><br>'
                            + '<b>📊 Datos en tiempo real:</b><br>'
                            + '• Estadísticas generales del sistema<br>'
                            + '• Ciudadanos sin mesa asignada<br>'
                            + '• Resumen de mesas por zona<br><br>'
                            + '<b>👥 Gestión de datos:</b><br>'
                            + '• Ciudadanos: agregar, editar, asignar mesas<br>'
                            + '• Mesas y zonas de votación<br>'
                            + '• Usuarios del sistema<br>'
                            + '• Documentos expedidos<br><br>'
                            + '<b>ℹ️ Información:</b><br>'
                            + '• Consulta de puestos de votación<br>'
                            + '• Horarios y requisitos',
                        chips: ['Estadísticas generales', 'Ciudadanos sin mesa', 'Gestionar ciudadanos', 'Gestionar zonas']
                    });
                }

                /* Default admin */
                return Promise.resolve({
                    html: '🤔 No encontré una respuesta para "<b>' + esc(text) + '</b>".<br><br>Puedo ayudarte con: estadísticas, ciudadanos, mesas, zonas, usuarios y documentos.',
                    chips: ['Ayuda', 'Estadísticas generales', 'Ciudadanos sin mesa']
                });
            }

            /* ══════════════════════════════════════════════════════
               RESPUESTAS VOTANTE AUTENTICADO
            ══════════════════════════════════════════════════════ */
            if (rol === 'votante') {

                if (tiene(q, ['mi perfil', 'mis datos', 'editar perfil', 'ver perfil'])) {
                    return Promise.resolve({
                        html: '👤 <b>Tu perfil:</b><br><br>'
                            + 'Puedes ver y actualizar tu información en <b>Mi Perfil</b> en el menú de navegación.<br><br>'
                            + '💡 Si necesitas actualizar datos sensibles como tu documento, acércate directamente a la Registraduría.',
                        chips: ['Consultar mi mesa', 'Documentos necesarios', 'Contacto']
                    });
                }

                if (tiene(q, ['ayuda', 'opciones', 'que puedo hacer'])) {
                    return Promise.resolve({
                        html: '🤝 <b>Puedo ayudarte con:</b><br><br>'
                            + '🗳️ Consultar tu puesto de votación<br>'
                            + '🪪 Documentos necesarios para votar<br>'
                            + '🕐 Horarios de votación y atención<br>'
                            + '📋 Inscripción y traslado electoral<br>'
                            + '🪪 Trámite de cédula de ciudadanía<br>'
                            + '📞 Información de contacto',
                        chips: ['Consultar mi mesa', 'Documentos necesarios', 'Horario de votación', 'Contacto']
                    });
                }

                /* Default votante */
                return Promise.resolve({
                    html: '🤔 No encontré una respuesta para "<b>' + esc(text) + '</b>". Puedo ayudarte con tu puesto de votación, documentos requeridos o información sobre el proceso electoral.',
                    chips: ['Consultar mi mesa', 'Documentos necesarios', 'Horario de votación', 'Ayuda']
                });
            }

            /* ══════════════════════════════════════════════════════
               RESPUESTAS INVITADO
            ══════════════════════════════════════════════════════ */

            if (tiene(q, ['ayuda', 'opciones', 'que puedo hacer', 'menu', 'como funciona'])) {
                return Promise.resolve({
                    html: '🤝 <b>Como visitante puedo ayudarte con:</b><br><br>'
                        + '🗳️ Cómo consultar tu puesto de votación<br>'
                        + '🪪 Documentos necesarios para votar<br>'
                        + '🕐 Horarios de atención y votación<br>'
                        + '📋 Cómo inscribirte o cambiar de puesto<br>'
                        + '🪪 Trámite de cédula de ciudadanía<br>'
                        + '📞 Información de contacto<br><br>'
                        + '💡 <a href="/login" style="color:#1d4ed8;font-weight:700;">Inicia sesión</a> para acceder a tu perfil y documentos.',
                    chips: ['Consultar puesto de votación', 'Documentos necesarios', 'Horarios de atención', 'Cómo registrarse']
                });
            }

            /* Default invitado */
            return Promise.resolve({
                html: '👋 Puedo ayudarte a encontrar tu puesto de votación o responder tus preguntas sobre el proceso electoral en Nobsa, Boyacá.',
                chips: ['Consultar puesto de votación', 'Documentos necesarios', 'Horarios de atención', 'Qué es la Registraduría']
            });
        });
    }

})();