<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
        <!DOCTYPE html>
        <html lang="es">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
            <title>Registraduría Municipal de Nobsa | Tu identidad, nuestro compromiso</title>

            <!-- Google Fonts-->
            <link
                href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap"
                rel="stylesheet">
            <script src="https://cdn.tailwindcss.com"></script>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

            <style>
                body {
                    font-family: 'Inter', sans-serif;
                    scroll-behavior: smooth;
                }

                .hero-gradient {
                    background: linear-gradient(135deg, #0a2540 0%, #1a5a9c 50%, #0d2b45 100%);
                }

                .card-hover:hover {
                    transform: translateY(-4px);
                    transition: all 0.3s ease;
                    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.02);
                }

                @keyframes fadeInUp {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                    }

                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                .animate-fadeInUp {
                    animation: fadeInUp 0.6s ease-out forwards;
                }

                .delay-100 {
                    animation-delay: 0.1s;
                }

                .delay-200 {
                    animation-delay: 0.2s;
                }

                .delay-300 {
                    animation-delay: 0.3s;
                }

                .delay-400 {
                    animation-delay: 0.4s;
                }

                .delay-500 {
                    animation-delay: 0.5s;
                }

                .btn-auth-primary:hover {
                    box-shadow:
                        0 20px 40px -10px rgba(37, 99, 235, 0.4),
                        0 0 0 1px rgba(255, 255, 255, 0.1) inset;
                }

                @keyframes pulse-subtle {

                    0%,
                    100% {
                        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
                    }

                    50% {
                        box-shadow: 0 8px 24px rgba(37, 99, 235, 0.35);
                    }
                }

                @media (min-width: 1024px) {
                    .btn-auth-primary:not(:hover) {
                        animation: pulse-subtle 3s ease-in-out infinite;
                    }
                }

                .btn-auth-primary {
                    position: relative;
                    overflow: hidden;
                }

                .btn-auth-primary::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: -100%;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
                    transition: left 0.5s ease;
                }

                .btn-auth-primary:hover::before {
                    left: 100%;
                }

                .btn-auth-secondary:hover {
                    box-shadow:
                        0 10px 25px -5px rgba(0, 0, 0, 0.1),
                        0 8px 16px -4px rgba(59, 130, 246, 0.15);
                }

                .btn-auth i {
                    transition: transform 0.3s ease, color 0.3s ease;
                }

                .btn-auth-secondary:hover i {
                    transform: translateX(3px);
                }

                .btn-auth-primary:hover i {
                    transform: rotate(15deg) scale(1.1);
                }

                .btn-auth-click {
                    position: relative;
                }

                .btn-auth-click::after {
                    content: '';
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    width: 0;
                    height: 0;
                    background: rgba(255, 255, 255, 0.4);
                    border-radius: 50%;
                    transform: translate(-50%, -50%) scale(0);
                    transition: width 0.4s ease, height 0.4s ease;
                    pointer-events: none;
                }

                .btn-auth-click:active::after {
                    width: 300px;
                    height: 300px;
                    opacity: 0;
                }

                /* MODALES*/

                .modal-overlay {
                    display: none;
                    position: fixed;
                    inset: 0;
                    background: rgba(0, 0, 0, 0.6);
                    backdrop-filter: blur(8px);
                    z-index: 9999;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                    animation: fadeIn 0.3s ease-out;
                }

                .modal-overlay.active {
                    display: flex;
                }

                @keyframes fadeIn {
                    from {
                        opacity: 0;
                    }

                    to {
                        opacity: 1;
                    }
                }

                @keyframes slideUp {
                    from {
                        opacity: 0;
                        transform: translateY(50px) scale(0.95);
                    }

                    to {
                        opacity: 1;
                        transform: translateY(0) scale(1);
                    }
                }

                .modal-content {
                    background: rgba(255, 255, 255, 0.95);
                    backdrop-filter: blur(20px);
                    -webkit-backdrop-filter: blur(20px);
                    border: 1px solid rgba(255, 255, 255, 0.3);
                    border-radius: 24px;
                    max-width: 600px;
                    width: 100%;
                    max-height: 85vh;
                    overflow-y: auto;
                    box-shadow:
                        0 25px 50px -12px rgba(0, 0, 0, 0.25),
                        0 0 0 1px rgba(255, 255, 255, 0.1) inset;
                    animation: slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1);
                    position: relative;
                }

                .modal-header {
                    background: linear-gradient(135deg, #1a5a9c 0%, #0a2540 100%);
                    color: white;
                    padding: 24px 28px;
                    border-radius: 24px 24px 0 0;
                    display: flex;
                    align-items: center;
                    gap: 16px;
                }

                .modal-icon {
                    width: 56px;
                    height: 56px;
                    background: rgba(255, 255, 255, 0.15);
                    border-radius: 16px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 24px;
                    flex-shrink: 0;
                }

                .modal-title {
                    font-family: 'Inter', sans-serif;
                    font-size: 22px;
                    font-weight: 700;
                    line-height: 1.3;
                }

                .modal-close {
                    position: absolute;
                    top: 20px;
                    right: 20px;
                    width: 40px;
                    height: 40px;
                    background: rgba(255, 255, 255, 0.15);
                    border: none;
                    border-radius: 12px;
                    color: white;
                    font-size: 20px;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.2s ease;
                }

                .modal-close:hover {
                    background: rgba(239, 68, 68, 0.8);
                    transform: rotate(90deg);
                }

                .modal-body {
                    padding: 28px;
                }

                .modal-section {
                    margin-bottom: 24px;
                }

                .modal-section:last-child {
                    margin-bottom: 0;
                }

                .modal-section-title {
                    font-size: 16px;
                    font-weight: 700;
                    color: #1a5a9c;
                    margin-bottom: 12px;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }

                .modal-section-content {
                    color: #475569;
                    line-height: 1.7;
                    font-size: 14px;
                }

                .modal-list {
                    list-style: none;
                    padding: 0;
                    margin: 12px 0;
                }

                .modal-list li {
                    padding: 10px 0;
                    padding-left: 32px;
                    position: relative;
                    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
                }

                .modal-list li:last-child {
                    border-bottom: none;
                }

                .modal-list li::before {
                    content: '\f00c';
                    font-family: 'Font Awesome 6 Free';
                    font-weight: 900;
                    position: absolute;
                    left: 0;
                    color: #10b981;
                    font-size: 14px;
                }

                .modal-alert {
                    background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(245, 158, 11, 0.05));
                    border: 1px solid rgba(245, 158, 11, 0.3);
                    border-radius: 12px;
                    padding: 16px;
                    display: flex;
                    gap: 12px;
                    margin-top: 16px;
                }

                .modal-alert i {
                    color: #f59e0b;
                    font-size: 20px;
                    flex-shrink: 0;
                    margin-top: 2px;
                }

                .modal-alert-content {
                    flex: 1;
                }

                .modal-alert-title {
                    font-weight: 600;
                    color: #92400e;
                    margin-bottom: 4px;
                }

                .modal-alert-text {
                    font-size: 13px;
                    color: #78350f;
                    line-height: 1.5;
                }

                .modal-footer {
                    padding: 20px 28px;
                    border-top: 1px solid rgba(0, 0, 0, 0.05);
                    display: flex;
                    justify-content: flex-end;
                    gap: 12px;
                }

                .btn-modal {
                    padding: 12px 24px;
                    border-radius: 12px;
                    font-weight: 600;
                    font-size: 14px;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    border: none;
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                }

                .btn-modal-secondary {
                    background: rgba(241, 245, 249, 0.8);
                    color: #475569;
                    border: 1px solid rgba(148, 163, 184, 0.3);
                }

                .btn-modal-secondary:hover {
                    background: rgba(226, 232, 240, 0.9);
                    transform: translateY(-2px);
                }

                .btn-modal-primary {
                    background: linear-gradient(135deg, #1a5a9c, #0a2540);
                    color: white;
                    box-shadow: 0 4px 12px rgba(26, 90, 156, 0.3);
                }

                .btn-modal-primary:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 8px 20px rgba(26, 90, 156, 0.4);
                }

                /* RESPONSIVE EXTRAS */
                @media (max-width: 768px) {
                    .hero-gradient h1 {
                        font-size: 2.5rem !important;
                    }

                    .modal-content {
                        max-height: 95vh;
                        margin: 10px;
                    }

                    .modal-header {
                        padding: 20px;
                    }

                    .modal-body {
                        padding: 20px;
                    }

                    .modal-footer {
                        padding: 16px 20px;
                        flex-direction: column;
                    }

                    .btn-modal {
                        width: 100%;
                        justify-content: center;
                    }
                }
            </style>
        </head>

        <body class="bg-white antialiased">

            <!-- NAVBAR-->
            <header
                class="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
                <!-- Top bar -->
                <div class="bg-gradient-to-r from-blue-900 to-blue-700 text-white text-sm py-2">
                    <div class="container mx-auto px-4 flex justify-between items-center">
                        <div class="flex items-center gap-6">
                            <a href="tel:195" class="flex items-center gap-2 hover:text-blue-200 transition">
                                <i class="fas fa-phone-alt w-4 h-4"></i> <span>Línea 195</span>
                            </a>
                            <a href="mailto:info@registraduria.gov.co"
                                class="hidden md:flex items-center gap-2 hover:text-blue-200 transition">
                                <i class="fas fa-envelope w-4 h-4"></i> <span>info@registraduria.gov.co</span>
                            </a>
                        </div>
                        <div class="text-xs">Horario: Lunes a Viernes 8:00 AM - 5:00 PM</div>
                    </div>
                </div>

                <!-- Menu de Navegacion -->
                <nav class="container mx-auto px-4 py-3 flex items-center justify-between">
                    <!-- Logo -->
                    <a href="<%= request.getContextPath() %>/" class="flex items-center gap-3 group">
                        <div
                            class="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center shadow-md group-hover:shadow-lg transition">
                            <span class="text-white font-bold text-sm">RN</span>
                        </div>
                        <div class="hidden md:block">
                            <h1
                                class="font-bold text-gray-900 text-sm leading-tight group-hover:text-blue-700 transition">
                                Registraduría Nacional</h1>
                            <p class="text-xs text-gray-500">Del Estado Civil</p>
                        </div>
                    </a>

                    <!-- Desktop menu -->
                    <div class="hidden lg:flex items-center gap-8">
                        <a href="#inicio"
                            class="text-gray-700 hover:text-blue-600 transition font-medium relative group">
                            Inicio
                            <span
                                class="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 group-hover:w-full transition-all"></span>
                        </a>
                        <a href="#servicios"
                            class="text-gray-700 hover:text-blue-600 transition font-medium relative group">
                            Servicios
                            <span
                                class="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 group-hover:w-full transition-all"></span>
                        </a>
                        <a href="#tramites"
                            class="text-gray-700 hover:text-blue-600 transition font-medium relative group">
                            Trámites
                            <span
                                class="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 group-hover:w-full transition-all"></span>
                        </a>
                        <a href="#consultas"
                            class="text-gray-700 hover:text-blue-600 transition font-medium relative group">
                            Consultas
                            <span
                                class="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 group-hover:w-full transition-all"></span>
                        </a>
                        <a href="#noticias"
                            class="text-gray-700 hover:text-blue-600 transition font-medium relative group">
                            Noticias
                            <span
                                class="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 group-hover:w-full transition-all"></span>
                        </a>
                        <a href="#contacto"
                            class="text-gray-700 hover:text-blue-600 transition font-medium relative group">
                            Contacto
                            <span
                                class="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 group-hover:w-full transition-all"></span>
                        </a>
                    </div>

                    <!-- Botones de Autenticación -->
                    <div class="flex items-center gap-3">
                        <!-- Botón Iniciar Sesión  -->
                        <a href="<%= request.getContextPath() %>/login" class="btn-auth btn-auth-secondary hidden md:flex items-center gap-2 px-5 py-2.5 
                          bg-white border-2 border-blue-200 
                          text-blue-700 font-semibold rounded-xl 
                          hover:border-blue-400 hover:bg-blue-50 hover:text-blue-800 
                          hover:shadow-lg hover:-translate-y-0.5 
                          transition-all duration-300 ease-out
                          group btn-auth-click">
                            <i class="fas fa-sign-in-alt w-4 h-4 group-hover:translate-x-0.5 transition-transform"></i>
                            <span>Iniciar Sesión</span>
                        </a>

                        <!-- Botón Registrarse -->
                        <a href="<%= request.getContextPath() %>/registro-votante" class="btn-auth btn-auth-primary hidden md:flex items-center gap-2 px-5 py-2.5 
                          bg-gradient-to-r from-blue-600 to-blue-700 
                          text-white font-semibold rounded-xl 
                          hover:from-blue-700 hover:to-blue-800 
                          hover:shadow-xl hover:shadow-blue-500/30 
                          hover:-translate-y-0.5 hover:scale-[1.02]
                          active:scale-[0.98]
                          transition-all duration-300 ease-out
                          group btn-auth-click">
                            <i class="fas fa-user-plus w-4 h-4 group-hover:rotate-12 transition-transform"></i>
                            <span>Registrarse</span>
                        </a>

                        <!-- Mobile menu button -->
                        <button id="mobileMenuButton" class="lg:hidden p-2.5 rounded-xl hover:bg-gray-100 transition"
                            aria-label="Menú">
                            <i class="fas fa-bars w-6 h-6 text-gray-700"></i>
                        </button>
                    </div>
                </nav>

                <!-- Mobile menu (hidden by default) -->
                <div id="mobileMenu" class="lg:hidden hidden border-t border-gray-100 bg-white py-4 px-4 shadow-lg">
                    <div class="flex flex-col gap-2">
                        <a href="#inicio"
                            class="block py-3 px-4 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition">Inicio</a>
                        <a href="#servicios"
                            class="block py-3 px-4 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition">Servicios</a>
                        <a href="#tramites"
                            class="block py-3 px-4 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition">Trámites</a>
                        <a href="#consultas"
                            class="block py-3 px-4 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition">Consultas</a>
                        <a href="#noticias"
                            class="block py-3 px-4 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition">Noticias</a>
                        <a href="#contacto"
                            class="block py-3 px-4 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition">Contacto</a>

                        <hr class="my-3 border-gray-200">

                        <!-- Botones móviles -->
                        <a href="<%= request.getContextPath() %>/login" class="btn-auth btn-auth-secondary flex items-center justify-center gap-2 py-3 px-4 
                          bg-white border-2 border-blue-200 
                          text-blue-700 font-semibold rounded-xl 
                          hover:border-blue-400 hover:bg-blue-50 
                          transition-all duration-300 btn-auth-click">
                            <i class="fas fa-sign-in-alt w-4 h-4"></i> Iniciar Sesión
                        </a>
                        <a href="<%= request.getContextPath() %>/registro" class="btn-auth btn-auth-primary flex items-center justify-center gap-2 py-3 px-4 
                          bg-gradient-to-r from-blue-600 to-blue-700 
                          text-white font-semibold rounded-xl 
                          hover:from-blue-700 hover:to-blue-800 
                          transition-all duration-300 btn-auth-click">
                            <i class="fas fa-user-plus w-4 h-4"></i> Registrarse
                        </a>
                    </div>
                </div>
            </header>

            <!--  HERO SECTION  -->
            <section id="inicio" class="relative pt-32 pb-20 overflow-hidden hero-gradient">
                <div
                    class="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1597700331582-aab3614b3c0c?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center mix-blend-overlay opacity-20">
                </div>
                <div class="container mx-auto px-4 relative z-10">
                    <div class="grid lg:grid-cols-2 gap-12 items-center">
                        <!-- Left column -->
                        <div class="animate-fadeInUp">
                            <div
                                class="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6 text-white text-sm">
                                <i class="fas fa-shield-alt w-4 h-4"></i> Servicio confiable y seguro
                            </div>
                            <h1 class="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">Tu
                                identidad,<br><span
                                    class="bg-gradient-to-r from-blue-200 to-purple-200 bg-clip-text text-transparent">nuestro
                                    compromiso</span></h1>
                            <p class="text-xl text-blue-100 mb-8 leading-relaxed">Accede a todos nuestros servicios
                                digitales de forma rápida y segura. Consulta tu zona de votación, tramita documentos y
                                más.</p>
                            <div class="flex flex-wrap gap-4">
                                <a href="#consultas"
                                    class="px-8 py-4 bg-white text-blue-900 rounded-lg font-semibold shadow-xl hover:shadow-2xl transition flex items-center gap-2 group">
                                    Consultar ahora <i
                                        class="fas fa-arrow-right w-5 h-5 group-hover:translate-x-1 transition"></i>
                                </a>
                                <a href="#servicios"
                                    class="px-8 py-4 bg-white/10 backdrop-blur-sm text-white rounded-lg font-semibold border border-white/30 hover:bg-white/20 transition">Ver
                                    servicios</a>
                            </div>
                            <div class="grid grid-cols-3 gap-6 mt-12 pt-12 border-t border-white/20">
                                <div>
                                    <div class="text-3xl font-bold text-white mb-1">38M+</div>
                                    <div class="text-sm text-blue-200">Ciudadanos</div>
                                </div>
                                <div>
                                    <div class="text-3xl font-bold text-white mb-1">1,200+</div>
                                    <div class="text-sm text-blue-200">Puntos de atención</div>
                                </div>
                                <div>
                                    <div class="text-3xl font-bold text-white mb-1">24/7</div>
                                    <div class="text-sm text-blue-200">Servicio digital</div>
                                </div>
                            </div>
                        </div>
                        <!-- Right column - Feature cards -->
                        <div class="hidden lg:grid grid-cols-2 gap-6 animate-fadeInUp delay-200">
                            <div
                                class="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 hover:bg-white/20 transition card-hover">
                                <div
                                    class="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mb-4 shadow-lg">
                                    <i class="fas fa-file-alt text-white text-xl"></i></div>
                                <h3 class="text-white font-semibold text-lg mb-2">Trámites digitales</h3>
                                <p class="text-blue-100 text-sm">Gestiona tus documentos en línea</p>
                            </div>
                            <div
                                class="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 hover:bg-white/20 transition card-hover">
                                <div
                                    class="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center mb-4 shadow-lg">
                                    <i class="fas fa-users text-white text-xl"></i></div>
                                <h3 class="text-white font-semibold text-lg mb-2">Consultas rápidas</h3>
                                <p class="text-blue-100 text-sm">Información al instante</p>
                            </div>
                            <div
                                class="col-span-2 bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 hover:bg-white/20 transition card-hover">
                                <div
                                    class="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-lg flex items-center justify-center mb-4 shadow-lg">
                                    <i class="fas fa-shield-alt text-white text-xl"></i></div>
                                <h3 class="text-white font-semibold text-lg mb-2">Datos seguros</h3>
                                <p class="text-blue-100 text-sm">Protección garantizada</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="absolute bottom-0 left-0 right-0">
                    <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-full">
                        <path
                            d="M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z"
                            fill="white" />
                    </svg>
                </div>
            </section>

            <!--  CONSULTA DE ZONA DE VOTACIÓN  -->
            <section id="consultas" class="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
                <div class="container mx-auto px-4">
                    <div class="text-center mb-12 animate-fadeInUp">
                        <div class="inline-flex items-center gap-2 bg-blue-100 px-4 py-2 rounded-full mb-4"><i
                                class="fas fa-map-marker-alt text-blue-600"></i><span
                                class="text-sm text-blue-900 font-medium">Consulta destacada</span></div>
                        <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Consulta tu Puesto de Votación
                        </h2>
                        <p class="text-xl text-gray-600 max-w-2xl mx-auto">Encuentra de forma rápida y segura dónde
                            debes ejercer tu derecho al voto</p>
                    </div>
                    <div class="max-w-4xl mx-auto">
                        <div class="bg-white rounded-2xl shadow-2xl overflow-hidden animate-fadeInUp delay-100">
                            <div class="bg-gradient-to-r from-blue-600 to-blue-700 p-8 text-white">
                                <h3 class="text-2xl font-bold mb-2">Ingresa tu número de documento</h3>
                                <p class="text-blue-100">Consulta tu lugar de votación para las próximas elecciones</p>
                            </div>
                            <div class="p-8">
                                <form action="<%= request.getContextPath() %>/consulta-mesa" method="get" class="mb-6">
                                    <div class="flex justify-center">
                                        <button type="submit"
                                            class="px-8 py-4 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 shadow-lg hover:shadow-xl transition flex items-center gap-2">
                                            <i class="fas fa-search"></i> Consultar
                                        </button>
                                    </div>
                                </form>
                                <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 flex gap-3"><i
                                        class="fas fa-info-circle text-blue-600 text-xl"></i>
                                    <div class="text-sm text-blue-900"><strong>Importante:</strong> Asegúrate de que tu
                                        documento esté vigente y actualizado en nuestro sistema.</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid md:grid-cols-3 gap-4 mt-8">
                            <button onclick="openModal('modalPrimeraVez')"
                                class="bg-white border-2 border-blue-200 hover:border-blue-400 rounded-xl p-4 text-center font-medium text-gray-700 hover:text-blue-600 transition cursor-pointer card-hover">
                                <i class="fas fa-question-circle text-2xl mb-2 block text-blue-600"></i>
                                ¿Primera vez votando?
                            </button>
                            <button onclick="openModal('modalCambioPuesto')"
                                class="bg-white border-2 border-purple-200 hover:border-purple-400 rounded-xl p-4 text-center font-medium text-gray-700 hover:text-purple-600 transition cursor-pointer card-hover">
                                <i class="fas fa-exchange-alt text-2xl mb-2 block text-purple-600"></i>
                                Cambio de puesto
                            </button>
                            <button onclick="openModal('modalJurados')"
                                class="bg-white border-2 border-indigo-200 hover:border-indigo-400 rounded-xl p-4 text-center font-medium text-gray-700 hover:text-indigo-600 transition cursor-pointer card-hover">
                                <i class="fas fa-users text-2xl mb-2 block text-indigo-600"></i>
                                Jurados de votación
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            <!--  MODALES GLASSMORPHISM  -->

            <!-- Modal: ¿Primera vez votando? -->
            <div id="modalPrimeraVez" class="modal-overlay" onclick="closeModalOnOverlay(event, 'modalPrimeraVez')">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-icon">
                            <i class="fas fa-user-plus"></i>
                        </div>
                        <div class="modal-title">¿Es tu primera vez votando?</div>
                        <button class="modal-close" onclick="closeModal('modalPrimeraVez')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="modal-section">
                            <div class="modal-section-title">
                                <i class="fas fa-info-circle"></i>
                                ¿Qué necesitas saber?
                            </div>
                            <div class="modal-section-content">
                                <p>Si es la primera vez que vas a votar en Colombia, es importante que conozcas los
                                    siguientes aspectos:</p>
                                <ul class="modal-list">
                                    <li>Debes tener tu cédula de ciudadanía amarilla con hologramas</li>
                                    <li>Verifica que ya estés registrado en el censo electoral</li>
                                    <li>Consulta tu puesto de votación con tu número de cédula</li>
                                    <li>Lleva tu cédula el día de las elecciones (es el único documento válido)</li>
                                    <li>Conoce la ubicación de tu puesto de votación antes del día de las elecciones
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="modal-section">
                            <div class="modal-section-title">
                                <i class="fas fa-clipboard-list"></i>
                                Pasos para votar por primera vez
                            </div>
                            <div class="modal-section-content">
                                <ol style="padding-left: 20px; line-height: 2;">
                                    <li><strong>Verifica tu cédula:</strong> Asegúrate de tener tu cédula vigente</li>
                                    <li><strong>Consulta tu puesto:</strong> Ingresa tu número de documento en nuestra
                                        plataforma</li>
                                    <li><strong>Reconoce el lugar:</strong> Visita tu puesto de votación antes del día
                                        de las elecciones</li>
                                    <li><strong>Vota el día de las elecciones:</strong> Presenta tu cédula y ejerce tu
                                        derecho al voto</li>
                                </ol>
                            </div>
                        </div>

                        <div class="modal-alert">
                            <i class="fas fa-exclamation-triangle"></i>
                            <div class="modal-alert-content">
                                <div class="modal-alert-title">Importante</div>
                                <div class="modal-alert-text">
                                    Si acabas de sacar tu cédula y no apareces en el censo electoral, debes esperar al
                                    próximo proceso de actualización del censo o acercarte a la Registraduría más
                                    cercana para verificar tu situación.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn-modal btn-modal-secondary" onclick="closeModal('modalPrimeraVez')">
                            <i class="fas fa-times"></i> Cerrar
                        </button>
                        <a href="<%= request.getContextPath() %>/consulta-mesa" class="btn-modal btn-modal-primary">
                            <i class="fas fa-search"></i> Consultar mi puesto
                        </a>
                    </div>
                </div>
            </div>

            <!-- Modal: Cambio de puesto -->
            <div id="modalCambioPuesto" class="modal-overlay" onclick="closeModalOnOverlay(event, 'modalCambioPuesto')">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-icon">
                            <i class="fas fa-exchange-alt"></i>
                        </div>
                        <div class="modal-title">Cambio de Puesto de Votación</div>
                        <button class="modal-close" onclick="closeModal('modalCambioPuesto')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="modal-section">
                            <div class="modal-section-title">
                                <i class="fas fa-map-marker-alt"></i>
                                ¿Necesitas cambiar tu puesto de votación?
                            </div>
                            <div class="modal-section-content">
                                <p>El cambio de puesto de votación es un trámite que <strong>debe realizarse de forma
                                        presencial</strong> en las oficinas de la Registraduría. Este proceso no se
                                    puede realizar en línea.</p>
                            </div>
                        </div>

                        <div class="modal-section">
                            <div class="modal-section-title">
                                <i class="fas fa-building"></i>
                                ¿Dónde debes ir?
                            </div>
                            <div class="modal-section-content">
                                <p>Debes acercarte a cualquiera de los siguientes lugares:</p>
                                <ul class="modal-list">
                                    <li><strong>Registraduría Municipal de Nobsa:</strong> Dirección principal del
                                        municipio</li>
                                    <li><strong>Puntos de atención SAT:</strong> Servicios de Atención al Ciudadano</li>
                                    <li><strong>Oficinas de la Registraduría Nacional:</strong> En cualquier ciudad del
                                        país</li>
                                </ul>
                            </div>
                        </div>

                        <div class="modal-section">
                            <div class="modal-section-title">
                                <i class="fas fa-file-alt"></i>
                                Documentos requeridos
                            </div>
                            <div class="modal-section-content">
                                <ul class="modal-list">
                                    <li>Cédula de ciudadanía original y vigente</li>
                                    <li>Recibo de servicio público (luz, agua o gas) de tu nueva dirección</li>
                                    <li>Formulario de solicitud de cambio de puesto (se diligencia en la oficina)</li>
                                </ul>
                            </div>
                        </div>

                        <div class="modal-alert">
                            <i class="fas fa-clock"></i>
                            <div class="modal-alert-content">
                                <div class="modal-alert-title">Tiempo de procesamiento</div>
                                <div class="modal-alert-text">
                                    El cambio de puesto de votación tiene un tiempo de procesamiento de 5 a 10 días
                                    hábiles. Te recomendamos realizar este trámite con al menos 30 días de anticipación
                                    a las elecciones.
                                </div>
                            </div>
                        </div>

                        <div class="modal-alert"
                            style="background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05)); border-color: rgba(239, 68, 68, 0.3); margin-top: 16px;">
                            <i class="fas fa-exclamation-circle" style="color: #ef4444;"></i>
                            <div class="modal-alert-content">
                                <div class="modal-alert-title" style="color: #991b1b;">Importante</div>
                                <div class="modal-alert-text" style="color: #7f1d1d;">
                                    <strong>Este trámite NO se puede realizar en línea.</strong> Debes acudir
                                    personalmente a un punto de atención de la Registraduría con los documentos
                                    requeridos.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn-modal btn-modal-secondary" onclick="closeModal('modalCambioPuesto')">
                            <i class="fas fa-times"></i> Cerrar
                        </button>
                        <a href="tel:195" class="btn-modal btn-modal-primary">
                            <i class="fas fa-phone"></i> Llamar a la Línea 195
                        </a>
                    </div>
                </div>
            </div>

            <!-- Modal: Jurados de votación -->
            <div id="modalJurados" class="modal-overlay" onclick="closeModalOnOverlay(event, 'modalJurados')">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="modal-title">Jurados de Votación</div>
                        <button class="modal-close" onclick="closeModal('modalJurados')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="modal-section">
                            <div class="modal-section-title">
                                <i class="fas fa-info-circle"></i>
                                ¿Qué es un jurado de votación?
                            </div>
                            <div class="modal-section-content">
                                <p>Los jurados de votación son ciudadanos seleccionados por la Registraduría Nacional
                                    del Estado Civil para apoyar el desarrollo de los procesos electorales. Su función
                                    es garantizar la transparencia y legalidad de las votaciones.</p>
                            </div>
                        </div>

                        <div class="modal-section">
                            <div class="modal-section-title">
                                <i class="fas fa-tasks"></i>
                                Funciones principales
                            </div>
                            <div class="modal-section-content">
                                <ul class="modal-list">
                                    <li>Verificar la identidad de los votantes</li>
                                    <li>Entregar las tarjetas electorales</li>
                                    <li>Garantizar el orden en el puesto de votación</li>
                                    <li>Realizar el escrutinio y conteo de votos</li>
                                    <li>Llenar y firmar las actas electorales</li>
                                    <li>Custodiar los materiales electorales</li>
                                </ul>
                            </div>
                        </div>

                        <div class="modal-section">
                            <div class="modal-section-title">
                                <i class="fas fa-gift"></i>
                                Beneficios de ser jurado
                            </div>
                            <div class="modal-section-content">
                                <ul class="modal-list">
                                    <li><strong>Día compensatorio:</strong> Un día de descanso remunerado</li>
                                    <li><strong>Auxilio de transporte:</strong> Para el desplazamiento al puesto de
                                        votación</li>
                                    <li><strong>Capacitación:</strong> Recibirás formación sobre el proceso electoral
                                    </li>
                                    <li><strong>Certificación:</strong> Constancia de participación en procesos
                                        democráticos</li>
                                </ul>
                            </div>
                        </div>

                        <div class="modal-section">
                            <div class="modal-section-title">
                                <i class="fas fa-clipboard-check"></i>
                                ¿Cómo inscribirse?
                            </div>
                            <div class="modal-section-content">
                                <p>Puedes inscribirte como jurado de votación de las siguientes formas:</p>
                                <ol style="padding-left: 20px; line-height: 2;">
                                    <li><strong>En línea:</strong> Ingresa a la página web de la Registraduría y
                                        completa el formulario de inscripción</li>
                                    <li><strong>Presencial:</strong> Acércate a cualquier oficina de la Registraduría
                                    </li>
                                    <li><strong>Línea 195:</strong> Llama para recibir información sobre el proceso</li>
                                </ol>
                            </div>
                        </div>

                        <div class="modal-alert">
                            <i class="fas fa-lightbulb"></i>
                            <div class="modal-alert-content">
                                <div class="modal-alert-title">¿Sabías que...?</div>
                                <div class="modal-alert-text">
                                    Ser jurado de votación es un deber ciudadano y una excelente oportunidad para
                                    participar activamente en el fortalecimiento de la democracia colombiana.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn-modal btn-modal-secondary" onclick="closeModal('modalJurados')">
                            <i class="fas fa-times"></i> Cerrar
                        </button>
                        <a href="<%= request.getContextPath() %>/registro-votante" class="btn-modal btn-modal-primary">
                            <i class="fas fa-user-plus"></i> Inscribirme como Jurado
                        </a>
                    </div>
                </div>
            </div>

            <!--  SERVICIOS DIGITALES  -->
            <section id="servicios" class="py-20 bg-white">
                <div class="container mx-auto px-4">
                    <div class="text-center mb-16 animate-fadeInUp">
                        <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Servicios digitales</h2>
                        <p class="text-xl text-gray-600 max-w-2xl mx-auto">Accede a todos nuestros servicios de forma
                            rápida, segura y sin salir de casa</p>
                    </div>
                    <div class="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">

                        <!-- Cédula de ciudadanía -->
                        <div
                            class="relative bg-white border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition cursor-pointer group">
                            <div
                                class="absolute -top-3 -right-3 bg-gradient-to-r from-yellow-400 to-orange-400 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">
                                Popular</div>
                            <div
                                class="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition">
                                <i class="fas fa-id-card text-white text-2xl"></i>
                            </div>
                            <h3 class="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition">Cédula
                                de ciudadanía</h3>
                            <p class="text-sm text-gray-600">Solicita o renueva tu documento de identidad</p>
                            <div class="mt-4 pt-4 border-t border-gray-100">
                                <a href="<%= request.getContextPath() %>/login"
                                    class="text-sm text-blue-600 font-medium group-hover:underline">Ir al servicio →</a>
                            </div>
                        </div>

                        <!-- Certificados -->
                        <div
                            class="bg-white border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition cursor-pointer group">
                            <div
                                class="w-14 h-14 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition">
                                <i class="fas fa-file-alt text-white text-2xl"></i>
                            </div>
                            <h3 class="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition">
                                Certificados</h3>
                            <p class="text-sm text-gray-600">Descarga certificados digitales</p>
                            <div class="mt-4 pt-4 border-t border-gray-100">
                                <a href="<%= request.getContextPath() %>/login"
                                    class="text-sm text-blue-600 font-medium group-hover:underline">Ir al servicio →</a>
                            </div>
                        </div>

                        <!-- Duplicados -->
                        <div
                            class="bg-white border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition cursor-pointer group">
                            <div
                                class="w-14 h-14 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition">
                                <i class="fas fa-copy text-white text-2xl"></i>
                            </div>
                            <h3 class="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition">
                                Duplicados</h3>
                            <p class="text-sm text-gray-600">Solicita duplicado de documentos</p>
                            <div class="mt-4 pt-4 border-t border-gray-100">
                                <a href="<%= request.getContextPath() %>/login"
                                    class="text-sm text-blue-600 font-medium group-hover:underline">Ir al servicio →</a>
                            </div>
                        </div>

                        <!-- Registro civil -->
                        <div
                            class="bg-white border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition cursor-pointer group">
                            <div
                                class="w-14 h-14 bg-gradient-to-br from-pink-500 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition">
                                <i class="fas fa-user-check text-white text-2xl"></i>
                            </div>
                            <h3 class="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition">
                                Registro civil</h3>
                            <p class="text-sm text-gray-600">Nacimientos, matrimonios y defunciones</p>
                            <div class="mt-4 pt-4 border-t border-gray-100">
                                <a href="<%= request.getContextPath() %>/login"
                                    class="text-sm text-blue-600 font-medium group-hover:underline">Ir al servicio →</a>
                            </div>
                        </div>

                        <!-- Cédula extranjería -->
                        <div
                            class="bg-white border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition cursor-pointer group">
                            <div
                                class="w-14 h-14 bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition">
                                <i class="fas fa-users text-white text-2xl"></i>
                            </div>
                            <h3 class="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition">Cédula
                                extranjería</h3>
                            <p class="text-sm text-gray-600">Documentos para extranjeros</p>
                            <div class="mt-4 pt-4 border-t border-gray-100">
                                <a href="<%= request.getContextPath() %>/login"
                                    class="text-sm text-blue-600 font-medium group-hover:underline">Ir al servicio →</a>
                            </div>
                        </div>

                        <!-- Antecedentes -->
                        <div
                            class="bg-white border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition cursor-pointer group">
                            <div
                                class="w-14 h-14 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition">
                                <i class="fas fa-book-open text-white text-2xl"></i>
                            </div>
                            <h3 class="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition">
                                Antecedentes</h3>
                            <p class="text-sm text-gray-600">Consulta de antecedentes</p>
                            <div class="mt-4 pt-4 border-t border-gray-100">
                                <a href="<%= request.getContextPath() %>/login"
                                    class="text-sm text-blue-600 font-medium group-hover:underline">Ir al servicio →</a>
                            </div>
                        </div>

                        <!-- Autenticaciones -->
                        <div
                            class="bg-white border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition cursor-pointer group">
                            <div
                                class="w-14 h-14 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition">
                                <i class="fas fa-shield-alt text-white text-2xl"></i>
                            </div>
                            <h3 class="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition">
                                Autenticaciones</h3>
                            <p class="text-sm text-gray-600">Servicio de autenticación</p>
                            <div class="mt-4 pt-4 border-t border-gray-100">
                                <a href="<%= request.getContextPath() %>/login"
                                    class="text-sm text-blue-600 font-medium group-hover:underline">Ir al servicio →</a>
                            </div>
                        </div>

                        <!-- Consulta BDUA -->
                        <div
                            class="bg-white border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition cursor-pointer group">
                            <div
                                class="w-14 h-14 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition">
                                <i class="fas fa-search text-white text-2xl"></i>
                            </div>
                            <h3 class="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition">
                                Consulta BDUA</h3>
                            <p class="text-sm text-gray-600">Base de datos única de afiliados</p>
                            <div class="mt-4 pt-4 border-t border-gray-100">
                                <a href="<%= request.getContextPath() %>/login"
                                    class="text-sm text-blue-600 font-medium group-hover:underline">Ir al servicio →</a>
                            </div>
                        </div>

                    </div>
                    <div
                        class="mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 md:p-12 text-center text-white animate-fadeInUp delay-200">
                        <h3 class="text-3xl font-bold mb-4">¿No encuentras lo que buscas?</h3>
                        <p class="text-xl text-blue-100 mb-6 max-w-2xl mx-auto">Nuestro equipo de atención está listo
                            para ayudarte con cualquier trámite</p>
                        <div class="flex flex-wrap gap-4 justify-center">
                            <button
                                class="px-8 py-4 bg-white text-blue-600 rounded-lg font-semibold shadow-lg hover:shadow-xl transition">Chatear
                                con un asesor</button>
                            <button
                                class="px-8 py-4 bg-white/10 backdrop-blur-sm text-white rounded-lg font-semibold border-2 border-white/30 hover:bg-white/20 transition">Ver
                                todos los servicios</button>
                        </div>
                    </div>
                </div>
            </section>

            <!--  TRÁMITES MÁS SOLICITADOS  -->
            <section id="tramites" class="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
                <div class="container mx-auto px-4">
                    <div class="text-center mb-16 animate-fadeInUp">
                        <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Trámites más solicitados</h2>
                        <p class="text-xl text-gray-600 max-w-2xl mx-auto">Conoce los requisitos y tiempos de los
                            trámites más comunes</p>
                    </div>
                    <div class="grid lg:grid-cols-2 gap-8 mb-12">
                        <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition card-hover">
                            <div class="flex items-start justify-between mb-6">
                                <div>
                                    <h3 class="text-2xl font-bold text-gray-900 mb-2">Primera cédula para mayores de
                                        edad</h3>
                                    <div class="flex flex-wrap gap-3"><span
                                            class="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">Fácil</span><span
                                            class="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium"><i
                                                class="fas fa-file-alt"></i> 4 pasos</span></div>
                                </div>
                            </div>
                            <div class="flex items-center gap-2 text-gray-600 mb-6 p-4 bg-blue-50 rounded-lg"><i
                                    class="fas fa-clock text-blue-600"></i><span class="font-medium">Tiempo estimado:
                                    15-20 días hábiles</span></div>
                            <div class="mb-6">
                                <h4 class="font-semibold text-gray-900 mb-3">Requisitos:</h4>
                                <ul class="space-y-2">
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Registro civil
                                            de nacimiento</span></li>
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Documento de
                                            identidad anterior</span></li>
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Comprobante de
                                            pago</span></li>
                                </ul>
                            </div>
                            <div class="flex gap-3"><button
                                    class="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition">Iniciar
                                    trámite</button><button
                                    class="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition">Más
                                    info</button></div>
                        </div>
                        <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition card-hover">
                            <div class="flex items-start justify-between mb-6">
                                <div>
                                    <h3 class="text-2xl font-bold text-gray-900 mb-2">Renovación de cédula</h3>
                                    <div class="flex flex-wrap gap-3"><span
                                            class="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">Fácil</span><span
                                            class="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium"><i
                                                class="fas fa-file-alt"></i> 3 pasos</span></div>
                                </div>
                            </div>
                            <div class="flex items-center gap-2 text-gray-600 mb-6 p-4 bg-blue-50 rounded-lg"><i
                                    class="fas fa-clock text-blue-600"></i><span class="font-medium">Tiempo estimado:
                                    10-15 días hábiles</span></div>
                            <div class="mb-6">
                                <h4 class="font-semibold text-gray-900 mb-3">Requisitos:</h4>
                                <ul class="space-y-2">
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Cédula
                                            anterior</span></li>
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Comprobante de
                                            pago</span></li>
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Foto
                                            actualizada</span></li>
                                </ul>
                            </div>
                            <div class="flex gap-3"><button
                                    class="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition">Iniciar
                                    trámite</button><button
                                    class="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition">Más
                                    info</button></div>
                        </div>
                        <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition card-hover">
                            <div class="flex items-start justify-between mb-6">
                                <div>
                                    <h3 class="text-2xl font-bold text-gray-900 mb-2">Registro civil de nacimiento</h3>
                                    <div class="flex flex-wrap gap-3"><span
                                            class="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">Fácil</span><span
                                            class="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium"><i
                                                class="fas fa-file-alt"></i> 3 pasos</span></div>
                                </div>
                            </div>
                            <div class="flex items-center gap-2 text-gray-600 mb-6 p-4 bg-blue-50 rounded-lg"><i
                                    class="fas fa-clock text-blue-600"></i><span class="font-medium">Tiempo estimado:
                                    5-10 días hábiles</span></div>
                            <div class="mb-6">
                                <h4 class="font-semibold text-gray-900 mb-3">Requisitos:</h4>
                                <ul class="space-y-2">
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Certificado de
                                            nacido vivo</span></li>
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Documentos de
                                            los padres</span></li>
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Declaración de
                                            testigos</span></li>
                                </ul>
                            </div>
                            <div class="flex gap-3"><button
                                    class="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition">Iniciar
                                    trámite</button><button
                                    class="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition">Más
                                    info</button></div>
                        </div>
                        <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition card-hover">
                            <div class="flex items-start justify-between mb-6">
                                <div>
                                    <h3 class="text-2xl font-bold text-gray-900 mb-2">Cambio de datos en cédula</h3>
                                    <div class="flex flex-wrap gap-3"><span
                                            class="inline-flex items-center gap-1 px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm font-medium">Media</span><span
                                            class="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium"><i
                                                class="fas fa-file-alt"></i> 5 pasos</span></div>
                                </div>
                            </div>
                            <div class="flex items-center gap-2 text-gray-600 mb-6 p-4 bg-blue-50 rounded-lg"><i
                                    class="fas fa-clock text-blue-600"></i><span class="font-medium">Tiempo estimado:
                                    20-30 días hábiles</span></div>
                            <div class="mb-6">
                                <h4 class="font-semibold text-gray-900 mb-3">Requisitos:</h4>
                                <ul class="space-y-2">
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Cédula
                                            actual</span></li>
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Documentos
                                            soportes del cambio</span></li>
                                    <li class="flex items-start gap-2"><i
                                            class="fas fa-check-circle text-green-500 mt-0.5"></i><span>Formulario
                                            diligenciado</span></li>
                                </ul>
                            </div>
                            <div class="flex gap-3"><button
                                    class="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition">Iniciar
                                    trámite</button><button
                                    class="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition">Más
                                    info</button></div>
                        </div>
                    </div>
                    <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
                        <div class="grid lg:grid-cols-2">
                            <div class="p-8 lg:p-12">
                                <h3 class="text-3xl font-bold text-gray-900 mb-6">¿Cómo funciona el proceso?</h3>
                                <div class="space-y-6">
                                    <div class="flex gap-4">
                                        <div
                                            class="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-full flex items-center justify-center font-bold text-lg shadow-lg">
                                            1</div>
                                        <div>
                                            <h4 class="font-bold text-gray-900 mb-1">Prepara tus documentos</h4>
                                            <p class="text-gray-600">Reúne todos los requisitos necesarios según el
                                                trámite</p>
                                        </div>
                                    </div>
                                    <div class="flex gap-4">
                                        <div
                                            class="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-full flex items-center justify-center font-bold text-lg shadow-lg">
                                            2</div>
                                        <div>
                                            <h4 class="font-bold text-gray-900 mb-1">Agenda tu cita</h4>
                                            <p class="text-gray-600">Selecciona fecha, hora y punto de atención</p>
                                        </div>
                                    </div>
                                    <div class="flex gap-4">
                                        <div
                                            class="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-full flex items-center justify-center font-bold text-lg shadow-lg">
                                            3</div>
                                        <div>
                                            <h4 class="font-bold text-gray-900 mb-1">Asiste a tu cita</h4>
                                            <p class="text-gray-600">Presenta tus documentos en el lugar y hora
                                                agendados</p>
                                        </div>
                                    </div>
                                    <div class="flex gap-4">
                                        <div
                                            class="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-full flex items-center justify-center font-bold text-lg shadow-lg">
                                            4</div>
                                        <div>
                                            <h4 class="font-bold text-gray-900 mb-1">Recibe tu documento</h4>
                                            <p class="text-gray-600">Obtén tu documento en el plazo establecido</p>
                                        </div>
                                    </div>
                                </div><button
                                    class="mt-8 w-full lg:w-auto px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold shadow-lg hover:shadow-xl transition flex items-center justify-center gap-2"><i
                                        class="fas fa-calendar-alt"></i> Agendar cita ahora</button>
                            </div>
                            <div class="relative h-64 lg:h-auto"><img
                                    src="https://images.unsplash.com/photo-1758518731462-d091b0b4ed0d?w=800&q=80"
                                    alt="Personas consultando documentos" class="w-full h-full object-cover">
                                <div class="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!--  NOTICIAS Y ACTUALIZACIONES  -->
            <section id="noticias" class="py-20 bg-white">
                <div class="container mx-auto px-4">
                    <div class="flex flex-col md:flex-row justify-between items-center mb-12">
                        <div>
                            <div class="inline-flex items-center gap-2 bg-purple-100 px-4 py-2 rounded-full mb-4"><i
                                    class="fas fa-chart-line text-purple-600"></i><span
                                    class="text-sm text-purple-900 font-medium">Novedades</span></div>
                            <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Noticias y actualizaciones
                            </h2>
                            <p class="text-xl text-gray-600">Mantente informado sobre nuestros servicios y novedades</p>
                        </div><a href="#"
                            class="hidden lg:flex items-center gap-2 text-blue-600 font-semibold hover:gap-3 transition">Ver
                            todas <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="grid lg:grid-cols-3 gap-8">
                        <div
                            class="lg:col-span-2 bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition card-hover cursor-pointer">
                            <div class="relative overflow-hidden"><img
                                    src="https://images.unsplash.com/photo-1668903678359-e810dd966016?w=800&q=80"
                                    alt="Noticia"
                                    class="w-full h-96 object-cover hover:scale-110 transition duration-500">
                                <div class="absolute top-4 left-4"><span
                                        class="inline-block px-4 py-2 bg-white/90 backdrop-blur-sm text-gray-900 text-sm font-semibold rounded-full shadow-lg">Actualización</span>
                                </div>
                            </div>
                            <div class="p-6">
                                <div class="flex items-center gap-2 text-gray-500 text-sm mb-3"><i
                                        class="fas fa-calendar-alt"></i><span>15 de abril, 2026</span></div>
                                <h3 class="text-2xl font-bold text-gray-900 mb-3 hover:text-blue-600 transition">Nueva
                                    plataforma digital disponible para trámites</h3>
                                <p class="text-gray-600 mb-4">A partir de mayo, todos los ciudadanos podrán realizar sus
                                    trámites 100% en línea</p>
                                <div class="flex items-center gap-2 text-blue-600 font-semibold hover:gap-3 transition">
                                    Leer más <i class="fas fa-arrow-right"></i></div>
                            </div>
                        </div>
                        <div
                            class="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition card-hover cursor-pointer">
                            <div class="relative overflow-hidden"><img
                                    src="https://images.unsplash.com/photo-1597700331582-aab3614b3c0c?w=800&q=80"
                                    alt="Noticia"
                                    class="w-full h-48 object-cover hover:scale-110 transition duration-500">
                                <div class="absolute top-4 left-4"><span
                                        class="inline-block px-4 py-2 bg-white/90 backdrop-blur-sm text-gray-900 text-sm font-semibold rounded-full shadow-lg">Comunicado</span>
                                </div>
                            </div>
                            <div class="p-6">
                                <div class="flex items-center gap-2 text-gray-500 text-sm mb-3"><i
                                        class="fas fa-calendar-alt"></i><span>12 de abril, 2026</span></div>
                                <h3 class="text-xl font-bold text-gray-900 mb-3 hover:text-blue-600 transition">Horarios
                                    especiales para elecciones 2026</h3>
                                <p class="text-gray-600 mb-4">Conoce los horarios de atención especiales durante el
                                    periodo electoral</p>
                                <div class="flex items-center gap-2 text-blue-600 font-semibold hover:gap-3 transition">
                                    Leer más <i class="fas fa-arrow-right"></i></div>
                            </div>
                        </div>
                        <div
                            class="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition card-hover cursor-pointer">
                            <div class="relative overflow-hidden"><img
                                    src="https://images.unsplash.com/photo-1767553667932-b1f07f29cf89?w=800&q=80"
                                    alt="Noticia"
                                    class="w-full h-48 object-cover hover:scale-110 transition duration-500">
                                <div class="absolute top-4 left-4"><span
                                        class="inline-block px-4 py-2 bg-white/90 backdrop-blur-sm text-gray-900 text-sm font-semibold rounded-full shadow-lg">Servicio</span>
                                </div>
                            </div>
                            <div class="p-6">
                                <div class="flex items-center gap-2 text-gray-500 text-sm mb-3"><i
                                        class="fas fa-calendar-alt"></i><span>8 de abril, 2026</span></div>
                                <h3 class="text-xl font-bold text-gray-900 mb-3 hover:text-blue-600 transition">Nuevos
                                    puntos de atención en zonas rurales</h3>
                                <p class="text-gray-600 mb-4">Ampliamos nuestra cobertura con 50 nuevos puntos de
                                    atención</p>
                                <div class="flex items-center gap-2 text-blue-600 font-semibold hover:gap-3 transition">
                                    Leer más <i class="fas fa-arrow-right"></i></div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-8 md:p-12">
                        <div class="grid md:grid-cols-2 gap-8 items-center">
                            <div class="text-white">
                                <h3 class="text-3xl font-bold mb-3">Suscríbete a nuestro boletín</h3>
                                <p class="text-purple-100 text-lg">Recibe las últimas noticias y actualizaciones
                                    directamente en tu correo</p>
                            </div>
                            <div>
                                <form class="flex flex-col sm:flex-row gap-3"><input type="email"
                                        placeholder="tu@email.com"
                                        class="flex-1 px-6 py-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-white"><button
                                        class="px-8 py-4 bg-white text-blue-600 rounded-lg font-semibold hover:bg-gray-100 transition shadow-lg">Suscribirse</button>
                                </form>
                                <p class="text-purple-100 text-sm mt-3">No compartimos tu información. Cancela cuando
                                    quieras.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!--  FOOTER  -->
            <footer id="contacto" class="bg-gradient-to-br from-gray-900 to-gray-800 text-white pt-20 pb-10">
                <div class="container mx-auto px-4">
                    <div class="grid md:grid-cols-2 lg:grid-cols-6 gap-12 mb-16">
                        <div class="lg:col-span-2">
                            <div class="flex items-center gap-3 mb-4">
                                <div
                                    class="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center shadow-lg">
                                    <span class="text-white font-bold text-xl">RN</span></div>
                                <div>
                                    <h3 class="font-bold text-xl">Registraduría Nacional</h3>
                                    <p class="text-sm text-gray-400">Del Estado Civil</p>
                                </div>
                            </div>
                            <p class="text-gray-400 mb-6 leading-relaxed">Garantizamos la identidad de los colombianos y
                                facilitamos el ejercicio de sus derechos políticos y civiles.</p>
                            <div class="space-y-3"><a href="tel:195"
                                    class="flex items-center gap-3 text-gray-300 hover:text-blue-400 transition"><i
                                        class="fas fa-phone-alt"></i><span>Línea gratuita: 195</span></a><a
                                    href="mailto:info@registraduria.gov.co"
                                    class="flex items-center gap-3 text-gray-300 hover:text-blue-400 transition"><i
                                        class="fas fa-envelope"></i><span>info@registraduria.gov.co</span></a>
                                <div class="flex items-start gap-3 text-gray-300"><i
                                        class="fas fa-map-marker-alt mt-1"></i><span>Calle 26 # 51-50, Bogotá D.C.,
                                        Colombia</span></div>
                            </div>
                        </div>
                        <div>
                            <h4 class="font-bold text-lg mb-4">Servicios</h4>
                            <ul class="space-y-3">
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Cédula
                                        de ciudadanía</a></li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Registro
                                        civil</a></li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Certificados</a>
                                </li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Duplicados</a>
                                </li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Autenticaciones</a>
                                </li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-bold text-lg mb-4">Trámites</h4>
                            <ul class="space-y-3">
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Agendar
                                        cita</a></li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Consultas
                                        en línea</a></li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Puntos
                                        de atención</a></li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Formularios</a>
                                </li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Tarifas</a>
                                </li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-bold text-lg mb-4">Información</h4>
                            <ul class="space-y-3">
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Sobre
                                        nosotros</a></li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Misión
                                        y visión</a></li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Normatividad</a>
                                </li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Transparencia</a>
                                </li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">PQRS</a>
                                </li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-bold text-lg mb-4">Ayuda</h4>
                            <ul class="space-y-3">
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Preguntas
                                        frecuentes</a></li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Tutoriales</a>
                                </li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Soporte
                                        técnico</a></li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Mapa
                                        del sitio</a></li>
                                <li><a href="#"
                                        class="text-gray-400 hover:text-white hover:translate-x-1 inline-block transition">Glosario</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="border-t border-gray-700 pt-12 pb-8">
                        <div class="flex flex-col lg:flex-row justify-between items-center gap-8">
                            <div>
                                <p class="text-gray-400 mb-4">Síguenos en redes sociales</p>
                                <div class="flex gap-4"><a href="#"
                                        class="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-blue-600 transition"><i
                                            class="fab fa-facebook-f text-white"></i></a><a href="#"
                                        class="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-blue-600 transition"><i
                                            class="fab fa-twitter text-white"></i></a><a href="#"
                                        class="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-blue-600 transition"><i
                                            class="fab fa-instagram text-white"></i></a><a href="#"
                                        class="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-blue-600 transition"><i
                                            class="fab fa-youtube text-white"></i></a><a href="#"
                                        class="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-blue-600 transition"><i
                                            class="fab fa-linkedin-in text-white"></i></a></div>
                            </div>
                            <div class="flex flex-wrap gap-4"><button
                                    class="px-6 py-3 bg-gray-800 rounded-lg hover:bg-gray-700 transition flex items-center gap-3">
                                    <div class="w-8 h-8 bg-white rounded-lg flex items-center justify-center"><span
                                            class="text-gray-900 font-bold">▶</span></div>
                                    <div>
                                        <div class="text-xs text-gray-400">Disponible en</div>
                                        <div class="font-semibold">Google Play</div>
                                    </div>
                                </button><button
                                    class="px-6 py-3 bg-gray-800 rounded-lg hover:bg-gray-700 transition flex items-center gap-3">
                                    <div class="w-8 h-8 bg-white rounded-lg flex items-center justify-center"><i
                                            class="fab fa-apple text-gray-900 text-xl"></i></div>
                                    <div>
                                        <div class="text-xs text-gray-400">Descarga en</div>
                                        <div class="font-semibold">App Store</div>
                                    </div>
                                </button></div>
                        </div>
                    </div>
                    <div
                        class="border-t border-gray-700 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
                        <p>© 2026 Registraduría Nacional del Estado Civil. Todos los derechos reservados.</p>
                        <div class="flex flex-wrap gap-6"><a href="#" class="hover:text-white transition">Política de
                                privacidad</a><a href="#" class="hover:text-white transition">Términos y
                                condiciones</a><a href="#" class="hover:text-white transition">Tratamiento de
                                datos</a><a href="#" class="hover:text-white transition">Accesibilidad</a></div>
                    </div>
                    <div class="mt-8 pt-8 border-t border-gray-700 flex flex-wrap justify-center gap-6">
                        <div class="px-6 py-3 bg-gray-800 rounded-lg text-center">
                            <div class="text-xs text-gray-400 mb-1">Certificado por</div>
                            <div class="font-semibold">ISO 9001:2015</div>
                        </div>
                        <div class="px-6 py-3 bg-gray-800 rounded-lg text-center">
                            <div class="text-xs text-gray-400 mb-1">Gobierno Digital</div>
                            <div class="font-semibold">Colombia</div>
                        </div>
                        <div class="px-6 py-3 bg-gray-800 rounded-lg text-center">
                            <div class="text-xs text-gray-400 mb-1">Nivel de seguridad</div>
                            <div class="font-semibold">Alto</div>
                        </div>
                    </div>
                </div>
            </footer>

            <!-- Scripts -->
            <script>


                document.addEventListener('DOMContentLoaded', function () {
                    // Mobile menu toggle
                    const mobileMenuButton = document.getElementById('mobileMenuButton');
                    const mobileMenu = document.getElementById('mobileMenu');
                    if (mobileMenuButton && mobileMenu) {
                        mobileMenuButton.addEventListener('click', () => {
                            mobileMenu.classList.toggle('hidden');
                        });
                    }

                    // Smooth scroll for anchor links
                    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                        anchor.addEventListener('click', function (e) {
                            const target = document.querySelector(this.getAttribute('href'));
                            if (target) {
                                e.preventDefault();
                                target.scrollIntoView({ behavior: 'smooth' });
                            }
                        });
                    });

                    // Efecto ripple al hacer click en botones auth
                    document.querySelectorAll('.btn-auth-click').forEach(btn => {
                        btn.addEventListener('click', function (e) {
                            const rect = this.getBoundingClientRect();
                            const x = e.clientX - rect.left;
                            const y = e.clientY - rect.top;

                            const ripple = document.createElement('span');
                            ripple.style.cssText = `
                        position: absolute;
                        width: 20px;
                        height: 20px;
                        border-radius: 50%;
                        background: rgba(255,255,255,0.5);
                        transform: translate(-50%, -50%) scale(0);
                        animation: ripple-effect 0.6s ease-out;
                        pointer-events: none;
                        left: ${x}px;
                        top: ${y}px;
                    `;

                            this.appendChild(ripple);
                            setTimeout(() => ripple.remove(), 600);
                        });
                    });

                    if (!document.getElementById('ripple-keyframes')) {
                        const style = document.createElement('style');
                        style.id = 'ripple-keyframes';
                        style.textContent = `
                    @keyframes ripple-effect {
                        to {
                            transform: translate(-50%, -50%) scale(15);
                            opacity: 0;
                        }
                    }
                `;
                        document.head.appendChild(style);
                    }

                    // Efecto de entrada escalonada para botones en carga
                    const authButtons = document.querySelectorAll('.btn-auth');
                    authButtons.forEach((btn, index) => {
                        btn.style.opacity = '0';
                        btn.style.transform = 'translateY(10px)';
                        btn.style.transition = 'opacity 0.4s ease, transform 0.4s ease';

                        setTimeout(() => {
                            btn.style.opacity = '1';
                            btn.style.transform = 'translateY(0)';
                        }, 200 + (index * 100));
                    });
                });

                // FUNCIONES PARA MODALES GLASSMORPHISM

                function openModal(modalId) {
                    const modal = document.getElementById(modalId);
                    if (modal) {
                        modal.classList.add('active');
                        document.body.style.overflow = 'hidden'; // Prevenir scroll del body
                    }
                }

                function closeModal(modalId) {
                    const modal = document.getElementById(modalId);
                    if (modal) {
                        modal.classList.remove('active');
                        document.body.style.overflow = ''; // Restaurar scroll del body
                    }
                }

                function closeModalOnOverlay(event, modalId) {
                    if (event.target === event.currentTarget) {
                        closeModal(modalId);
                    }
                }

                // Cerrar modal con tecla ESC
                document.addEventListener('keydown', function (e) {
                    if (e.key === 'Escape') {
                        const activeModals = document.querySelectorAll('.modal-overlay.active');
                        activeModals.forEach(modal => {
                            modal.classList.remove('active');
                        });
                        document.body.style.overflow = '';
                    }
                });
            </script>
            <script src="<%= request.getContextPath() %>/js/registraduria.js"></script>
        </body>

        </html>